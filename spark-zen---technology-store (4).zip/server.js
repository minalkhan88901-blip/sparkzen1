import express from 'express';
import { createClient } from '@supabase/supabase-js';

const app = express();
app.use(express.json());

const supabase = createClient(
  process.env.SUPABASE_URL || 'https://spqpwimhruoqjmbpgjka.supabase.co',
  process.env.SUPABASE_SERVICE_ROLE_KEY || 'sb_secret_iZ4Fs7v_kR_CdzfmNDTIsA_PF5oq5j5'
);

// bKash SMS Parsing (Regex)
export function parseBkashSMS(smsText) {
  const trxMatch = smsText.match(/TrxID\s+([A-Z0-9]+)/i);
  const amountMatch = smsText.match(/Tk\s+([\d,]+\.?\d*)/i);

  if (trxMatch && amountMatch) {
    return {
      trx_id: trxMatch[1].trim(),
      amount: parseFloat(amountMatch[1].replace(/,/g, ''))
    };
  }
  return null;
}

// SMS Webhook Endpoint
app.post('/api/sms-webhook', async (req, res) => {
  try {
    const { message } = req.body;
    if (!message) return res.status(400).json({ error: 'No message' });

    const parsedData = parseBkashSMS(message);
    if (!parsedData) return res.status(200).json({ message: 'Not bKash SMS' });

    const { trx_id, amount } = parsedData;

    // ১. পেন্ডিং অর্ডার খোঁজা
    const { data: order, error } = await supabase
      .from('orders')
      .select('*')
      .eq('submitted_trx_id', trx_id)
      .eq('status', 'Pending')
      .single();

    if (error || !order) {
      return res.status(200).json({ message: 'No matching order' });
    }

    const orderPk = order.id !== undefined ? order.id : order.order_id;
    const orderCol = order.id !== undefined ? 'id' : 'order_id';

    // ২. টাকা মেলানো
    if (amount >= order.total_price) {
      // ✅ SUCCESS
      await supabase
        .from('orders')
        .update({ status: 'Paid', verified_amount: amount })
        .eq(orderCol, orderPk);

      // রিসেলার অটো-অর্ডার ফাংশন কল
      await placeResellerOrder(order);

      return res.status(200).json({ status: 'success' });
    } else {
      // ❌ FAILED
      await supabase
        .from('orders')
        .update({ status: 'Payment Failed', failure_reason: 'Insufficient Amount' })
        .eq(orderCol, orderPk);

      return res.status(200).json({ status: 'failed' });
    }
  } catch (err) {
    return res.status(500).json({ error: 'Server Error' });
  }
});

// ৩. রিসেলার সাইটে অটো-অর্ডার পাঠানোর লজিক
export async function placeResellerOrder(orderData) {
  // এখানে আপনার রিসেলার সাইটের API Call হবে
  console.log("Placing order on Reseller Site for Order ID:", orderData.id || orderData.order_id);
}

// ৪. কাস্টমার ফ্রন্টএন্ড থেকে স্ট্যাটাস চেক করার Endpoint
app.get('/api/check-order-status', async (req, res) => {
  const { order_id } = req.query;
  if (!order_id) return res.json({ status: 'Pending' });

  // Check Supabase
  let order = null;
  const resId = await supabase
    .from('orders')
    .select('status')
    .eq('id', order_id)
    .single();

  if (resId.data) {
    order = resId.data;
  } else {
    const resOrder = await supabase
      .from('orders')
      .select('status')
      .eq('order_id', order_id)
      .single();
    if (resOrder.data) {
      order = resOrder.data;
    }
  }

  res.json({ status: order ? order.status : 'Pending' });
});

export default app;
