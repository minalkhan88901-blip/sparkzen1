export interface ProductSpecification {
  key: string;
  value: string;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  shortDescription: string;
  description: string;
  specifications: ProductSpecification[];
  price: number;
  discountPrice?: number;
  stockQuantity: number;
  sku: string;
  category: string;
  status: 'active' | 'disabled';
  featured: boolean;
  badge?: string;
  images: string[];
}

export interface OrderItem {
  productId: string;
  name: string;
  sku: string;
  price: number;
  quantity: number;
  subtotal: number;
  image: string;
}

export interface OrderPricing {
  subtotal: number;
  deliveryCharge: number;
  totalOrderValue: number;
  advanceDeliveryPaid: number;
  productAmountDue: number;
}

export interface CustomerInfo {
  name: string;
  phone: string;
  address: string;
  city: string;
  location: 'inside_dhaka' | 'outside_dhaka';
  notes?: string;
}

export type PaymentStatus =
  | 'delivery_charge_pending'
  | 'delivery_charge_paid'
  | 'product_amount_due'
  | 'product_amount_paid'
  | 'fully_paid'
  | 'payment_failed'
  | 'refunded';

export type OrderStatus =
  | 'new'
  | 'confirmed'
  | 'processing'
  | 'shipped'
  | 'delivered'
  | 'cancelled';

export type DeliveryStatus =
  | 'pending'
  | 'booked'
  | 'in_transit'
  | 'delivered'
  | 'returned';

export interface CourierInfo {
  name: string;
  trackingId: string;
}

export interface AdvancePaymentDetails {
  method: 'bkash' | 'nagad' | 'card' | 'manual';
  transactionId?: string;
  senderNumber?: string;
  paidAt?: string;
}

export interface Order {
  id: string;
  createdAt: string;
  customer: CustomerInfo;
  items: OrderItem[];
  pricing: OrderPricing;
  paymentStatus: PaymentStatus;
  orderStatus: OrderStatus;
  deliveryStatus: DeliveryStatus;
  courier: CourierInfo;
  advancePaymentDetails?: AdvancePaymentDetails;
  adminNotes?: string;
  syncedToGoogleSheets?: boolean;
  sheetsSyncTimestamp?: string;
}

export interface CustomerRecord {
  id: string;
  name: string;
  phone: string;
  address: string;
  city: string;
  location: 'inside_dhaka' | 'outside_dhaka';
  ordersCount: number;
  totalSpent: number;
  outstandingDue: number;
  lastOrderDate: string;
}

export interface StoreSettings {
  storeName: string;
  brandTagline: string;
  phone: string;
  whatsapp: string;
  email: string;
  address: string;
  insideDhakaDeliveryCharge: number;
  outsideDhakaDeliveryCharge: number;
  advancePaymentMethod: {
    bkashMerchantNumber: string;
    nagadMerchantNumber: string;
    instructions: string;
  };
  googleSheetsWebhookUrl: string;
  faqs: { q: string; a: string }[];
  returnPolicy: string;
  terms: string;
  heroAnnouncement?: string;
}

export interface CartItem {
  productId: string;
  product: Product;
  quantity: number;
  unitPrice: number;
  subtotal: number;
  selected?: boolean;
}

export interface AdminStats {
  totalOrders: number;
  newOrders: number;
  confirmedOrders: number;
  processingOrders: number;
  shippedOrders: number;
  deliveredOrders: number;
  cancelledOrders: number;
  totalSales: number;
  amountCollected: number;
  amountDue: number;
  deliveryChargesCollected?: number;
  outstandingProductDue?: number;
  lowStockProducts?: number;
}
