import type {
  Product,
  Order,
  StoreSettings,
  CustomerRecord,
  AdminStats,
  PaymentStatus,
  OrderStatus,
  DeliveryStatus
} from './types.js';

const API_BASE = '/api';

function getAdminHeaders(): HeadersInit {
  const token = localStorage.getItem('sparkzen_admin_token');
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {})
  };
}

export const api = {
  // --- Public APIs ---
  async getProducts(): Promise<Product[]> {
    const res = await fetch(`${API_BASE}/products`);
    if (!res.ok) throw new Error('Failed to fetch products');
    return res.json();
  },

  async getProduct(id: string): Promise<Product> {
    const res = await fetch(`${API_BASE}/products/${id}`);
    if (!res.ok) throw new Error('Product not found');
    return res.json();
  },

  async getSettings(): Promise<StoreSettings> {
    const res = await fetch(`${API_BASE}/settings`);
    if (!res.ok) throw new Error('Failed to fetch settings');
    return res.json();
  },

  async createOrder(payload: {
    customer: Order['customer'];
    items: { productId: string; quantity: number }[];
    advancePaymentDetails?: Order['advancePaymentDetails'];
  }): Promise<Order> {
    const res = await fetch(`${API_BASE}/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to place order');
    return data;
  },

  async getOrder(id: string): Promise<Order> {
    const res = await fetch(`${API_BASE}/orders/${id}`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Order not found');
    return data;
  },

  async submitAdvancePayment(orderId: string, details: {
    method: 'bkash' | 'nagad' | 'card' | 'manual';
    transactionId: string;
    senderNumber?: string;
  }): Promise<Order> {
    const res = await fetch(`${API_BASE}/orders/${orderId}/advance-payment`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(details)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to record advance payment');
    return data;
  },

  // --- Admin APIs ---
  async adminLogin(username: string, password: string): Promise<{ token: string; user: { username: string; role: string } }> {
    const res = await fetch(`${API_BASE}/admin/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Login failed');
    return data;
  },

  async adminLogout(): Promise<void> {
    try {
      await fetch(`${API_BASE}/admin/logout`, {
        method: 'POST',
        headers: getAdminHeaders()
      });
    } catch (e) {
      console.error('Logout error:', e);
    } finally {
      localStorage.removeItem('sparkzen_admin_token');
    }
  },

  async adminVerify(): Promise<{ valid: boolean; user?: { username: string; role: string } }> {
    const token = localStorage.getItem('sparkzen_admin_token');
    if (!token) return { valid: false };
    try {
      const res = await fetch(`${API_BASE}/admin/verify`, {
        headers: getAdminHeaders()
      });
      if (!res.ok) return { valid: false };
      return res.json();
    } catch {
      return { valid: false };
    }
  },

  async getAdminStats(): Promise<{ stats: AdminStats; recentOrders: Order[] }> {
    const res = await fetch(`${API_BASE}/admin/stats`, {
      headers: getAdminHeaders()
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to load admin stats');
    return data;
  },

  async getAdminProducts(): Promise<Product[]> {
    const res = await fetch(`${API_BASE}/admin/products`, {
      headers: getAdminHeaders()
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to load admin products');
    return data;
  },

  async addProduct(product: Partial<Product>): Promise<Product> {
    const res = await fetch(`${API_BASE}/admin/products`, {
      method: 'POST',
      headers: getAdminHeaders(),
      body: JSON.stringify(product)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to add product');
    return data;
  },

  async updateProduct(id: string, updates: Partial<Product>): Promise<Product> {
    const res = await fetch(`${API_BASE}/admin/products/${id}`, {
      method: 'PUT',
      headers: getAdminHeaders(),
      body: JSON.stringify(updates)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update product');
    return data;
  },

  async deleteProduct(id: string): Promise<void> {
    const res = await fetch(`${API_BASE}/admin/products/${id}`, {
      method: 'DELETE',
      headers: getAdminHeaders()
    });
    if (!res.ok) {
      const data = await res.json();
      throw new Error(data.error || 'Failed to delete product');
    }
  },

  async getAdminOrders(params?: { search?: string; orderStatus?: string; paymentStatus?: string }): Promise<Order[]> {
    const query = new URLSearchParams();
    if (params?.search) query.set('search', params.search);
    if (params?.orderStatus) query.set('orderStatus', params.orderStatus);
    if (params?.paymentStatus) query.set('paymentStatus', params.paymentStatus);

    const res = await fetch(`${API_BASE}/admin/orders?${query.toString()}`, {
      headers: getAdminHeaders()
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to load orders');
    return data;
  },

  async updateOrder(id: string, updates: Partial<Order>): Promise<Order> {
    const res = await fetch(`${API_BASE}/admin/orders/${id}`, {
      method: 'PUT',
      headers: getAdminHeaders(),
      body: JSON.stringify(updates)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update order');
    return data;
  },

  async syncOrderSheets(id: string): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`${API_BASE}/admin/orders/${id}/sync-sheets`, {
      method: 'POST',
      headers: getAdminHeaders()
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Sync request failed');
    return data;
  },

  async getAdminCustomers(): Promise<CustomerRecord[]> {
    const res = await fetch(`${API_BASE}/admin/customers`, {
      headers: getAdminHeaders()
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to load customers');
    return data;
  },

  async getAdminSettings(): Promise<StoreSettings> {
    const res = await fetch(`${API_BASE}/admin/settings`, {
      headers: getAdminHeaders()
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to load settings');
    return data;
  },

  async updateAdminSettings(settings: Partial<StoreSettings>): Promise<StoreSettings> {
    const res = await fetch(`${API_BASE}/admin/settings`, {
      method: 'PUT',
      headers: getAdminHeaders(),
      body: JSON.stringify(settings)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update settings');
    return data;
  },

  async changeAdminPassword(newPassword: string): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`${API_BASE}/admin/change-password`, {
      method: 'POST',
      headers: getAdminHeaders(),
      body: JSON.stringify({ newPassword })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to change password');
    return data;
  },

  async uploadProductImage(file: File): Promise<{ url: string; filename: string }> {
    return new Promise((resolve, reject) => {
      // Validate client-side first
      const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
      if (!validTypes.includes(file.type)) {
        return reject(new Error('Invalid image type. Please select a JPG, PNG, WEBP, or GIF file.'));
      }
      if (file.size > 5 * 1024 * 1024) {
        return reject(new Error('Image file is too large. Maximum file size is 5MB.'));
      }

      const reader = new FileReader();
      reader.onload = async () => {
        try {
          const base64Data = reader.result as string;
          const res = await fetch(`${API_BASE}/admin/upload-image`, {
            method: 'POST',
            headers: getAdminHeaders(),
            body: JSON.stringify({
              image: base64Data,
              filename: file.name
            })
          });
          const data = await res.json();
          if (!res.ok) {
            throw new Error(data.error || 'Upload failed');
          }
          resolve(data);
        } catch (err) {
          reject(err);
        }
      };
      reader.onerror = () => reject(new Error('Failed to read image file'));
      reader.readAsDataURL(file);
    });
  },

  async getDatabaseBackup(): Promise<any> {
    const res = await fetch(`${API_BASE}/admin/backup`, {
      headers: getAdminHeaders()
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      throw new Error(data.error || 'Failed to download database backup');
    }
    return res.json();
  },

  async restoreDatabaseBackup(backupData: any): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`${API_BASE}/admin/restore`, {
      method: 'POST',
      headers: getAdminHeaders(),
      body: JSON.stringify({ backup: backupData })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to restore database');
    return data;
  }
};
