import React, { useState, useEffect } from 'react';
import { Header } from './components/Header.js';
import { Hero } from './components/Hero.js';
import { FeaturedProducts } from './components/FeaturedProducts.js';
import { ProductDetailsModal } from './components/ProductDetailsModal.js';
import { CartDrawer } from './components/CartDrawer.js';
import { CheckoutModal } from './components/CheckoutModal.js';
import { OrderConfirmationModal } from './components/OrderConfirmationModal.js';
import { TrackOrderModal } from './components/TrackOrderModal.js';
import { PaymentModelExplainer } from './components/PaymentModelExplainer.js';
import { AboutSection } from './components/AboutSection.js';
import { FAQSection } from './components/FAQSection.js';
import { Footer } from './components/Footer.js';
import { AdminLogin } from './components/admin/AdminLogin.js';
import { AdminDashboard } from './components/admin/AdminDashboard.js';
import { api } from './api.js';
import type { Product, CartItem, StoreSettings, Order } from './types.js';

export default function App() {
  const [products, setProducts] = useState<Product[]>([]);
  const [settings, setSettings] = useState<StoreSettings | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Cart state persisted to localStorage
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('sparkzen_cart');
      if (!saved) return [];
      const parsed = JSON.parse(saved);
      return parsed.map((item: any) => ({
        productId: item.productId || item.product?.id || '',
        product: item.product,
        quantity: Math.max(1, item.quantity || 1),
        unitPrice: item.unitPrice || item.product?.price || 0,
        subtotal: (item.unitPrice || item.product?.price || 0) * (item.quantity || 1),
        selected: item.selected !== false
      }));
    } catch {
      return [];
    }
  });

  // Checkout Mode & Buy Now state (strictly separated from cart)
  const [checkoutMode, setCheckoutMode] = useState<'cart' | 'buy_now'>('cart');
  const [buyNowItem, setBuyNowItem] = useState<CartItem | null>(null);

  // Modal states
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [checkoutLocation, setCheckoutLocation] = useState<'inside_dhaka' | 'outside_dhaka'>('inside_dhaka');
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);
  const [isTrackModalOpen, setIsTrackModalOpen] = useState(false);

  // Admin routing state
  const [isAdminView, setIsAdminView] = useState(() => {
    return window.location.hash === '#admin';
  });
  const [adminUser, setAdminUser] = useState<{ username: string; role: string } | null>(null);

  // Toast feedback
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (message: string) => {
    setToast(message);
    setTimeout(() => setToast(null), 2500);
  };

  // Save cart
  useEffect(() => {
    try {
      localStorage.setItem('sparkzen_cart', JSON.stringify(cart));
    } catch (e) {
      console.error(e);
    }
  }, [cart]);

  // Listen to hash changes for #admin
  useEffect(() => {
    const handleHashChange = () => {
      if (window.location.hash === '#admin') {
        setIsAdminView(true);
      }
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // Check admin session on mount
  useEffect(() => {
    api.adminVerify().then(res => {
      if (res.valid && res.user) {
        setAdminUser(res.user);
      }
    });
  }, []);

  // Fetch initial public products and store settings
  const fetchStoreData = async () => {
    try {
      setIsLoading(true);
      const [fetchedProducts, fetchedSettings] = await Promise.all([
        api.getProducts(),
        api.getSettings()
      ]);
      setProducts(fetchedProducts);
      setSettings(fetchedSettings);
    } catch (err) {
      console.error('Failed to load store data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchStoreData();
  }, []);

  // Cart operations
  const handleAddToCart = (product: Product, quantity = 1) => {
    setCart(prev => {
      const existing = prev.find(item => item.productId === product.id || item.product.id === product.id);
      if (existing) {
        const newQty = Math.min(existing.quantity + quantity, product.stockQuantity);
        return prev.map(item =>
          (item.productId === product.id || item.product.id === product.id)
            ? {
                ...item,
                quantity: newQty,
                unitPrice: product.price,
                subtotal: product.price * newQty,
                selected: true
              }
            : item
        );
      } else {
        const initialQty = Math.min(Math.max(1, quantity), product.stockQuantity);
        return [
          ...prev,
          {
            productId: product.id,
            product,
            quantity: initialQty,
            unitPrice: product.price,
            subtotal: product.price * initialQty,
            selected: true
          }
        ];
      }
    });
    setToast(`Added "${product.name}" (${quantity}) to cart`);
    setTimeout(() => setToast(null), 2500);
  };

  const handleUpdateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveCartItem(productId);
      return;
    }
    setCart(prev =>
      prev.map(item => {
        if (item.productId === productId || item.product.id === productId) {
          const validQty = Math.min(Math.max(1, quantity), item.product.stockQuantity);
          return {
            ...item,
            quantity: validQty,
            subtotal: item.unitPrice * validQty
          };
        }
        return item;
      })
    );
  };

  const handleRemoveCartItem = (productId: string) => {
    setCart(prev => prev.filter(item => item.productId !== productId && item.product.id !== productId));
  };

  const handleToggleCartItemSelect = (productId: string) => {
    setCart(prev =>
      prev.map(item =>
        (item.productId === productId || item.product.id === productId)
          ? { ...item, selected: item.selected === false ? true : false }
          : item
      )
    );
  };

  const handleToggleSelectAll = (selectAll: boolean) => {
    setCart(prev => prev.map(item => ({ ...item, selected: selectAll })));
  };

  // BUY NOW: Completely separate temporary flow. Does NOT touch cart.
  const handleBuyNow = (product: Product, quantity = 1) => {
    const validQty = Math.min(Math.max(1, quantity), product.stockQuantity);
    const checkoutItem: CartItem = {
      productId: product.id,
      product,
      quantity: validQty,
      unitPrice: product.price,
      subtotal: product.price * validQty,
      selected: true
    };
    setBuyNowItem(checkoutItem);
    setCheckoutMode('buy_now');
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  // CART CHECKOUT: Checkout currently selected cart items.
  const handleProceedToCheckout = (location: 'inside_dhaka' | 'outside_dhaka') => {
    setCheckoutLocation(location);
    setBuyNowItem(null);
    setCheckoutMode('cart');
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  // Quantity updates directly inside the Checkout Modal
  const handleUpdateCheckoutQuantity = (productId: string, newQty: number) => {
    if (checkoutMode === 'buy_now') {
      if (buyNowItem && (buyNowItem.productId === productId || buyNowItem.product.id === productId)) {
        const validQty = Math.min(Math.max(1, newQty), buyNowItem.product.stockQuantity);
        setBuyNowItem({
          ...buyNowItem,
          quantity: validQty,
          subtotal: buyNowItem.unitPrice * validQty
        });
      }
    } else {
      handleUpdateCartQuantity(productId, newQty);
    }
  };

  const handleOrderSuccess = (order: Order) => {
    setConfirmedOrder(order);
    setIsCheckoutOpen(false);
    if (checkoutMode === 'cart') {
      // Retain unselected items in cart; remove checked-out items
      setCart(prev => prev.filter(item => item.selected === false));
    }
    // Reset buy now and checkout state
    setBuyNowItem(null);
    setCheckoutMode('cart');
    fetchStoreData(); // Refresh product stock
  };

  // Scroll helpers
  const handleShopNow = () => {
    const el = document.getElementById('products');
    if (el) {
      const yOffset = -70;
      const y = el.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  const handleExplore = () => {
    const el = document.getElementById('payment-model');
    if (el) {
      const yOffset = -70;
      const y = el.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  // If Admin View is active
  if (isAdminView) {
    if (!adminUser) {
      return (
        <AdminLogin
          onLoginSuccess={(user) => setAdminUser(user)}
          onBackToStore={() => {
            window.location.hash = '';
            setIsAdminView(false);
          }}
        />
      );
    }

    return (
      <AdminDashboard
        adminUser={adminUser}
        onLogout={async () => {
          try {
            await api.adminLogout();
          } catch (e) {
            // ignore
          }
          localStorage.removeItem('sparkzen_admin_token');
          setAdminUser(null);
          window.location.hash = '';
          setIsAdminView(false);
        }}
        onViewStore={() => {
          window.location.hash = '';
          setIsAdminView(false);
        }}
      />
    );
  }

  // Storefront view
  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col font-sans selection:bg-blue-600/15 selection:text-blue-700">
      
      {/* Toast Notification */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 px-4 py-3 rounded-xl bg-white border border-slate-200 text-slate-800 text-xs font-mono-code shadow-xl ring-1 ring-slate-900/5 animate-in fade-in slide-in-from-bottom-3">
          {toast}
        </div>
      )}

      {/* Header */}
      <Header
        cart={cart}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenAdmin={() => {
          window.location.hash = '#admin';
          setIsAdminView(true);
        }}
        onOpenTrack={() => setIsTrackModalOpen(true)}
        settings={settings}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        <Hero
          settings={settings}
          onShopNow={handleShopNow}
          onExplore={handleExplore}
        />

        <FeaturedProducts
          products={products}
          onSelectProduct={(product) => setSelectedProduct(product)}
          onAddToCart={(product) => handleAddToCart(product)}
          onBuyNow={(product) => handleBuyNow(product)}
        />

        <PaymentModelExplainer settings={settings} />

        <AboutSection settings={settings} />

        <FAQSection settings={settings} />
      </main>

      {/* Footer */}
      <Footer
        settings={settings}
        onOpenTrack={() => setIsTrackModalOpen(true)}
        onOpenAdmin={() => {
          window.location.hash = '#admin';
          setIsAdminView(true);
        }}
      />

      {/* Modals & Drawers */}
      <ProductDetailsModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={(product, qty) => handleAddToCart(product, qty)}
        onBuyNow={(product, qty) => handleBuyNow(product, qty)}
      />

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onToggleItemSelect={handleToggleCartItemSelect}
        onToggleSelectAll={handleToggleSelectAll}
        onProceedToCheckout={handleProceedToCheckout}
        settings={settings}
      />

      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => {
          setIsCheckoutOpen(false);
          setBuyNowItem(null);
          setCheckoutMode('cart');
        }}
        items={
          checkoutMode === 'buy_now'
            ? (buyNowItem ? [buyNowItem] : [])
            : (cart.filter(item => item.selected !== false).length > 0
                ? cart.filter(item => item.selected !== false)
                : cart)
        }
        mode={checkoutMode}
        defaultLocation={checkoutLocation}
        settings={settings}
        onUpdateQuantity={handleUpdateCheckoutQuantity}
        onOrderSuccess={handleOrderSuccess}
      />

      <OrderConfirmationModal
        order={confirmedOrder}
        onClose={() => setConfirmedOrder(null)}
        settings={settings}
      />

      <TrackOrderModal
        isOpen={isTrackModalOpen}
        onClose={() => setIsTrackModalOpen(false)}
      />

    </div>
  );
}
