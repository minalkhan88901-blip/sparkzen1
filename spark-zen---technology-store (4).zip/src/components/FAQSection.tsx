import React, { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';
import type { StoreSettings } from '../types.js';

interface FAQSectionProps {
  settings: StoreSettings | null;
}

interface FAQItem {
  question: string;
  answer: string;
}

export const FAQSection: React.FC<FAQSectionProps> = ({ settings }) => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const insideFee = settings?.insideDhakaDeliveryCharge || 70;
  const outsideFee = settings?.outsideDhakaDeliveryCharge || 130;

  const faqs: FAQItem[] = [
    {
      question: 'Why do I only pay the delivery charge in advance?',
      answer: `Courier companies in Bangladesh require booking fees when parcels are shipped. To protect against fake orders without putting your money at risk, we strictly collect only the courier charge (৳${insideFee} inside Dhaka / ৳${outsideFee} outside Dhaka) upfront. You pay the gadget price in cash only when you receive and hold the item.`
    },
    {
      question: 'How do I pay the advance courier fee?',
      answer: `You can send money easily via bKash or Nagad directly during checkout and paste your Transaction ID (TrxID). Alternatively, choose 'Confirm & Pay in 2 Hours', and our friendly customer care team will message your WhatsApp or call you with verified steps.`
    },
    {
      question: 'When and how do I pay for the gadget itself?',
      answer: `You pay the product price exclusively upon doorstep delivery directly to the courier rider in cash (Cash on Delivery). You never pay for your product until it physically arrives at your home or office.`
    },
    {
      question: 'How fast will my order arrive across Bangladesh?',
      answer: `Orders inside Dhaka are delivered within 24 to 48 hours. Orders outside Dhaka (Chattogram, Sylhet, Rajshahi, Khulna, Barishal, Rangpur, etc.) are delivered within 48 to 72 hours via trusted couriers (Steadfast / Pathao) with continuous SMS tracking updates.`
    },
    {
      question: 'Are all products authentic and tested before shipping?',
      answer: `Yes, 100%! Every single product in our catalog undergoes rigorous functional inspection before packaging—checking charging speeds, sound clarity, bluetooth stability, and build quality.`
    },
    {
      question: 'What is your warranty and replacement policy?',
      answer: `We provide a 7-day hassle-free replacement warranty for any manufacturer defect. If anything isn't working properly, simply send our friendly WhatsApp team a quick video clip for immediate replacement.`
    },
    {
      question: 'Can I cancel or change my delivery address after ordering?',
      answer: `Absolutely. Just message or call our support team on WhatsApp or phone with your Order ID before the parcel is dispatched from our hub.`
    }
  ];

  return (
    <section id="faq" className="py-16 md:py-24 bg-[#f8fafc] border-b border-slate-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-50 border border-blue-200 text-xs font-semibold text-blue-700 mb-3 shadow-xs">
            <HelpCircle className="w-3.5 h-3.5 text-blue-600" />
            <span>Got Questions? We're Here to Help</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Frequently Asked Questions
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-600">
            Clear, honest answers about our ordering, delivery, and cash-on-delivery system.
          </p>
        </div>

        {/* Accordion List */}
        <div className="space-y-3">
          {faqs.map((faq, idx) => {
            const isOpen = openIndex === idx;

            return (
              <div
                key={idx}
                className={`rounded-2xl border transition-all overflow-hidden ${
                  isOpen
                    ? 'border-blue-500 bg-white shadow-xs'
                    : 'border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                <button
                  onClick={() => setOpenIndex(isOpen ? null : idx)}
                  className="w-full py-4 sm:py-5 px-5 sm:px-6 text-left flex items-center justify-between gap-4 cursor-pointer focus:outline-none"
                >
                  <span className="text-sm sm:text-base font-bold text-slate-900">
                    {faq.question}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 text-slate-500 shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 text-blue-600' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-5 sm:px-6 pb-5 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 pt-3.5">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
