import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, ShieldCheck, Zap, Check } from 'lucide-react';
import type { CartItem, StoreSettings } from '../types.js';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onToggleItemSelect?: (productId: string) => void;
  onToggleSelectAll?: (selectAll: boolean) => void;
  onProceedToCheckout: (deliveryLocation: 'inside_dhaka' | 'outside_dhaka') => void;
  settings: StoreSettings | null;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onToggleItemSelect,
  onToggleSelectAll,
  onProceedToCheckout,
  settings
}) => {
  const [deliveryLocation, setDeliveryLocation] = useState<'inside_dhaka' | 'outside_dhaka'>('inside_dhaka');

  if (!isOpen) return null;

  const insideFee = settings?.insideDhakaDeliveryCharge || 70;
  const outsideFee = settings?.outsideDhakaDeliveryCharge || 130;
  const currentDeliveryFee = deliveryLocation === 'inside_dhaka' ? insideFee : outsideFee;

  const selectedItems = cart.filter(item => item.selected !== false);
  const selectedUnitsCount = selectedItems.reduce((sum, i) => sum + i.quantity, 0);
  const totalCartUnits = cart.reduce((sum, i) => sum + i.quantity, 0);
  const allSelected = cart.length > 0 && cart.every(i => i.selected !== false);

  const subtotal = selectedItems.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const totalOrderValue = selectedItems.length > 0 ? subtotal + currentDeliveryFee : 0;
  const advancePayableNow = selectedItems.length > 0 ? currentDeliveryFee : 0;
  const amountDueOnDelivery = subtotal;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-slate-900/50 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-0 sm:pl-10">
        <div className="w-full sm:w-screen max-w-full sm:max-w-md bg-white border-l border-slate-200 shadow-2xl flex flex-col justify-between">
          
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-white">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-blue-600" />
              <h2 className="text-base sm:text-lg font-bold text-slate-900">Your Shopping Cart</h2>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200 font-bold">
                {totalCartUnits} {totalCartUnits === 1 ? 'item' : 'items'}
              </span>
            </div>
            <button
              onClick={onClose}
              className="w-9 h-9 sm:w-8 sm:h-8 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors flex items-center justify-center cursor-pointer"
              aria-label="Close cart"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 divide-y divide-slate-100">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
                <div className="w-16 h-16 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-center text-slate-400">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h3 className="text-base font-bold text-slate-800">Your cart is currently empty</h3>
                <p className="text-xs text-slate-500 max-w-xs">
                  Browse our curated tech essentials and add your favorite items.
                </p>
                <button
                  onClick={onClose}
                  className="mt-2 min-h-[44px] px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition-colors cursor-pointer shadow-xs"
                >
                  Browse Tech Products
                </button>
              </div>
            ) : (
              <>
                {/* Select All Toggle Bar */}
                {cart.length > 1 && (
                  <div className="pb-3 flex items-center justify-between text-xs text-slate-600">
                    <label className="flex items-center gap-2 cursor-pointer font-medium hover:text-slate-900 select-none">
                      <input
                        type="checkbox"
                        checked={allSelected}
                        onChange={(e) => onToggleSelectAll?.(e.target.checked)}
                        className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300 cursor-pointer accent-blue-600"
                      />
                      <span>Select All ({cart.length} products)</span>
                    </label>
                    <span className="text-slate-400 font-mono text-[11px]">
                      {selectedItems.length}/{cart.length} selected
                    </span>
                  </div>
                )}

                {cart.map((item) => {
                  const pId = item.productId || item.product.id;
                  const isSelected = item.selected !== false;
                  const itemSubtotal = item.product.price * item.quantity;
                  const isMin = item.quantity <= 1;
                  const isMax = item.quantity >= item.product.stockQuantity;

                  return (
                    <div key={pId} className="py-3.5 sm:py-4 flex gap-2.5 sm:gap-3 items-center">
                      {/* Item Selection Checkbox */}
                      <div className="shrink-0">
                        <label className="cursor-pointer block p-0.5 select-none" aria-label={`Select ${item.product.name}`}>
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => onToggleItemSelect?.(pId)}
                            className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300 cursor-pointer accent-blue-600"
                          />
                        </label>
                      </div>

                      {/* Product Thumbnail */}
                      <div className="w-16 h-16 rounded-xl bg-[#f8fafc] border border-slate-200 p-1.5 shrink-0 flex items-center justify-center overflow-hidden">
                        <img
                          src={item.product.images[0] || '/sparkzen-logo.png'}
                          alt={item.product.name}
                          className="w-full h-full object-contain"
                          referrerPolicy="no-referrer"
                          onError={(e) => {
                            const target = e.currentTarget;
                            if (!target.src.endsWith('/sparkzen-logo.png')) {
                              target.src = '/sparkzen-logo.png';
                            }
                          }}
                        />
                      </div>

                      {/* Product Details & Quantity Controls */}
                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs sm:text-sm font-bold text-slate-900 truncate">
                          {item.product.name}
                        </h4>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-xs text-blue-600 font-bold">
                            ৳{(item.product.price ?? 0).toLocaleString()}
                          </span>
                          <span className="text-[11px] text-slate-400">
                            (Stock: {item.product.stockQuantity})
                          </span>
                        </div>

                        <div className="flex items-center gap-3 mt-2">
                          {/* Independent Quantity selector: [-] 1 [+] */}
                          <div className="flex items-center border border-slate-200 rounded-lg bg-white shadow-xs">
                            <button
                              type="button"
                              onClick={() => onUpdateQuantity(pId, item.quantity - 1)}
                              disabled={isMin}
                              className="w-8 h-8 sm:w-7 sm:h-7 flex items-center justify-center text-slate-500 hover:text-slate-900 disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
                              aria-label={`Decrease ${item.product.name} quantity`}
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <span className="w-8 text-center text-xs font-bold text-slate-900 select-none">
                              {item.quantity}
                            </span>
                            <button
                              type="button"
                              onClick={() => onUpdateQuantity(pId, item.quantity + 1)}
                              disabled={isMax}
                              className="w-8 h-8 sm:w-7 sm:h-7 flex items-center justify-center text-slate-500 hover:text-slate-900 disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
                              aria-label={`Increase ${item.product.name} quantity`}
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          {/* Remove button */}
                          <button
                            type="button"
                            onClick={() => onRemoveItem(pId)}
                            className="w-8 h-8 flex items-center justify-center text-slate-400 hover:text-rose-500 transition-colors cursor-pointer"
                            title="Remove product"
                            aria-label={`Remove ${item.product.name} from cart`}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Item Subtotal Calculation */}
                      <div className="text-right shrink-0">
                        <span className="text-xs sm:text-sm font-bold text-slate-900 block">
                          ৳{(itemSubtotal ?? 0).toLocaleString()}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          subtotal
                        </span>
                      </div>
                    </div>
                  );
                })}
              </>
            )}
          </div>

          {/* Footer & Financial Breakdown */}
          {cart.length > 0 && (
            <div className="p-4 sm:p-5 border-t border-slate-200 bg-[#f8fafc] space-y-3.5 sm:space-y-4">
              
              {/* Delivery Destination Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Select Delivery Location
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setDeliveryLocation('inside_dhaka')}
                    className={`min-h-[50px] p-2.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-center ${
                      deliveryLocation === 'inside_dhaka'
                        ? 'border-blue-600 bg-blue-50/80 text-blue-900 ring-2 ring-blue-500/20 shadow-xs'
                        : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <div className="text-xs font-bold">Inside Dhaka</div>
                    <div className="text-xs text-blue-600 mt-0.5 font-bold">৳{insideFee} Delivery</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setDeliveryLocation('outside_dhaka')}
                    className={`min-h-[50px] p-2.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-center ${
                      deliveryLocation === 'outside_dhaka'
                        ? 'border-blue-600 bg-blue-50/80 text-blue-900 ring-2 ring-blue-500/20 shadow-xs'
                        : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <div className="text-xs font-bold">Outside Dhaka</div>
                    <div className="text-xs text-blue-600 mt-0.5 font-bold">৳{outsideFee} Delivery</div>
                  </button>
                </div>
              </div>

              {/* Price Calculation Table */}
              <div className="space-y-1.5 text-xs border-t border-slate-200/80 pt-3">
                <div className="flex justify-between text-slate-600">
                  <span>Product Subtotal ({selectedUnitsCount} items):</span>
                  <span className="font-semibold text-slate-900">৳{(subtotal ?? 0).toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Advance Delivery Fee:</span>
                  <span className="font-semibold text-slate-900">৳{advancePayableNow}</span>
                </div>
                <div className="flex justify-between text-slate-900 font-bold pt-1.5 border-t border-slate-200">
                  <span>Total Order Value:</span>
                  <span className="text-blue-600 text-sm font-extrabold">৳{(totalOrderValue ?? 0).toLocaleString()}</span>
                </div>
              </div>

              {/* Advance Delivery Highlight Box */}
              <div className="p-3 sm:p-3.5 rounded-xl bg-white border border-blue-200 text-xs shadow-xs">
                <div className="flex items-center justify-between text-blue-700 font-bold mb-1">
                  <span className="flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 text-blue-600" />
                    Pay Advance via bKash/Nagad:
                  </span>
                  <span className="text-sm sm:text-base font-extrabold text-blue-700">৳{advancePayableNow}</span>
                </div>
                <div className="flex items-center justify-between text-slate-600 text-xs pt-1.5 border-t border-slate-100">
                  <span>Due on Delivery (Cash):</span>
                  <span className="text-emerald-700 font-bold">৳{(amountDueOnDelivery ?? 0).toLocaleString()}</span>
                </div>
              </div>

              {/* Checkout Button */}
              <button
                id="cart-checkout-button"
                type="button"
                disabled={selectedItems.length === 0}
                onClick={() => {
                  onClose();
                  onProceedToCheckout(deliveryLocation);
                }}
                className="w-full min-h-[50px] py-3.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm tracking-normal transition-all shadow-md shadow-blue-600/20 flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer active:scale-[0.99]"
              >
                <span>
                  {selectedItems.length === 0
                    ? 'Select at least 1 item to checkout'
                    : `Proceed to Easy Checkout (${selectedUnitsCount} ${selectedUnitsCount === 1 ? 'item' : 'items'})`}
                </span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-center gap-1.5 text-[11px] sm:text-xs text-slate-500 font-medium">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Zero product risk • Pay product price upon delivery</span>
              </div>

            </div>
          )}

        </div>
      </div>
    </div>
  );
};
