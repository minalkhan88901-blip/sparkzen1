import React from 'react';
import { CheckCircle2, Copy, Check, MessageCircle, Printer, Truck, ArrowRight, ShieldAlert, Sparkles } from 'lucide-react';
import type { Order, StoreSettings } from '../types.js';
import OrderStatus from './OrderStatus.js';

interface OrderConfirmationModalProps {
  order: Order | null;
  onClose: () => void;
  settings: StoreSettings | null;
}

export const OrderConfirmationModal: React.FC<OrderConfirmationModalProps> = ({
  order,
  onClose,
  settings
}) => {
  const [copiedId, setCopiedId] = React.useState(false);

  if (!order) return null;

  const handleCopyOrderId = () => {
    navigator.clipboard.writeText(order.id);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  const whatsappPhone = (settings?.whatsapp || '+880 1712-345678').replace(/[^0-9]/g, '');
  const whatsappMessage = encodeURIComponent(
    `Hello SPARK Zen, I just placed an order!\nOrder ID: ${order.id}\nCustomer: ${order.customer.name}\nTotal: BDT ${order.pricing.totalOrderValue}\nAdvance: BDT ${order.pricing.advanceDeliveryPaid}\nCOD Due: BDT ${order.pricing.productAmountDue}`
  );
  const whatsappUrl = `https://wa.me/${whatsappPhone}?text=${whatsappMessage}`;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm overscroll-contain flex min-h-full items-start sm:items-center justify-center p-2.5 sm:p-4 md:p-6">
      <div 
        className="relative w-full max-w-2xl bg-white border border-slate-200 rounded-2xl sm:rounded-3xl shadow-2xl overflow-hidden my-auto sm:my-6"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Banner */}
        <div className="p-4 sm:p-6 bg-gradient-to-b from-blue-50 to-white border-b border-slate-200 text-center">
          <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-emerald-100 border border-emerald-200 text-emerald-600 flex items-center justify-center mx-auto mb-3 shadow-xs">
            <CheckCircle2 className="w-7 h-7 sm:w-8 sm:h-8" />
          </div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
            Order Successfully Placed!
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-md mx-auto">
            Thank you for shopping with SPARK Zen. Your order has been recorded in our dispatch system.
          </p>

          {/* Order ID Tag */}
          <div className="mt-3.5 sm:mt-4 inline-flex items-center gap-2 px-3.5 py-1.5 sm:px-4 sm:py-2 rounded-xl bg-white border border-slate-200 shadow-xs">
            <span className="text-xs text-slate-500 font-mono-code">Order ID:</span>
            <span className="text-sm sm:text-base font-extrabold text-blue-600 font-mono-code tracking-wider">
              {order.id}
            </span>
            <button
              onClick={handleCopyOrderId}
              className="p-1 rounded hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
              title="Copy Order ID"
            >
              {copiedId ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-slate-500" />}
            </button>
          </div>
        </div>

        <div className="p-4 sm:p-6 space-y-4 sm:space-y-6">
          
          {/* Real-time Order Payment Verification Banner */}
          <div className="rounded-2xl border border-slate-200 bg-white shadow-xs overflow-hidden">
            <OrderStatus orderId={order.id} whatsappNumber={settings?.whatsapp} />
          </div>

          {/* Payment Status Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            
            {/* Advance Delivery Status */}
            <div className="p-4 rounded-xl bg-[#f8fafc] border border-slate-200">
              <span className="text-[11px] font-mono-code text-slate-500 uppercase tracking-wider block">
                Advance Delivery Fee ({order.customer.location === 'inside_dhaka' ? 'Inside Dhaka' : 'Outside Dhaka'})
              </span>
              <div className="mt-1 flex items-baseline justify-between">
                <span className="text-xl font-extrabold font-mono-code text-slate-900">
                  BDT {order.pricing.deliveryCharge}
                </span>
                {order.paymentStatus === 'delivery_charge_paid' || order.advancePaymentDetails?.transactionId ? (
                  <span className="text-xs font-mono-code text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded flex items-center gap-1 font-medium">
                    <Check className="w-3 h-3" /> Paid / Under Verification
                  </span>
                ) : (
                  <span className="text-xs font-mono-code text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded font-medium">
                    Payment Pending
                  </span>
                )}
              </div>
              {order.advancePaymentDetails?.transactionId && (
                <div className="mt-2 text-[11px] font-mono-code text-slate-500">
                  TrxID: <span className="text-blue-600 font-bold">{order.advancePaymentDetails.transactionId}</span>
                </div>
              )}
            </div>

            {/* Amount Due on Delivery */}
            <div className="p-4 rounded-xl bg-[#f8fafc] border border-slate-200">
              <span className="text-[11px] font-mono-code text-slate-500 uppercase tracking-wider block">
                Amount Due on Delivery (Cash to Rider)
              </span>
              <div className="mt-1 flex items-baseline justify-between">
                <span className="text-xl font-extrabold font-mono-code text-emerald-700">
                  BDT {(order.pricing?.productAmountDue ?? 0).toLocaleString()}
                </span>
                <span className="text-xs font-mono-code text-slate-700 bg-slate-200 px-2 py-0.5 rounded font-medium">
                  COD on Handover
                </span>
              </div>
              <div className="mt-2 text-[11px] text-slate-500">
                Pay when you receive & inspect your package.
              </div>
            </div>

          </div>

          {/* Ordered Products Itemized */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 font-mono-code mb-2">
              Ordered Items ({order.items.length})
            </h4>
            <div className="rounded-2xl border border-slate-200 divide-y divide-slate-100 overflow-hidden bg-white shadow-xs">
              {order.items.map((item, i) => (
                <div key={i} className="p-3.5 flex items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-[#f8fafc] border border-slate-200/90 p-1.5 shrink-0 flex items-center justify-center overflow-hidden shadow-xs">
                      <img
                        src={item.image || '/sparkzen-logo.png'}
                        alt={item.name}
                        className="w-full h-full object-contain filter drop-shadow-xs"
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          const target = e.currentTarget;
                          if (!target.src.endsWith('/sparkzen-logo.png')) {
                            target.src = '/sparkzen-logo.png';
                          }
                        }}
                      />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900 text-sm leading-snug">{item.name}</p>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        <span className="font-semibold text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded mr-1.5">Qty: {item.quantity}</span>
                        <span>Unit: ৳{(item.price ?? 0).toLocaleString()}</span>
                        {item.sku && <span className="ml-1.5 text-slate-400 font-mono-code">• {item.sku}</span>}
                      </p>
                    </div>
                  </div>
                  <span className="font-bold text-slate-900 text-sm shrink-0">
                    ৳{(item.subtotal ?? ((item.price ?? 0) * (item.quantity ?? 1))).toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Shipping & Recipient Details */}
          <div className="p-4 rounded-xl bg-[#f8fafc] border border-slate-200 text-xs space-y-2">
            <h4 className="font-bold uppercase tracking-wider text-slate-700 font-mono-code">
              Delivery Address & Recipient
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-600">
              <div>
                <span className="text-slate-500">Name:</span> <span className="font-medium text-slate-900">{order.customer.name}</span>
              </div>
              <div>
                <span className="text-slate-500">Phone:</span> <span className="font-mono-code text-blue-600 font-medium">{order.customer.phone}</span>
              </div>
              <div className="sm:col-span-2">
                <span className="text-slate-500">Address:</span> <span className="text-slate-800">{order.customer.address}, {order.customer.city}</span>
              </div>
              {order.customer.notes && (
                <div className="sm:col-span-2">
                  <span className="text-slate-500">Note:</span> <span className="text-slate-700 italic">{order.customer.notes}</span>
                </div>
              )}
            </div>
          </div>

          {/* Actions: WhatsApp confirmation, Print invoice, Close */}
          <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:flex-1 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-colors shadow-xs"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Confirm on WhatsApp Support</span>
            </a>

            <button
              onClick={handlePrint}
              className="w-full sm:w-auto py-3 px-4 rounded-xl bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <Printer className="w-4 h-4 text-blue-600" />
              <span>Print Invoice</span>
            </button>

            <button
              onClick={onClose}
              className="w-full sm:w-auto py-3 px-5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 text-xs font-semibold transition-colors cursor-pointer"
            >
              Continue Shopping
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
