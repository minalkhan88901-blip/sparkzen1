import React from 'react';
import { Phone, Mail, MapPin, MessageCircle, ShieldCheck, ArrowUp, Heart } from 'lucide-react';
import type { StoreSettings } from '../types.js';

interface FooterProps {
  settings: StoreSettings | null;
  onOpenTrack: () => void;
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({ settings, onOpenTrack, onOpenAdmin }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      const y = el.getBoundingClientRect().top + window.pageYOffset - 80;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  const whatsappPhone = (settings?.whatsapp || '+880 1712-345678').replace(/[^0-9]/g, '');

  return (
    <footer id="contact" className="bg-[#f8fafc] border-t border-slate-200 pt-16 pb-12 text-slate-500 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-slate-200">
          
          {/* Col 1: Brand & Logo */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl overflow-hidden border border-slate-200 bg-[#0c101a] p-1.5 shadow-xs flex items-center justify-center">
                <img
                  src="/sparkzen-logo.png"
                  alt="SPARK Zen Logo"
                  className="w-full h-full object-contain"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="flex items-center">
                <span className="font-extrabold text-xl text-slate-900 tracking-tight">SPARK</span>
                <span className="font-extrabold text-xl text-blue-600 tracking-tight ml-1">ZEN</span>
              </div>
            </div>

            <p className="text-slate-600 text-xs sm:text-sm leading-relaxed max-w-sm">
              Your trusted destination for curated tech essentials in Bangladesh. Handpicked items under ৳1,500 with zero product risk and fair Cash on Delivery.
            </p>

            <div className="pt-1 flex flex-wrap items-center gap-2.5">
              <a
                href={`https://wa.me/${whatsappPhone}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-semibold hover:bg-emerald-100 transition-colors shadow-xs"
              >
                <MessageCircle className="w-4 h-4 text-emerald-600" />
                <span>Chat on WhatsApp</span>
              </a>

              <button
                onClick={onOpenTrack}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white text-slate-700 border border-slate-200 text-xs font-semibold hover:border-blue-300 hover:text-blue-600 transition-colors shadow-xs cursor-pointer"
              >
                <span>Track Your Order</span>
              </button>
            </div>
          </div>

          {/* Col 2: Navigation */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
              Quick Links
            </h4>
            <ul className="space-y-2.5 text-slate-600 font-medium text-xs sm:text-sm">
              <li>
                <button onClick={() => scrollToSection('products')} className="hover:text-blue-600 transition-colors cursor-pointer">
                  Featured Products
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('payment-model')} className="hover:text-blue-600 transition-colors cursor-pointer">
                  How COD Works
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('about')} className="hover:text-blue-600 transition-colors cursor-pointer">
                  About SPARK Zen
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('faq')} className="hover:text-blue-600 transition-colors cursor-pointer">
                  Frequently Asked Questions
                </button>
              </li>
              <li>
                <button onClick={onOpenAdmin} className="hover:text-blue-600 transition-colors flex items-center gap-1 cursor-pointer">
                  <span>Merchant Portal</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Delivery & Policies */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
              Delivery & Guarantee
            </h4>
            <ul className="space-y-2.5 text-slate-600 text-xs sm:text-sm">
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-blue-600 shrink-0"></span>
                <span>Inside Dhaka: ৳{settings?.insideDhakaDeliveryCharge || 70} Advance</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-blue-600 shrink-0"></span>
                <span>Outside Dhaka: ৳{settings?.outsideDhakaDeliveryCharge || 130} Advance</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0"></span>
                <span className="font-semibold text-slate-800">Cash on Delivery for Product</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-slate-400 shrink-0"></span>
                <span>7-Day Hassle-Free Replacement</span>
              </li>
            </ul>
          </div>

          {/* Col 4: Contact info */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
              Customer Support
            </h4>
            <div className="space-y-3 text-xs sm:text-sm">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <span className="text-slate-700">{settings?.address || 'Mirpur, Dhaka-1216, Bangladesh'}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-blue-600 shrink-0" />
                <a href={`tel:${settings?.phone || '+8801712345678'}`} className="text-slate-700 hover:text-blue-600 font-semibold">
                  {settings?.phone || '+880 1712-345678'}
                </a>
              </div>
              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-blue-600 shrink-0" />
                <a href={`mailto:${settings?.email || 'support@sparkzen.com'}`} className="text-slate-700 hover:text-blue-600">
                  {settings?.email || 'support@sparkzen.com'}
                </a>
              </div>
              <div className="pt-1 text-xs text-slate-500">
                Support Hours: 10:00 AM – 10:00 PM (Everyday)
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500 text-xs">
          <div>
            &copy; {new Date().getFullYear()} {settings?.storeName || 'SPARK Zen'}. All rights reserved. Curated Tech Store Bangladesh.
          </div>

          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              Made with care for tech enthusiasts
            </span>
            <span>•</span>
            <button
              onClick={scrollToTop}
              className="hover:text-blue-600 font-semibold flex items-center gap-1 transition-colors cursor-pointer"
            >
              <span>Back to top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
