import React from 'react';
import { ArrowRight, ShieldCheck, Zap, Truck, CheckCircle2 } from 'lucide-react';
import type { StoreSettings } from '../types.js';

interface HeroProps {
  settings: StoreSettings | null;
  onShopNow: () => void;
  onExplore: () => void;
}

export const Hero: React.FC<HeroProps> = ({ settings, onShopNow, onExplore }) => {
  const insideFee = settings?.insideDhakaDeliveryCharge || 70;
  const outsideFee = settings?.outsideDhakaDeliveryCharge || 130;

  return (
    <section className="relative overflow-hidden pt-10 pb-16 md:pt-16 md:pb-24 bg-gradient-to-b from-[#f8fafc] via-[#f1f5f9]/50 to-white border-b border-slate-200/80">
      {/* Background soft ambient accents */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[300px] bg-blue-100/50 blur-[100px] pointer-events-none rounded-full" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        {/* Friendly trust badge */}
        <div className="inline-flex items-center justify-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-blue-200/80 text-xs font-semibold text-blue-700 shadow-xs">
            <Zap className="w-3.5 h-3.5 text-blue-600 fill-blue-600/20" />
            <span>Curated Daily Tech Gear • All Under BDT 1,500</span>
          </div>
        </div>

        {/* Friendly Display Headline */}
        <h1 className="mt-6 text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 leading-[1.14]">
          Smart Tech Essentials, <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 via-sky-600 to-cyan-600">
            Delivered Straight to Your Door.
          </span>
        </h1>

        {/* Value Proposition Statement */}
        <p className="mt-5 text-base sm:text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed">
          Order genuine, bench-tested gadgets with total peace of mind. Pay only the courier delivery charge (BDT {insideFee} in Dhaka / BDT {outsideFee} outside) in advance—pay for the product in cash when it arrives at your doorstep.
        </p>

        {/* Action Buttons */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3.5">
          <button
            id="hero-shop-now-btn"
            onClick={onShopNow}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm tracking-normal transition-all shadow-md shadow-blue-600/20 hover:shadow-lg hover:shadow-blue-600/25 active:scale-[0.99] cursor-pointer"
          >
            <span>Explore Featured Products</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={onExplore}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-white hover:bg-slate-50 text-slate-700 hover:text-slate-900 border border-slate-200 hover:border-slate-300 text-sm font-semibold transition-all shadow-xs active:scale-[0.99] cursor-pointer"
          >
            <span>How Cash on Delivery Works</span>
          </button>
        </div>

        {/* Micro value pillars in a friendly grid */}
        <div className="mt-12 grid grid-cols-2 sm:grid-cols-4 gap-3 pt-8 border-t border-slate-200/80 max-w-3xl mx-auto text-left">
          <div className="p-3 rounded-xl bg-white border border-slate-200/70 shadow-xs flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-slate-900 text-xs">Bench Tested</p>
              <p className="text-slate-500 text-[11px]">Inspected prior to dispatch</p>
            </div>
          </div>
          <div className="p-3 rounded-xl bg-white border border-slate-200/70 shadow-xs flex items-start gap-2.5">
            <Truck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-slate-900 text-xs">Fast Courier</p>
              <p className="text-slate-500 text-[11px]">24–72h home delivery</p>
            </div>
          </div>
          <div className="p-3 rounded-xl bg-white border border-slate-200/70 shadow-xs flex items-start gap-2.5">
            <Zap className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-slate-900 text-xs">Cash on Delivery</p>
              <p className="text-slate-500 text-[11px]">Pay gadget price at door</p>
            </div>
          </div>
          <div className="p-3 rounded-xl bg-white border border-slate-200/70 shadow-xs flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-slate-900 text-xs">7-Day Warranty</p>
              <p className="text-slate-500 text-[11px]">Direct replacement guarantee</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
