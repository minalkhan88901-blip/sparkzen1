import React, { useState, useEffect, useRef } from 'react';
import {
  LayoutDashboard,
  Package,
  ShoppingBag,
  Users,
  Settings,
  LogOut,
  Plus,
  Search,
  Filter,
  Download,
  ExternalLink,
  Edit2,
  Trash2,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Truck,
  DollarSign,
  FileSpreadsheet,
  X,
  Save,
  RefreshCw,
  Eye,
  Check,
  Zap,
  PhoneCall,
  Upload,
  Image as ImageIcon,
  Database as DatabaseIcon,
  FileUp,
  Bell,
  Volume2,
  VolumeX
} from 'lucide-react';
import { api } from '../../api.js';
import type {
  Product,
  Order,
  StoreSettings,
  CustomerRecord,
  AdminStats,
  OrderStatus,
  PaymentStatus,
  DeliveryStatus
} from '../../types.js';

// Self-contained Web Audio API chime for new order alerts
function playOrderChime() {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const now = ctx.currentTime;

    // First tone (D5 - 587.33Hz)
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, now);
    gain1.gain.setValueAtTime(0.12, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.28);

    // Second tone (A5 - 880Hz)
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(880, now + 0.12);
    gain2.gain.setValueAtTime(0.16, now + 0.12);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.55);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(now + 0.12);
    osc2.stop(now + 0.55);
  } catch {
    // Gracefully handle any browser autoplay restrictions
  }
}

interface AdminDashboardProps {
  adminUser: { username: string; role: string };
  onLogout: () => void;
  onViewStore: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  adminUser,
  onLogout,
  onViewStore
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'orders' | 'products' | 'customers' | 'inventory' | 'settings'>('overview');
  
  // Data states
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [customers, setCustomers] = useState<CustomerRecord[]>([]);
  const [settings, setSettings] = useState<StoreSettings | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [toastMessage, setToastMessage] = useState('');

  // Orders Filters
  const [orderSearch, setOrderSearch] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState('');
  const [paymentStatusFilter, setPaymentStatusFilter] = useState('');

  // Selected Order Modal
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isSavingOrder, setIsSavingOrder] = useState(false);

  // Product Modals
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);

  // Password Change
  const [newPassword, setNewPassword] = useState('');
  const [passwordStatus, setPasswordStatus] = useState('');

  // Image Upload & Storage UX
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [imageUploadError, setImageUploadError] = useState<string | null>(null);
  const [showImageUrlInput, setShowImageUrlInput] = useState(false);

  // Backup & Recovery state
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);

  // Real-Time New Order Alert & Background Polling State
  const [newOrderAlert, setNewOrderAlert] = useState<Order | null>(null);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    return localStorage.getItem('sparkzen_admin_sound') !== 'false';
  });
  const [lastSyncTime, setLastSyncTime] = useState<Date>(new Date());
  const knownOrderIdsRef = useRef<Set<string>>(new Set());
  const isInitialLoadDoneRef = useRef<boolean>(false);
  const isPollingRef = useRef<boolean>(false);

  const toggleSound = () => {
    setSoundEnabled(prev => {
      const next = !prev;
      localStorage.setItem('sparkzen_admin_sound', next ? 'true' : 'false');
      return next;
    });
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 3500);
  };

  const loadAllData = async (isBackground = false) => {
    if (isBackground && isPollingRef.current) return;
    if (isBackground) isPollingRef.current = true;
    else setIsLoading(true);

    try {
      const [statsData, ordersData, productsData, customersData, settingsData] = await Promise.all([
        api.getAdminStats(),
        api.getAdminOrders(),
        api.getAdminProducts(),
        api.getAdminCustomers(),
        api.getAdminSettings()
      ]);

      // Check for incoming new orders during live background sync
      if (isInitialLoadDoneRef.current && ordersData.length > 0) {
        const newlyArrivedOrders = ordersData.filter(o => !knownOrderIdsRef.current.has(o.id));
        if (newlyArrivedOrders.length > 0) {
          const newest = newlyArrivedOrders[0];
          setNewOrderAlert(newest);
          if (soundEnabled) {
            playOrderChime();
          }
          showToast(`🔔 New Order Arrived: #${newest.id} by ${newest.customer.name}!`);
        }
      }

      // Update known order IDs cache
      const idSet = new Set(ordersData.map(o => o.id));
      knownOrderIdsRef.current = idSet;
      isInitialLoadDoneRef.current = true;

      setStats(statsData.stats);
      setOrders(ordersData);
      setProducts(productsData);
      setCustomers(customersData);
      setSettings(settingsData);
      setLastSyncTime(new Date());

      // Update document title with pending/new order indicator
      if (statsData.stats.newOrders > 0) {
        document.title = `(${statsData.stats.newOrders} New) SPARK Zen - Admin`;
      } else {
        document.title = 'SPARK Zen - Admin Panel';
      }
    } catch (err: any) {
      if (!isBackground) {
        console.error(err);
        showToast('Error loading data: ' + err.message);
      }
    } finally {
      if (isBackground) isPollingRef.current = false;
      else setIsLoading(false);
    }
  };

  useEffect(() => {
    loadAllData();

    // Auto-refresh background polling every 10 seconds
    const interval = setInterval(() => {
      loadAllData(true);
    }, 10000);

    return () => clearInterval(interval);
  }, [soundEnabled]);

  // Filtered orders
  const filteredOrders = orders.filter(order => {
    if (orderStatusFilter && order.orderStatus !== orderStatusFilter) return false;
    if (paymentStatusFilter && order.paymentStatus !== paymentStatusFilter) return false;
    if (orderSearch) {
      const q = orderSearch.toLowerCase();
      const matchId = order.id.toLowerCase().includes(q);
      const matchName = order.customer.name.toLowerCase().includes(q);
      const matchPhone = order.customer.phone.includes(q);
      const matchTracking = order.courier.trackingId?.toLowerCase().includes(q);
      if (!matchId && !matchName && !matchPhone && !matchTracking) return false;
    }
    return true;
  });

  // Handle Order Status Update
  const handleUpdateOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedOrder) return;

    try {
      setIsSavingOrder(true);
      const updated = await api.updateOrder(selectedOrder.id, {
        orderStatus: selectedOrder.orderStatus,
        paymentStatus: selectedOrder.paymentStatus,
        deliveryStatus: selectedOrder.deliveryStatus,
        courier: selectedOrder.courier,
        adminNotes: selectedOrder.adminNotes,
        advancePaymentDetails: selectedOrder.advancePaymentDetails
      });

      setOrders(orders.map(o => o.id === updated.id ? updated : o));
      setSelectedOrder(null);
      showToast(`Order ${updated.id} successfully updated!`);
      // Reload stats
      const statsData = await api.getAdminStats();
      setStats(statsData.stats);
    } catch (err: any) {
      showToast('Update failed: ' + err.message);
    } finally {
      setIsSavingOrder(false);
    }
  };

  // 1-Click Sync to Google Sheets
  const handleSyncToSheets = async (orderId: string) => {
    try {
      showToast('Triggering Google Sheets sync...');
      const res = await api.syncOrderSheets(orderId);
      showToast(res.message);
      // Reload order
      const updated = await api.getOrder(orderId);
      setOrders(orders.map(o => o.id === orderId ? updated : o));
      if (selectedOrder?.id === orderId) {
        setSelectedOrder(updated);
      }
    } catch (err: any) {
      showToast('Sync error: ' + err.message);
    }
  };

  // Export CSV for Google Sheets
  const handleExportCSV = () => {
    const token = localStorage.getItem('sparkzen_admin_token') || '';
    const a = document.createElement('a');
    a.href = `/api/admin/orders/export-csv?token=${encodeURIComponent(token)}`;
    a.download = `sparkzen-orders-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  // Product Save (Add or Edit)
  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;

    try {
      if (editingProduct.id) {
        // Update
        const updated = await api.updateProduct(editingProduct.id, editingProduct);
        setProducts(products.map(p => p.id === updated.id ? updated : p));
        showToast('Product updated successfully!');
      } else {
        // Create
        const created = await api.addProduct(editingProduct);
        setProducts([...products, created]);
        showToast('Product created successfully!');
      }
      setIsProductModalOpen(false);
      setEditingProduct(null);
    } catch (err: any) {
      showToast('Error saving product: ' + err.message);
    }
  };

  // Delete Product
  const handleDeleteProduct = async (id: string, name: string) => {
    if (!window.confirm(`Are you sure you want to delete "${name}"?`)) return;
    try {
      await api.deleteProduct(id);
      setProducts(products.filter(p => p.id !== id));
      showToast('Product deleted');
    } catch (err: any) {
      showToast('Failed to delete: ' + err.message);
    }
  };

  // Quick Stock update
  const handleQuickStockChange = async (product: Product, delta: number) => {
    const newStock = Math.max(0, product.stockQuantity + delta);
    try {
      const updated = await api.updateProduct(product.id, { stockQuantity: newStock });
      setProducts(products.map(p => p.id === updated.id ? updated : p));
      showToast(`${product.name} stock updated to ${newStock}`);
    } catch (err: any) {
      showToast('Failed stock update: ' + err.message);
    }
  };

  // Save Settings
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;

    try {
      const updated = await api.updateAdminSettings(settings);
      setSettings(updated);
      showToast('Store settings saved successfully!');
    } catch (err: any) {
      showToast('Failed to save settings: ' + err.message);
    }
  };

  // Change Password
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword.trim() || newPassword.length < 6) {
      setPasswordStatus('Password must be at least 6 characters.');
      return;
    }

    try {
      await api.changeAdminPassword(newPassword.trim());
      setNewPassword('');
      setPasswordStatus('Password successfully updated!');
      showToast('Admin password changed successfully');
    } catch (err: any) {
      setPasswordStatus('Failed: ' + err.message);
    }
  };

  // Upload Product Image with Validation
  const handleImageFileSelected = async (file: File) => {
    setImageUploadError(null);
    setIsUploadingImage(true);
    try {
      const res = await api.uploadProductImage(file);
      if (editingProduct) {
        setEditingProduct({
          ...editingProduct,
          images: [res.url, ...(editingProduct.images || []).filter(img => img !== res.url)]
        });
      }
      showToast('Product image uploaded successfully!');
    } catch (err: any) {
      setImageUploadError(err.message || 'Image upload failed');
    } finally {
      setIsUploadingImage(false);
    }
  };

  // Toggle Active / Disabled Status for Product
  const handleToggleProductStatus = async (product: Product) => {
    const newStatus = product.status === 'active' ? 'disabled' : 'active';
    try {
      const updated = await api.updateProduct(product.id, { status: newStatus });
      setProducts(products.map(p => p.id === updated.id ? updated : p));
      showToast(`Product "${product.name}" is now ${newStatus}`);
    } catch (err: any) {
      showToast('Failed to update product status: ' + err.message);
    }
  };

  // Download Database JSON Backup
  const handleDownloadBackup = async () => {
    try {
      setIsBackingUp(true);
      const backup = await api.getDatabaseBackup();
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `sparkzen-database-backup-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showToast('Database backup downloaded successfully!');
    } catch (err: any) {
      showToast('Backup export failed: ' + err.message);
    } finally {
      setIsBackingUp(false);
    }
  };

  // Restore Database Backup from File
  const handleRestoreBackupFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!window.confirm('WARNING: Restoring from a backup file will overwrite all existing products, orders, and store settings with the uploaded snapshot. Are you sure you want to proceed?')) {
      e.target.value = '';
      return;
    }
    try {
      setIsRestoring(true);
      const text = await file.text();
      const json = JSON.parse(text);
      await api.restoreDatabaseBackup(json);
      showToast('Database successfully restored!');
      await loadAllData();
    } catch (err: any) {
      showToast('Restore failed: ' + err.message);
    } finally {
      setIsRestoring(false);
      e.target.value = '';
    }
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-800 flex flex-col font-sans">
      
      {/* Admin Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 px-4 py-3 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs font-mono-code shadow-2xl animate-in slide-in-from-bottom-2">
          {toastMessage}
        </div>
      )}

      {/* Floating Real-Time New Order Alert Banner */}
      {newOrderAlert && (
        <div className="fixed top-20 right-4 sm:right-6 z-50 max-w-sm w-full bg-white border-2 border-blue-500 rounded-2xl p-4 shadow-2xl shadow-blue-500/20 animate-in slide-in-from-top-3">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center shrink-0">
                <Bell className="w-4 h-4 animate-bounce" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700 font-mono-code">
                    New Order Received!
                  </span>
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                </div>
                <div className="text-xs font-extrabold text-slate-900 mt-0.5">
                  #{newOrderAlert.id}
                </div>
              </div>
            </div>

            <button
              onClick={() => setNewOrderAlert(null)}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
              title="Dismiss"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="mt-2.5 pt-2.5 border-t border-slate-100 text-xs text-slate-600 space-y-1">
            <div className="flex justify-between">
              <span className="text-slate-500">Customer:</span>
              <span className="font-semibold text-slate-900">{newOrderAlert.customer.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">City / Zone:</span>
              <span className="font-semibold text-slate-900">{newOrderAlert.customer.city}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Total Value:</span>
              <span className="font-bold text-blue-700 font-mono-code">BDT {(newOrderAlert.pricing?.totalOrderValue ?? 0).toLocaleString()}</span>
            </div>
          </div>

          <div className="mt-3 flex items-center gap-2">
            <button
              onClick={() => {
                setActiveTab('orders');
                setSelectedOrder(newOrderAlert);
                setNewOrderAlert(null);
              }}
              className="flex-1 py-1.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Inspect Order</span>
            </button>
            <button
              onClick={() => setNewOrderAlert(null)}
              className="py-1.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition-colors cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* Top Navbar */}
      <header className="sticky top-0 z-30 h-16 bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg overflow-hidden border border-slate-200 bg-[#0b0f19] p-0.5 shadow-xs">
            <img src="/sparkzen-logo.png" alt="Logo" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-sm text-slate-900 tracking-wider font-display">SPARK ZEN</span>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-mono-code uppercase bg-blue-50 text-blue-700 border border-blue-200">
                Admin Panel
              </span>
            </div>
            <div className="flex items-center gap-2 text-[10px] text-slate-500 font-mono-code">
              <span>Signed in as {adminUser.username}</span>
              <span className="hidden lg:inline text-slate-300">•</span>
              <span className="hidden lg:inline-flex items-center gap-1 text-emerald-600" title={`Auto-syncing every 10s. Last synced: ${lastSyncTime.toLocaleTimeString()}`}>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>Live Sync</span>
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Notification Bell with Unread / New Orders Count */}
          <button
            onClick={() => {
              setActiveTab('orders');
              setOrderStatusFilter('new');
            }}
            className="relative p-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition-colors cursor-pointer"
            title={`${stats?.newOrders || 0} New Orders pending review`}
          >
            <Bell className="w-3.5 h-3.5" />
            {Boolean(stats?.newOrders && stats.newOrders > 0) && (
              <span className="absolute -top-1 -right-1 px-1 min-w-[16px] h-4 rounded-full bg-blue-600 text-white text-[9px] font-bold font-mono-code flex items-center justify-center animate-pulse">
                {stats?.newOrders}
              </span>
            )}
          </button>

          {/* Sound Alert Toggle */}
          <button
            onClick={toggleSound}
            className={`p-2 rounded-lg border transition-colors cursor-pointer ${
              soundEnabled
                ? 'bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100'
                : 'bg-slate-100 text-slate-400 border-slate-200 hover:bg-slate-200'
            }`}
            title={soundEnabled ? 'Order Alert Sound: Enabled' : 'Order Alert Sound: Muted'}
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
          </button>

          <button
            onClick={onViewStore}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold border border-slate-200 transition-colors cursor-pointer"
          >
            <ExternalLink className="w-3.5 h-3.5 text-blue-600" />
            <span className="hidden sm:inline">Storefront</span>
          </button>

          <button
            onClick={() => loadAllData(false)}
            disabled={isLoading}
            className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 border border-slate-200 transition-colors cursor-pointer"
            title="Refresh Data"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          </button>

          <button
            onClick={onLogout}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold border border-rose-200 transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Logout</span>
          </button>
        </div>
      </header>

      {/* Main Admin Body */}
      <div className="flex-1 flex flex-col md:flex-row">
        
        {/* Sidebar Nav */}
        <aside className="w-full md:w-60 bg-white border-b md:border-b-0 md:border-r border-slate-200 p-2 sm:p-3 flex md:flex-col gap-1 overflow-x-auto md:overflow-visible shrink-0">
          <button
            onClick={() => setActiveTab('overview')}
            className={`flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap md:whitespace-normal shrink-0 md:shrink transition-all cursor-pointer ${
              activeTab === 'overview'
                ? 'bg-blue-50 text-blue-700 border border-blue-200 shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <LayoutDashboard className="w-4 h-4 shrink-0" />
            <span>Overview & KPIs</span>
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`flex items-center justify-between gap-2.5 px-3.5 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap md:whitespace-normal shrink-0 md:shrink transition-all cursor-pointer ${
              activeTab === 'orders'
                ? 'bg-blue-50 text-blue-700 border border-blue-200 shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <ShoppingBag className="w-4 h-4 shrink-0" />
              <span>Orders Dispatch</span>
            </div>
            {stats?.newOrders ? (
              <span className="px-1.5 py-0.5 text-[10px] font-mono-code font-bold bg-blue-600 text-white rounded-full">
                {stats.newOrders}
              </span>
            ) : null}
          </button>

          <button
            onClick={() => setActiveTab('products')}
            className={`flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap md:whitespace-normal shrink-0 md:shrink transition-all cursor-pointer ${
              activeTab === 'products'
                ? 'bg-blue-50 text-blue-700 border border-blue-200 shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <Package className="w-4 h-4 shrink-0" />
            <span>Product Catalog</span>
          </button>

          <button
            onClick={() => setActiveTab('inventory')}
            className={`flex items-center justify-between gap-2.5 px-3.5 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap md:whitespace-normal shrink-0 md:shrink transition-all cursor-pointer ${
              activeTab === 'inventory'
                ? 'bg-blue-50 text-blue-700 border border-blue-200 shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>Inventory Stock</span>
            </div>
            {stats?.lowStockProducts ? (
              <span className="px-1.5 py-0.5 text-[10px] font-mono-code font-bold bg-amber-500 text-white rounded-full">
                {stats.lowStockProducts}
              </span>
            ) : null}
          </button>

          <button
            onClick={() => setActiveTab('customers')}
            className={`flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap md:whitespace-normal shrink-0 md:shrink transition-all cursor-pointer ${
              activeTab === 'customers'
                ? 'bg-blue-50 text-blue-700 border border-blue-200 shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <Users className="w-4 h-4 shrink-0" />
            <span>Customer Base</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap md:whitespace-normal shrink-0 md:shrink transition-all cursor-pointer ${
              activeTab === 'settings'
                ? 'bg-blue-50 text-blue-700 border border-blue-200 shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <Settings className="w-4 h-4 shrink-0" />
            <span>Store & Sync Config</span>
          </button>
        </aside>

        {/* Content Area */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto max-w-7xl">
          
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && stats && (
            <div className="space-y-6">
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl font-extrabold text-slate-900">Store Overview & Performance</h2>
                  <p className="text-xs text-slate-500 mt-0.5">Real-time metrics for SPARK Zen operations</p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleExportCSV}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 text-xs font-semibold transition-colors shadow-xs cursor-pointer"
                  >
                    <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                    <span>Download Orders CSV</span>
                  </button>
                </div>
              </div>

              {/* KPI Cards Grid */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs">
                  <span className="text-[11px] font-mono-code text-slate-500 block uppercase">Total Sales Value</span>
                  <div className="text-2xl font-black text-slate-900 font-mono-code mt-1">
                    BDT {(stats.totalSales ?? 0).toLocaleString()}
                  </div>
                  <span className="text-[10px] text-slate-500 mt-1 block">From {stats.totalOrders} total orders</span>
                </div>

                <div className="p-5 rounded-2xl bg-blue-50/50 border border-blue-200 shadow-xs">
                  <span className="text-[11px] font-mono-code text-blue-700 block uppercase font-bold">Advance Collected</span>
                  <div className="text-2xl font-black text-blue-700 font-mono-code mt-1">
                    BDT {(stats.deliveryChargesCollected ?? stats.amountCollected ?? 0).toLocaleString()}
                  </div>
                  <span className="text-[10px] text-blue-600/80 mt-1 block">Non-refundable courier fees</span>
                </div>

                <div className="p-5 rounded-2xl bg-emerald-50/40 border border-emerald-200 shadow-xs">
                  <span className="text-[11px] font-mono-code text-emerald-700 block uppercase font-bold">Outstanding COD Due</span>
                  <div className="text-2xl font-black text-emerald-700 font-mono-code mt-1">
                    BDT {(stats.outstandingProductDue ?? stats.amountDue ?? 0).toLocaleString()}
                  </div>
                  <span className="text-[10px] text-slate-500 mt-1 block">Payable to riders on delivery</span>
                </div>

                <div className="p-5 rounded-2xl bg-amber-50/40 border border-amber-200 shadow-xs">
                  <span className="text-[11px] font-mono-code text-amber-700 block uppercase font-bold">New / Pending Orders</span>
                  <div className="text-2xl font-black text-amber-600 font-mono-code mt-1">
                    {stats.newOrders}
                  </div>
                  <span className="text-[10px] text-slate-500 mt-1 block">Requires dispatch confirmation</span>
                </div>
              </div>

              {/* Order Status Breakdown */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                <div className="p-3.5 rounded-xl bg-white border border-slate-200 text-center shadow-xs">
                  <span className="text-xs text-slate-500 block">Confirmed</span>
                  <span className="text-lg font-bold text-slate-900 font-mono-code">{stats.confirmedOrders}</span>
                </div>
                <div className="p-3.5 rounded-xl bg-white border border-slate-200 text-center shadow-xs">
                  <span className="text-xs text-slate-500 block">Processing</span>
                  <span className="text-lg font-bold text-blue-600 font-mono-code">{stats.processingOrders}</span>
                </div>
                <div className="p-3.5 rounded-xl bg-white border border-slate-200 text-center shadow-xs">
                  <span className="text-xs text-slate-500 block">Shipped</span>
                  <span className="text-lg font-bold text-cyan-600 font-mono-code">{stats.shippedOrders}</span>
                </div>
                <div className="p-3.5 rounded-xl bg-white border border-slate-200 text-center shadow-xs">
                  <span className="text-xs text-slate-500 block">Delivered</span>
                  <span className="text-lg font-bold text-emerald-600 font-mono-code">{stats.deliveredOrders}</span>
                </div>
                <div className="p-3.5 rounded-xl bg-white border border-slate-200 text-center shadow-xs">
                  <span className="text-xs text-slate-500 block">Cancelled</span>
                  <span className="text-lg font-bold text-rose-600 font-mono-code">{stats.cancelledOrders}</span>
                </div>
              </div>

              {/* Recent Orders Preview */}
              <div className="rounded-2xl bg-white border border-slate-200 p-5 space-y-4 shadow-xs">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-900">Recent Customer Orders</h3>
                  <button
                    onClick={() => setActiveTab('orders')}
                    className="text-xs text-blue-600 hover:text-blue-700 font-semibold cursor-pointer"
                  >
                    View All Orders &rarr;
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500 font-mono-code bg-slate-50/80">
                        <th className="p-3">Order ID</th>
                        <th className="p-3">Customer</th>
                        <th className="p-3">Total Value</th>
                        <th className="p-3">Advance Status</th>
                        <th className="p-3">Order Status</th>
                        <th className="p-3 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {orders.slice(0, 5).map(order => (
                        <tr key={order.id} className="hover:bg-slate-50/80">
                          <td className="p-3 font-mono-code font-bold text-blue-600">{order.id}</td>
                          <td className="p-3">
                            <div className="font-semibold text-slate-900">{order.customer.name}</div>
                            <div className="text-[11px] text-slate-500 font-mono-code">{order.customer.phone}</div>
                          </td>
                          <td className="p-3 font-mono-code font-bold text-slate-900">
                            BDT {(order.pricing?.totalOrderValue ?? 0).toLocaleString()}
                          </td>
                          <td className="p-3">
                            <span className="px-2 py-0.5 rounded text-[10px] font-mono-code uppercase bg-slate-100 text-slate-700 border border-slate-200">
                              {order.paymentStatus.replace(/_/g, ' ')}
                            </span>
                          </td>
                          <td className="p-3">
                            <span className="px-2 py-0.5 rounded text-[10px] font-mono-code uppercase bg-blue-50 text-blue-700 border border-blue-200">
                              {order.orderStatus}
                            </span>
                          </td>
                          <td className="p-3 text-right">
                            <button
                              onClick={() => setSelectedOrder(order)}
                              className="px-2.5 py-1 rounded bg-slate-100 hover:bg-blue-50 text-slate-700 hover:text-blue-700 text-xs font-semibold border border-slate-200 transition-colors cursor-pointer"
                            >
                              Inspect
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: ORDERS MANAGEMENT */}
          {activeTab === 'orders' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl font-extrabold text-slate-900">Orders & Dispatch Management</h2>
                  <p className="text-xs text-slate-500 mt-0.5">Manage customer orders, advance verification, and courier tracking</p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleExportCSV}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 text-xs font-semibold transition-colors shadow-xs cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5 text-blue-600" />
                    <span>Export CSV</span>
                  </button>
                </div>
              </div>

              {/* Search & Filters */}
              <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="relative">
                  <input
                    type="text"
                    value={orderSearch}
                    onChange={(e) => setOrderSearch(e.target.value)}
                    placeholder="Search by ID, name, phone, tracking..."
                    className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-600 focus:bg-white"
                  />
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                </div>

                <div>
                  <select
                    value={orderStatusFilter}
                    onChange={(e) => setOrderStatusFilter(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white"
                  >
                    <option value="">All Order Statuses</option>
                    <option value="new">New</option>
                    <option value="confirmed">Confirmed</option>
                    <option value="processing">Processing</option>
                    <option value="shipped">Shipped</option>
                    <option value="delivered">Delivered</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>

                <div>
                  <select
                    value={paymentStatusFilter}
                    onChange={(e) => setPaymentStatusFilter(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white"
                  >
                    <option value="">All Payment Statuses</option>
                    <option value="delivery_charge_pending">Delivery Charge Pending</option>
                    <option value="delivery_charge_paid">Delivery Charge Paid</option>
                    <option value="product_amount_due">Product Amount Due</option>
                    <option value="fully_paid">Fully Paid</option>
                    <option value="refunded">Refunded</option>
                  </select>
                </div>
              </div>

              {/* Orders Table */}
              <div className="rounded-2xl bg-white border border-slate-200 overflow-hidden shadow-xs">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-mono-code">
                        <th className="p-3.5">Order ID & Date</th>
                        <th className="p-3.5">Customer & Area</th>
                        <th className="p-3.5">Items</th>
                        <th className="p-3.5">Payment Details</th>
                        <th className="p-3.5">Courier & Status</th>
                        <th className="p-3.5 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredOrders.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="p-8 text-center text-slate-400">
                            No orders found matching criteria.
                          </td>
                        </tr>
                      ) : (
                        filteredOrders.map(order => (
                          <tr key={order.id} className="hover:bg-slate-50/70 transition-colors">
                            <td className="p-3.5">
                              <span className="font-mono-code font-bold text-blue-600 block">{order.id}</span>
                              <span className="text-[10px] text-slate-400 font-mono-code">
                                {new Date(order.createdAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </td>

                            <td className="p-3.5">
                              <div className="font-semibold text-slate-900">{order.customer.name}</div>
                              <div className="text-[11px] font-mono-code text-blue-600">{order.customer.phone}</div>
                              <div className="text-[10px] text-slate-500 truncate max-w-xs">{order.customer.city} ({order.customer.location === 'inside_dhaka' ? 'Inside' : 'Outside'})</div>
                            </td>

                            <td className="p-3.5">
                              <span className="font-mono-code font-bold text-slate-800">{order.items.length} item(s)</span>
                              <div className="text-[10px] text-slate-500 truncate max-w-[180px]">
                                {order.items.map(i => `${i.name} (x${i.quantity})`).join(', ')}
                              </div>
                            </td>

                             <td className="p-3.5">
                              <div className="font-mono-code text-slate-900">
                                Total: <strong>BDT {(order.pricing?.totalOrderValue ?? 0).toLocaleString()}</strong>
                              </div>
                              <div className="text-[10px] font-mono-code text-blue-600">
                                Adv: BDT {order.pricing?.advanceDeliveryPaid ?? 0} ({order.paymentStatus === 'delivery_charge_paid' ? 'Paid' : 'Pending'})
                              </div>
                              <div className="text-[10px] font-mono-code text-emerald-600">
                                Due: BDT {(order.pricing?.productAmountDue ?? 0).toLocaleString()} (COD)
                              </div>
                            </td>

                            <td className="p-3.5">
                              <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-mono-code uppercase font-semibold ${
                                order.orderStatus === 'delivered' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                                order.orderStatus === 'cancelled' ? 'bg-rose-50 text-rose-700 border border-rose-200' :
                                'bg-blue-50 text-blue-700 border border-blue-200'
                              }`}>
                                {order.orderStatus}
                              </span>
                              <div className="text-[10px] text-slate-500 mt-1">
                                {order.courier.name} {order.courier.trackingId ? `• ${order.courier.trackingId}` : ''}
                              </div>
                            </td>

                            <td className="p-3.5 text-right space-x-2">
                              <button
                                onClick={() => setSelectedOrder(order)}
                                className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-blue-50 text-slate-700 hover:text-blue-700 text-xs font-semibold border border-slate-200 transition-colors cursor-pointer"
                              >
                                Edit / View
                              </button>
                              <button
                                onClick={() => handleSyncToSheets(order.id)}
                                className="px-2 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 text-xs font-mono-code transition-colors cursor-pointer"
                                title="Sync to Google Sheets"
                              >
                                Sync
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: PRODUCT CATALOG */}
          {activeTab === 'products' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl font-extrabold text-slate-900">Product Catalog</h2>
                  <p className="text-xs text-slate-500 mt-0.5">Manage the 3–5 curated tech items for SPARK Zen</p>
                </div>

                <button
                  onClick={() => {
                    setEditingProduct({
                      name: '',
                      sku: `SZ-TECH-${Math.floor(100 + Math.random() * 900)}`,
                      price: 950,
                      discountPrice: 1250,
                      stockQuantity: 20,
                      category: 'Audio',
                      badge: 'New Arrival',
                      shortDescription: '',
                      description: '',
                      images: ['/images/earbuds.png'],
                      specifications: [
                        { key: 'Latency', value: '38ms' },
                        { key: 'Warranty', value: '7-Day Replacement' }
                      ],
                      status: 'active',
                      featured: false
                    });
                    setIsProductModalOpen(true);
                  }}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition-colors shadow-xs cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add New Product</span>
                </button>
              </div>

              {/* Product Cards Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {products.map(product => (
                  <div key={product.id} className="rounded-2xl bg-white border border-slate-200 p-5 flex flex-col justify-between space-y-4 shadow-xs">
                    <div className="flex gap-4 items-start">
                      <div className="w-16 h-16 rounded-xl bg-slate-50 border border-slate-200 p-1 shrink-0 flex items-center justify-center">
                        <img src={product.images[0] || '/sparkzen-logo.png'} alt="" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-mono-code uppercase text-blue-600 font-semibold">{product.category}</span>
                          <span className="text-[10px] font-mono-code text-slate-400">{product.sku}</span>
                        </div>
                        <h4 className="font-bold text-slate-900 text-sm truncate mt-0.5">{product.name}</h4>
                        <div className="flex items-baseline gap-2 mt-1">
                          <span className="font-mono-code font-extrabold text-slate-900 text-base">BDT {(product.price ?? 0).toLocaleString()}</span>
                          {product.discountPrice != null && (
                            <span className="font-mono-code text-slate-400 line-through text-xs">BDT {(product.discountPrice ?? 0).toLocaleString()}</span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Stock status indicator & Quick control */}
                    <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                      <div className="text-xs font-mono-code text-slate-600">
                        Stock: <strong className={product.stockQuantity <= 5 ? 'text-amber-600' : 'text-emerald-600'}>{product.stockQuantity} units</strong>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleQuickStockChange(product, -1)}
                          className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 text-xs font-bold cursor-pointer"
                          title="Decrease Stock by 1"
                        >
                          -1
                        </button>
                        <button
                          onClick={() => handleQuickStockChange(product, 5)}
                          className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-blue-600 border border-slate-200 text-xs font-bold cursor-pointer"
                          title="Add 5 to stock"
                        >
                          +5
                        </button>
                      </div>
                    </div>

                    {/* Actions & Status Toggle */}
                    <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                      <button
                        type="button"
                        onClick={() => handleToggleProductStatus(product)}
                        className={`text-[10px] font-mono-code uppercase px-2.5 py-1 rounded-md border font-semibold cursor-pointer transition-colors ${
                          product.status === 'active'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-300 hover:bg-emerald-100'
                            : 'bg-slate-100 text-slate-600 border-slate-300 hover:bg-slate-200'
                        }`}
                        title="Click to toggle status (Active vs Disabled)"
                      >
                        {product.status === 'active' ? '● Active' : '○ Disabled'}
                      </button>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => {
                            setEditingProduct({ ...product });
                            setIsProductModalOpen(true);
                          }}
                          className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 cursor-pointer"
                          title="Edit"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteProduct(product.id, product.name)}
                          className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 cursor-pointer"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: INVENTORY STOCK */}
          {activeTab === 'inventory' && (
            <div className="space-y-6">
              <h2 className="text-xl font-extrabold text-slate-900">Inventory & Stock Tracking</h2>
              <div className="rounded-2xl bg-white border border-slate-200 p-5 shadow-xs">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500 font-mono-code">
                        <th className="pb-3">Product Name</th>
                        <th className="pb-3">SKU</th>
                        <th className="pb-3">Price</th>
                        <th className="pb-3">Current Stock</th>
                        <th className="pb-3">Stock Condition</th>
                        <th className="pb-3 text-right">Quick Restock</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {products.map(p => (
                        <tr key={p.id} className="hover:bg-slate-50/70">
                          <td className="py-3 font-bold text-slate-900 flex items-center gap-2">
                            <img src={p.images[0]} alt="" className="w-7 h-7 object-contain bg-slate-50 border border-slate-200 rounded p-0.5" />
                            <span>{p.name}</span>
                          </td>
                          <td className="py-3 font-mono-code text-slate-500">{p.sku}</td>
                          <td className="py-3 font-mono-code text-slate-800">BDT {(p.price ?? 0).toLocaleString()}</td>
                          <td className="py-3 font-mono-code font-bold text-slate-900">{p.stockQuantity}</td>
                          <td className="py-3">
                            {p.stockQuantity <= 0 ? (
                              <span className="px-2 py-0.5 rounded text-[10px] font-mono-code uppercase bg-rose-50 text-rose-700 border border-rose-200">
                                Out of stock
                              </span>
                            ) : p.stockQuantity <= 5 ? (
                              <span className="px-2 py-0.5 rounded text-[10px] font-mono-code uppercase bg-amber-50 text-amber-700 border border-amber-200">
                                Low Stock Alert
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded text-[10px] font-mono-code uppercase bg-emerald-50 text-emerald-700 border border-emerald-200">
                                Healthy Stock
                              </span>
                            )}
                          </td>
                          <td className="py-3 text-right space-x-1">
                            <button
                              onClick={() => handleQuickStockChange(p, 5)}
                              className="px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-blue-700 border border-slate-200 font-mono-code font-semibold cursor-pointer"
                            >
                              +5 units
                            </button>
                            <button
                              onClick={() => handleQuickStockChange(p, 20)}
                              className="px-2.5 py-1 rounded bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 font-mono-code font-semibold cursor-pointer"
                            >
                              +20 units
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: CUSTOMER BASE */}
          {activeTab === 'customers' && (
            <div className="space-y-6">
              <h2 className="text-xl font-extrabold text-slate-900">Customer Directory</h2>
              <div className="rounded-2xl bg-white border border-slate-200 p-5 shadow-xs">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500 font-mono-code">
                        <th className="pb-3">Customer Phone</th>
                        <th className="pb-3">Name</th>
                        <th className="pb-3">Area / City</th>
                        <th className="pb-3">Total Orders</th>
                        <th className="pb-3">Total Spent</th>
                        <th className="pb-3">Outstanding COD Due</th>
                        <th className="pb-3">Last Active</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {customers.map(c => (
                        <tr key={c.phone} className="hover:bg-slate-50/70">
                          <td className="py-3 font-mono-code font-bold text-blue-600">{c.phone}</td>
                          <td className="py-3 font-semibold text-slate-900">{c.name}</td>
                          <td className="py-3 text-slate-600">{c.city}</td>
                          <td className="py-3 font-mono-code text-slate-700">{c.ordersCount}</td>
                          <td className="py-3 font-mono-code font-bold text-slate-900">BDT {(c.totalSpent ?? 0).toLocaleString()}</td>
                          <td className="py-3 font-mono-code font-bold text-emerald-700">BDT {(c.outstandingDue ?? 0).toLocaleString()}</td>
                          <td className="py-3 font-mono-code text-slate-500">{c.lastOrderDate ? new Date(c.lastOrderDate).toLocaleDateString() : 'N/A'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: SETTINGS & GOOGLE SHEETS */}
          {activeTab === 'settings' && settings && (
            <div className="space-y-6 max-w-3xl">
              <h2 className="text-xl font-extrabold text-slate-900">Store & Synchronization Settings</h2>

              <form onSubmit={handleSaveSettings} className="space-y-6">
                
                {/* Delivery Fees */}
                <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-blue-700 font-mono-code">
                    1. Advance Delivery Charge Amounts (BDT)
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Inside Dhaka Delivery Fee
                      </label>
                      <input
                        type="number"
                        value={settings.insideDhakaDeliveryCharge}
                        onChange={(e) => setSettings({ ...settings, insideDhakaDeliveryCharge: Number(e.target.value) })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-sm font-mono-code text-slate-900 focus:outline-none focus:border-blue-600 focus:bg-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Outside Dhaka Delivery Fee
                      </label>
                      <input
                        type="number"
                        value={settings.outsideDhakaDeliveryCharge}
                        onChange={(e) => setSettings({ ...settings, outsideDhakaDeliveryCharge: Number(e.target.value) })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-sm font-mono-code text-slate-900 focus:outline-none focus:border-blue-600 focus:bg-white"
                      />
                    </div>
                  </div>
                </div>

                {/* Mobile Banking Accounts */}
                <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-blue-700 font-mono-code">
                    2. bKash / Nagad Advance Payment Accounts
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        bKash Merchant / Personal Number
                      </label>
                      <input
                        type="text"
                        value={settings.advancePaymentMethod?.bkashMerchantNumber || ''}
                        onChange={(e) => setSettings({
                          ...settings,
                          advancePaymentMethod: {
                            ...settings.advancePaymentMethod,
                            bkashMerchantNumber: e.target.value
                          }
                        })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-sm font-mono-code text-slate-900 focus:outline-none focus:border-blue-600 focus:bg-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Nagad Merchant / Personal Number
                      </label>
                      <input
                        type="text"
                        value={settings.advancePaymentMethod?.nagadMerchantNumber || ''}
                        onChange={(e) => setSettings({
                          ...settings,
                          advancePaymentMethod: {
                            ...settings.advancePaymentMethod,
                            nagadMerchantNumber: e.target.value
                          }
                        })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-sm font-mono-code text-slate-900 focus:outline-none focus:border-blue-600 focus:bg-white"
                      />
                    </div>
                  </div>
                </div>

                {/* Google Sheets Webhook Configuration */}
                <div className="p-5 rounded-2xl bg-white border border-emerald-200 shadow-xs space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-700 font-mono-code flex items-center gap-1.5">
                      <FileSpreadsheet className="w-4 h-4" />
                      <span>3. Google Sheets Real-Time Integration</span>
                    </h3>
                    <button
                      type="button"
                      onClick={handleExportCSV}
                      className="text-xs text-blue-600 hover:text-blue-700 font-mono-code flex items-center gap-1 font-semibold cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Backup CSV</span>
                    </button>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Google Apps Script Webhook URL (POST Endpoint)
                    </label>
                    <input
                      type="url"
                      value={settings.googleSheetsWebhookUrl || ''}
                      onChange={(e) => setSettings({ ...settings, googleSheetsWebhookUrl: e.target.value })}
                      placeholder="https://script.google.com/macros/s/AKfycb.../exec"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-mono-code text-slate-900 focus:outline-none focus:border-blue-600 focus:bg-white"
                    />
                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                      Every time an order is created or updated, SPARK Zen posts all 20 columns directly to your Google Sheet. If no webhook URL is configured, you can always download the standardized CSV backup at any time.
                    </p>
                  </div>
                </div>

                {/* Contact info & Announcement */}
                <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-blue-700 font-mono-code">
                    4. Contact Details & Announcement Bar
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Support Phone</label>
                      <input
                        type="text"
                        value={settings.phone || ''}
                        onChange={(e) => setSettings({ ...settings, phone: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 focus:outline-none focus:border-blue-600 focus:bg-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">WhatsApp Hotline</label>
                      <input
                        type="text"
                        value={settings.whatsapp || ''}
                        onChange={(e) => setSettings({ ...settings, whatsapp: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 focus:outline-none focus:border-blue-600 focus:bg-white"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Announcement Banner</label>
                      <input
                        type="text"
                        value={settings.heroAnnouncement || ''}
                        onChange={(e) => setSettings({ ...settings, heroAnnouncement: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 focus:outline-none focus:border-blue-600 focus:bg-white"
                      />
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm transition-colors shadow-xs flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Store Configuration</span>
                </button>
              </form>

              {/* Password Change Box */}
              <div className="pt-6 border-t border-slate-200">
                <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 font-mono-code">
                    Change Admin Password
                  </h3>
                  {passwordStatus && (
                    <div className="text-xs font-mono-code text-blue-600 font-semibold">{passwordStatus}</div>
                  )}
                  <form onSubmit={handleChangePassword} className="flex gap-3">
                    <input
                      type="password"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="Enter new password (min 6 chars)"
                      className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 font-mono-code focus:outline-none focus:border-blue-600 focus:bg-white"
                    />
                    <button
                      type="submit"
                      className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors cursor-pointer"
                    >
                      Update Password
                    </button>
                  </form>
                </div>
              </div>

              {/* Database Backup & Disaster Recovery */}
              <div className="pt-6 border-t border-slate-200">
                <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
                  <div className="flex items-center gap-2">
                    <DatabaseIcon className="w-4 h-4 text-blue-600" />
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 font-mono-code">
                      Database Backup & Disaster Recovery
                    </h3>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Download a complete, offline JSON snapshot of your store's entire state (all products, order history, customer directory, and system settings), or restore from an earlier backup archive.
                  </p>
                  
                  <div className="flex flex-wrap items-center gap-3 pt-2">
                    <button
                      type="button"
                      onClick={handleDownloadBackup}
                      disabled={isBackingUp}
                      className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold font-mono-code transition-colors disabled:opacity-50 cursor-pointer shadow-xs"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>{isBackingUp ? 'Exporting Snapshot...' : 'Download Full Database (.json)'}</span>
                    </button>

                    <label className={`flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold font-mono-code border border-slate-200 transition-colors cursor-pointer shadow-xs ${isRestoring ? 'opacity-50 pointer-events-none' : ''}`}>
                      <FileUp className="w-3.5 h-3.5 text-blue-600" />
                      <span>{isRestoring ? 'Restoring Database...' : 'Restore from Backup File'}</span>
                      <input
                        type="file"
                        accept=".json,application/json"
                        onChange={handleRestoreBackupFile}
                        className="hidden"
                      />
                    </label>
                  </div>
                </div>
              </div>

            </div>
          )}

        </main>
      </div>

      {/* SELECTED ORDER MODAL (Full inspection & status update) */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto bg-slate-900/40 backdrop-blur-xs">
          <div className="relative w-full max-w-3xl bg-white border border-slate-200 rounded-2xl shadow-xl overflow-hidden my-6">
            <div className="p-5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-base font-extrabold text-slate-900 font-mono-code">{selectedOrder.id}</span>
                  <span className="text-xs font-mono-code uppercase px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200">
                    {selectedOrder.orderStatus}
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  Placed on {selectedOrder.createdAt ? new Date(selectedOrder.createdAt).toLocaleString() : 'N/A'}
                </p>
              </div>
              <button
                onClick={() => setSelectedOrder(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUpdateOrder} className="p-5 sm:p-6 space-y-5">
              
              {/* Customer & Address Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                <div>
                  <span className="text-slate-500 block font-mono-code">Customer:</span>
                  <span className="font-bold text-slate-900 text-sm">{selectedOrder.customer.name}</span>
                  <div className="text-blue-600 font-mono-code font-bold mt-0.5">{selectedOrder.customer.phone}</div>
                </div>
                <div>
                  <span className="text-slate-500 block font-mono-code">Destination:</span>
                  <span className="text-slate-800">
                    {selectedOrder.customer.address}, {selectedOrder.customer.city}
                  </span>
                  <div className="text-blue-600 font-mono-code mt-0.5">
                    Zone: {selectedOrder.customer.location === 'inside_dhaka' ? 'Inside Dhaka (BDT 70)' : 'Outside Dhaka (BDT 130)'}
                  </div>
                </div>
                {selectedOrder.customer.notes && (
                  <div className="sm:col-span-2 text-slate-600 italic">
                    Note: "{selectedOrder.customer.notes}"
                  </div>
                )}
              </div>

              {/* Financial & Items */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-3">
                <div>
                  <span className="font-bold text-slate-700 block mb-2 font-mono-code">
                    Ordered Items ({selectedOrder.items.length}):
                  </span>
                  <div className="rounded-xl border border-slate-200 divide-y divide-slate-100 overflow-hidden bg-white">
                    {selectedOrder.items.map((item, idx) => (
                      <div key={idx} className="p-2.5 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-xl bg-slate-50 border border-slate-200 p-1 shrink-0 flex items-center justify-center overflow-hidden">
                            <img
                              src={item.image || '/sparkzen-logo.png'}
                              alt={item.name}
                              className="w-full h-full object-contain"
                              referrerPolicy="no-referrer"
                              onError={(e) => {
                                const target = e.currentTarget;
                                if (!target.src.endsWith('/sparkzen-logo.png')) {
                                  target.src = '/sparkzen-logo.png';
                                }
                              }}
                            />
                          </div>
                          <div>
                            <div className="font-bold text-slate-900">{item.name}</div>
                            <div className="text-[11px] text-slate-500 font-mono-code">
                              SKU: {item.sku} • Qty: {item.quantity} • Unit: ৳{(item.price ?? 0).toLocaleString()}
                            </div>
                          </div>
                        </div>
                        <div className="font-bold text-slate-900 font-mono-code text-right shrink-0">
                          ৳{(item.subtotal ?? ((item.price ?? 0) * (item.quantity ?? 1))).toLocaleString()}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-200 space-y-1.5">
                  <div className="flex justify-between text-slate-700">
                    <span>Total Order Value:</span>
                    <span className="font-mono-code font-bold text-slate-900">৳{(selectedOrder.pricing?.totalOrderValue ?? 0).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-blue-700 font-semibold">
                    <span>Advance Delivery Charge:</span>
                    <span className="font-mono-code">৳{selectedOrder.pricing?.advanceDeliveryPaid ?? 0}</span>
                  </div>
                  <div className="flex justify-between text-emerald-700 font-bold">
                    <span>Remaining Product Amount Due (COD):</span>
                    <span className="font-mono-code">৳{(selectedOrder.pricing?.productAmountDue ?? 0).toLocaleString()}</span>
                  </div>
                </div>
              </div>

              {/* Status Selectors */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Order Status</label>
                  <select
                    value={selectedOrder.orderStatus}
                    onChange={(e) => setSelectedOrder({ ...selectedOrder, orderStatus: e.target.value as OrderStatus })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white"
                  >
                    <option value="new">New</option>
                    <option value="confirmed">Confirmed</option>
                    <option value="processing">Processing</option>
                    <option value="shipped">Shipped</option>
                    <option value="delivered">Delivered</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Payment Status</label>
                  <select
                    value={selectedOrder.paymentStatus}
                    onChange={(e) => setSelectedOrder({ ...selectedOrder, paymentStatus: e.target.value as PaymentStatus })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white"
                  >
                    <option value="delivery_charge_pending">Delivery Charge Pending</option>
                    <option value="delivery_charge_paid">Delivery Charge Paid</option>
                    <option value="product_amount_due">Product Amount Due</option>
                    <option value="fully_paid">Fully Paid</option>
                    <option value="refunded">Refunded</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Delivery Status</label>
                  <select
                    value={selectedOrder.deliveryStatus}
                    onChange={(e) => setSelectedOrder({ ...selectedOrder, deliveryStatus: e.target.value as DeliveryStatus })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white"
                  >
                    <option value="pending">Pending</option>
                    <option value="booked">Booked</option>
                    <option value="in_transit">In Transit</option>
                    <option value="delivered">Delivered</option>
                    <option value="returned">Returned</option>
                  </select>
                </div>
              </div>

              {/* Courier Assignment */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Courier Partner</label>
                  <input
                    type="text"
                    value={selectedOrder.courier.name}
                    onChange={(e) => setSelectedOrder({
                      ...selectedOrder,
                      courier: { ...selectedOrder.courier, name: e.target.value }
                    })}
                    placeholder="e.g. Steadfast / Pathao / RedX"
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Courier Tracking ID</label>
                  <input
                    type="text"
                    value={selectedOrder.courier.trackingId || ''}
                    onChange={(e) => setSelectedOrder({
                      ...selectedOrder,
                      courier: { ...selectedOrder.courier, trackingId: e.target.value }
                    })}
                    placeholder="e.g. SF-9812498"
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 font-mono-code focus:outline-none focus:border-blue-600 focus:bg-white"
                  />
                </div>
              </div>

              {/* Advance Payment Details Check */}
              <div className="p-3.5 rounded-xl bg-blue-50/50 border border-blue-200 text-xs space-y-2">
                <span className="font-bold text-blue-700 font-mono-code uppercase block">
                  Advance Payment Information
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <div>
                    <span className="text-slate-500 block">Method:</span>
                    <span className="text-slate-800 uppercase font-mono-code font-semibold">
                      {selectedOrder.advancePaymentDetails?.method || 'Pending'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">TrxID:</span>
                    <span className="text-blue-700 font-mono-code font-bold">
                      {selectedOrder.advancePaymentDetails?.transactionId || 'None provided yet'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Sender Phone:</span>
                    <span className="text-slate-800 font-mono-code">
                      {selectedOrder.advancePaymentDetails?.senderNumber || selectedOrder.customer.phone}
                    </span>
                  </div>
                </div>
                {(selectedOrder.advancePaymentDetails as any)?.verifiedBy && (
                  <div className="mt-2 text-[11px] text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg px-2.5 py-1.5 font-mono-code flex items-center justify-between">
                    <span>✅ SMS Verified (bKash Webhook)</span>
                    <span className="text-[10px] text-emerald-600">
                      Amount: ৳{(selectedOrder.advancePaymentDetails as any).verifiedAmount || selectedOrder.pricing.advanceDeliveryPaid}
                    </span>
                  </div>
                )}
              </div>

              {/* Admin Private Notes */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Admin Internal Notes</label>
                <textarea
                  rows={2}
                  value={selectedOrder.adminNotes || ''}
                  onChange={(e) => setSelectedOrder({ ...selectedOrder, adminNotes: e.target.value })}
                  placeholder="e.g. Verified BDT 70 via bKash statement. Booked on Steadfast 11 AM."
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white"
                />
              </div>

              {/* Submit & Sync buttons */}
              <div className="flex items-center justify-between pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => handleSyncToSheets(selectedOrder.id)}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 text-xs font-mono-code cursor-pointer font-semibold"
                >
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>Push to Google Sheets</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedOrder(null)}
                    className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSavingOrder}
                    className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition-colors disabled:opacity-50 shadow-xs cursor-pointer"
                  >
                    {isSavingOrder ? 'Saving...' : 'Save Order Changes'}
                  </button>
                </div>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* PRODUCT CREATE / EDIT MODAL */}
      {isProductModalOpen && editingProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto bg-slate-900/40 backdrop-blur-xs">
          <div className="relative w-full max-w-2xl bg-white border border-slate-200 rounded-2xl shadow-xl overflow-hidden my-6">
            <div className="p-5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">
                {editingProduct.id ? `Edit Product: ${editingProduct.name}` : 'Add New Tech Product'}
              </h3>
              <button
                onClick={() => setIsProductModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="p-5 sm:p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Product Title</label>
                  <input
                    type="text"
                    required
                    value={editingProduct.name || ''}
                    onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                    placeholder="e.g. ZenPods Ultra Latency"
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">SKU</label>
                  <input
                    type="text"
                    required
                    value={editingProduct.sku || ''}
                    onChange={(e) => setEditingProduct({ ...editingProduct, sku: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-mono-code text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Price (BDT)</label>
                  <input
                    type="number"
                    required
                    value={editingProduct.price || 0}
                    onChange={(e) => setEditingProduct({ ...editingProduct, price: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-mono-code text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Discount Price (BDT)</label>
                  <input
                    type="number"
                    value={editingProduct.discountPrice || ''}
                    onChange={(e) => setEditingProduct({ ...editingProduct, discountPrice: e.target.value ? Number(e.target.value) : undefined })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-mono-code text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Stock Quantity</label>
                  <input
                    type="number"
                    required
                    value={editingProduct.stockQuantity || 0}
                    onChange={(e) => setEditingProduct({ ...editingProduct, stockQuantity: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-mono-code text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
                  <input
                    type="text"
                    value={editingProduct.category || ''}
                    onChange={(e) => setEditingProduct({ ...editingProduct, category: e.target.value })}
                    placeholder="e.g. Wireless Audio"
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Badge Tag</label>
                  <input
                    type="text"
                    value={editingProduct.badge || ''}
                    onChange={(e) => setEditingProduct({ ...editingProduct, badge: e.target.value })}
                    placeholder="e.g. Best Seller / Popular"
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white"
                  />
                </div>
              </div>

              {/* Status and Featured Controls */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Catalog Status</label>
                  <select
                    value={editingProduct.status || 'active'}
                    onChange={(e) => setEditingProduct({ ...editingProduct, status: e.target.value as 'active' | 'disabled' })}
                    className="w-full px-3 py-2 rounded-lg bg-white border border-slate-200 text-xs font-medium text-slate-800 focus:outline-none focus:border-blue-600"
                  >
                    <option value="active">Active (Published on Store)</option>
                    <option value="disabled">Disabled (Hidden from Store)</option>
                  </select>
                </div>
                <div className="flex items-center pt-5 sm:pt-6">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-800 select-none">
                    <input
                      type="checkbox"
                      checked={editingProduct.featured || false}
                      onChange={(e) => setEditingProduct({ ...editingProduct, featured: e.target.checked })}
                      className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300 cursor-pointer"
                    />
                    <span>Highlight as Featured Product</span>
                  </label>
                </div>
              </div>

              {/* Product Image Upload with Live Preview */}
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-slate-700">Product Image</label>
                
                {editingProduct.images?.[0] ? (
                  <div className="flex items-center gap-4 p-3 rounded-xl bg-slate-50 border border-slate-200">
                    <div className="w-16 h-16 rounded-lg bg-white border border-slate-200 p-1 shrink-0 overflow-hidden flex items-center justify-center">
                      <img
                        src={editingProduct.images[0]}
                        alt="Product Preview"
                        className="w-full h-full object-contain"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-mono-code text-slate-700 truncate">{editingProduct.images[0]}</p>
                      <p className="text-[11px] text-emerald-600 font-semibold mt-0.5">Image ready for display</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <label className="px-3 py-1.5 rounded-lg bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold border border-slate-200 cursor-pointer shadow-2xs">
                        Change
                        <input
                          type="file"
                          accept="image/jpeg,image/png,image/webp,image/gif"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleImageFileSelected(file);
                          }}
                          className="hidden"
                        />
                      </label>
                      <button
                        type="button"
                        onClick={() => setEditingProduct({ ...editingProduct, images: [] })}
                        className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50 cursor-pointer"
                        title="Remove image"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="border-2 border-dashed border-slate-200 hover:border-blue-400 transition-colors rounded-xl p-5 text-center bg-slate-50/50">
                    <Upload className="w-7 h-7 mx-auto text-slate-400 mb-2" />
                    <p className="text-xs font-semibold text-slate-700">Upload Product Image</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">PNG, JPG, WEBP, or GIF up to 5MB</p>
                    
                    <div className="mt-3">
                      <label className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold cursor-pointer transition-colors shadow-xs">
                        <Upload className="w-3.5 h-3.5" />
                        <span>Select Image File</span>
                        <input
                          type="file"
                          accept="image/jpeg,image/png,image/webp,image/gif"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleImageFileSelected(file);
                          }}
                          className="hidden"
                        />
                      </label>
                    </div>
                  </div>
                )}

                {isUploadingImage && (
                  <div className="flex items-center gap-2 text-xs text-blue-600 font-mono-code animate-pulse py-1">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Uploading and verifying image...</span>
                  </div>
                )}

                {imageUploadError && (
                  <div className="text-xs text-rose-600 font-semibold py-1">
                    {imageUploadError}
                  </div>
                )}

                {/* Direct URL Accordion */}
                <div className="pt-1">
                  <button
                    type="button"
                    onClick={() => setShowImageUrlInput(!showImageUrlInput)}
                    className="text-[11px] text-slate-500 hover:text-slate-800 font-medium underline cursor-pointer"
                  >
                    {showImageUrlInput ? 'Hide manual URL input' : 'Or enter external image URL manually'}
                  </button>

                  {showImageUrlInput && (
                    <input
                      type="text"
                      value={editingProduct.images?.[0] || ''}
                      onChange={(e) => setEditingProduct({ ...editingProduct, images: [e.target.value] })}
                      placeholder="https://example.com/image.jpg or /images/uploads/..."
                      className="mt-1.5 w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 font-mono-code focus:outline-none focus:border-blue-600 focus:bg-white"
                    />
                  )}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Short Description</label>
                <input
                  type="text"
                  value={editingProduct.shortDescription || ''}
                  onChange={(e) => setEditingProduct({ ...editingProduct, shortDescription: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Full Description</label>
                <textarea
                  rows={3}
                  value={editingProduct.description || ''}
                  onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsProductModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs cursor-pointer shadow-xs"
                >
                  Save Product
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
