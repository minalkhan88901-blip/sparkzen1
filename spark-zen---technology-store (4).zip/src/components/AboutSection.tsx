import React from 'react';
import { Sparkles, ShieldCheck, HeartHandshake, CheckCircle2 } from 'lucide-react';
import type { StoreSettings } from '../types.js';

interface AboutSectionProps {
  settings: StoreSettings | null;
}

export const AboutSection: React.FC<AboutSectionProps> = ({ settings }) => {
  return (
    <section id="about" className="py-16 md:py-24 bg-white border-b border-slate-200 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Brand Visual / Logo feature */}
          <div className="lg:col-span-5 order-2 lg:order-1">
            <div className="relative rounded-3xl bg-[#f8fafc] border border-slate-200/90 p-8 shadow-xs overflow-hidden">
              <div className="w-24 h-24 rounded-3xl bg-[#0c101a] border border-slate-200 p-3 mx-auto mb-6 flex items-center justify-center shadow-sm">
                <img
                  src="/sparkzen-logo.png"
                  alt="SPARK Zen Logo"
                  className="w-full h-full object-contain"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="space-y-3 text-center">
                <h3 className="text-2xl font-extrabold text-slate-900">
                  {settings?.storeName || 'SPARK Zen'}
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  Dhaka, Bangladesh • Everyday Tech Gear
                </p>
                <div className="pt-3 border-t border-slate-200 text-xs text-slate-600 leading-relaxed">
                  Specialized in curated, authentic, high-utility tech essentials.
                </div>
              </div>

              {/* Specs snapshot */}
              <div className="grid grid-cols-2 gap-3 mt-6 pt-6 border-t border-slate-200 text-xs">
                <div className="p-3.5 rounded-xl bg-white border border-slate-200 shadow-xs text-center">
                  <span className="text-slate-500 block text-xs font-medium">Budget Friendly</span>
                  <span className="text-slate-900 font-extrabold text-sm mt-0.5 block">Under ৳1,500</span>
                </div>
                <div className="p-3.5 rounded-xl bg-white border border-slate-200 shadow-xs text-center">
                  <span className="text-slate-500 block text-xs font-medium">Quality Guarantee</span>
                  <span className="text-blue-600 font-extrabold text-sm mt-0.5 block">100% Tested</span>
                </div>
              </div>
            </div>
          </div>

          {/* Text Content */}
          <div className="lg:col-span-7 order-1 lg:order-2 space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-50 border border-blue-200 text-xs font-semibold text-blue-700 shadow-xs">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              <span>About SPARK Zen</span>
            </div>

            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight leading-snug">
              Delivering Honest, High-Utility Tech Gear in Bangladesh.
            </h2>

            <div className="space-y-4 text-sm sm:text-base text-slate-600 leading-relaxed">
              <p>
                SPARK Zen was established with a simple, friendly mission: to cut through the confusion of counterfeit and unreliable electronics in the local market, and deliver handpicked, thoroughly tested gadgets directly to tech lovers across Bangladesh.
              </p>
              <p>
                Instead of hundreds of random low-grade items, we only curate 3 to 5 standout essentials—all priced under ৳1,500—that solve real daily tech challenges: crystal clear low-latency audio, phone cooling for marathon gaming sessions, ultra-durable fast charging, and pocket toolkits.
              </p>
              <p>
                Every order is backed by a 7-day hassle-free replacement warranty and our fair delivery charge model.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3">
              <div className="flex items-start gap-3.5 p-4 rounded-2xl bg-[#f8fafc] border border-slate-200/80 shadow-xs">
                <div className="p-2.5 rounded-xl bg-blue-50 text-blue-600 border border-blue-200 shrink-0">
                  <CheckCircle2 className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Curated & Tested</h4>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">Only select high-caliber products tested before dispatch.</p>
                </div>
              </div>

              <div className="flex items-start gap-3.5 p-4 rounded-2xl bg-[#f8fafc] border border-slate-200/80 shadow-xs">
                <div className="p-2.5 rounded-xl bg-emerald-50 text-emerald-600 border border-emerald-200 shrink-0">
                  <ShieldCheck className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">7-Day Replacement</h4>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">Zero risk shopping with fast and friendly customer care.</p>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
