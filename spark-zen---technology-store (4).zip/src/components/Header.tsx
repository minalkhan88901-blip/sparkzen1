import React, { useState } from 'react';
import { ShoppingBag, Menu, X, Shield, Search, PhoneCall } from 'lucide-react';
import type { CartItem, StoreSettings } from '../types.js';

interface HeaderProps {
  cart: CartItem[];
  onOpenCart: () => void;
  onOpenAdmin: () => void;
  onOpenTrack: () => void;
  settings: StoreSettings | null;
}

export const Header: React.FC<HeaderProps> = ({
  cart,
  onOpenCart,
  onOpenAdmin,
  onOpenTrack,
  settings
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const yOffset = -80;
      const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white/95 backdrop-blur-md border-b border-slate-200/80 transition-all">
      {/* Announcement Bar */}
      {settings?.heroAnnouncement && (
        <div className="bg-gradient-to-r from-blue-50 via-sky-50 to-blue-50 border-b border-blue-100/80 text-xs py-2 px-4 text-center text-blue-800 font-medium tracking-normal">
          <span>{settings.heroAnnouncement}</span>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Brand Identity / Logo */}
        <a
          href="#"
          className="flex items-center gap-3 group focus:outline-none"
          onClick={(e) => {
            e.preventDefault();
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
        >
          <div className="relative w-11 h-11 rounded-2xl overflow-hidden border border-slate-200 bg-[#0c101a] p-1.5 shadow-xs group-hover:border-blue-300 transition-colors flex items-center justify-center">
            <img
              src="/sparkzen-logo.png"
              alt="SPARK Zen Logo"
              className="w-full h-full object-contain"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="flex flex-col">
            <div className="flex items-center">
              <span className="font-extrabold text-xl text-slate-900 tracking-tight">SPARK</span>
              <span className="font-extrabold text-xl text-blue-600 tracking-tight ml-1">ZEN</span>
            </div>
            <span className="text-[11px] text-slate-500 font-medium -mt-0.5">
              Everyday Tech BD
            </span>
          </div>
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-semibold text-slate-600">
          <button
            onClick={() => scrollToSection('products')}
            className="hover:text-blue-600 transition-colors cursor-pointer py-1"
          >
            Products
          </button>
          <button
            onClick={() => scrollToSection('payment-model')}
            className="hover:text-blue-600 transition-colors cursor-pointer flex items-center gap-1.5 py-1"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>How COD Works</span>
          </button>
          <button
            onClick={() => scrollToSection('about')}
            className="hover:text-blue-600 transition-colors cursor-pointer py-1"
          >
            About Us
          </button>
          <button
            onClick={() => scrollToSection('faq')}
            className="hover:text-blue-600 transition-colors cursor-pointer py-1"
          >
            FAQ
          </button>
          <button
            onClick={() => scrollToSection('contact')}
            className="hover:text-blue-600 transition-colors cursor-pointer py-1"
          >
            Contact
          </button>
        </nav>

        {/* Action Controls */}
        <div className="flex items-center gap-2.5">
          {/* Hotline Phone if available */}
          {settings?.phone && (
            <a
              href={`tel:${settings.phone}`}
              className="hidden lg:flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-xl text-slate-600 hover:text-blue-600 hover:bg-slate-50 transition-colors"
              title="Customer Support Helpline"
            >
              <PhoneCall className="w-3.5 h-3.5 text-blue-600" />
              <span>{settings.phone}</span>
            </a>
          )}

          {/* Track Order Button */}
          <button
            onClick={onOpenTrack}
            className="hidden sm:flex items-center gap-1.5 text-xs font-semibold px-3.5 py-2.5 rounded-xl bg-white text-slate-700 border border-slate-200 hover:border-blue-300 hover:text-blue-600 hover:bg-slate-50 transition-all shadow-xs cursor-pointer"
            title="Track Existing Order Status"
          >
            <Search className="w-3.5 h-3.5 text-slate-500" />
            <span>Track Order</span>
          </button>

          {/* Cart Trigger */}
          <button
            id="header-cart-button"
            onClick={onOpenCart}
            className="relative flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition-all shadow-sm hover:shadow-md cursor-pointer"
            aria-label="View Shopping Cart"
          >
            <ShoppingBag className="w-4 h-4 text-white" />
            <span className="hidden sm:inline">Cart</span>
            {totalCartCount > 0 && (
              <span className="flex items-center justify-center min-w-[20px] h-5 px-1.5 text-[11px] font-bold text-blue-700 bg-white rounded-full shadow-xs">
                {totalCartCount}
              </span>
            )}
          </button>

          {/* Admin Access Discreet Link */}
          <button
            onClick={onOpenAdmin}
            className="p-2.5 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
            title="Admin Dashboard"
            aria-label="Admin Portal"
          >
            <Shield className="w-4 h-4 text-slate-400 hover:text-blue-600 transition-colors" />
          </button>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-xl text-slate-700 hover:text-slate-900 hover:bg-slate-100 transition-colors"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-slate-200 bg-white px-4 pt-3 pb-6 space-y-3 shadow-lg">
          <div className="flex flex-col space-y-1 text-sm font-medium">
            <button
              onClick={() => scrollToSection('products')}
              className="text-left py-2.5 px-3 rounded-lg text-slate-700 hover:bg-slate-50 hover:text-blue-600"
            >
              Featured Products
            </button>
            <button
              onClick={() => scrollToSection('payment-model')}
              className="text-left py-2.5 px-3 rounded-lg text-slate-700 hover:bg-slate-50 hover:text-blue-600 flex items-center justify-between"
            >
              <span>Advance Delivery & COD Model</span>
              <span className="text-[11px] font-mono-code text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                COD Ready
              </span>
            </button>
            <button
              onClick={() => scrollToSection('about')}
              className="text-left py-2.5 px-3 rounded-lg text-slate-700 hover:bg-slate-50 hover:text-blue-600"
            >
              About SPARK Zen
            </button>
            <button
              onClick={() => scrollToSection('faq')}
              className="text-left py-2.5 px-3 rounded-lg text-slate-700 hover:bg-slate-50 hover:text-blue-600"
            >
              Frequently Asked Questions
            </button>
            <button
              onClick={() => scrollToSection('contact')}
              className="text-left py-2.5 px-3 rounded-lg text-slate-700 hover:bg-slate-50 hover:text-blue-600"
            >
              Contact & Support
            </button>
          </div>

          <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenTrack();
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-slate-50 text-slate-700 border border-slate-200 text-xs font-semibold hover:bg-slate-100"
            >
              <Search className="w-3.5 h-3.5 text-slate-500" />
              <span>Track Existing Order</span>
            </button>
            {settings?.phone && (
              <a
                href={`tel:${settings.phone}`}
                className="w-full flex items-center justify-center gap-2 py-2 rounded-lg text-xs text-slate-500 hover:text-blue-600"
              >
                <PhoneCall className="w-3.5 h-3.5 text-slate-400" />
                <span>Call Hotline: {settings.phone}</span>
              </a>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
