import React, { useState } from 'react';
import { X, Search, Package, Truck, CheckCircle2, Clock, AlertCircle, Loader2 } from 'lucide-react';
import type { Order } from '../types.js';
import OrderStatus from './OrderStatus.js';

interface TrackOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TrackOrderModal: React.FC<TrackOrderModalProps> = ({ isOpen, onClose }) => {
  const [orderIdInput, setOrderIdInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [order, setOrder] = useState<Order | null>(null);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleTrack = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderIdInput.trim()) return;

    try {
      setIsLoading(true);
      setError('');
      setOrder(null);

      const res = await fetch(`/api/orders/${orderIdInput.trim().toUpperCase()}`);
      if (!res.ok) {
        if (res.status === 404) {
          throw new Error('No order found with that Order ID. Please check the code (e.g. SZ-2026-1021).');
        }
        throw new Error('Could not retrieve order details.');
      }

      const data = await res.json();
      setOrder(data);
    } catch (err: any) {
      setError(err.message || 'Failed to track order');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm overscroll-contain flex min-h-full items-start sm:items-center justify-center p-2.5 sm:p-4 md:p-6">
      <div 
        className="relative w-full max-w-lg bg-white border border-slate-200/90 rounded-2xl sm:rounded-3xl shadow-xl overflow-hidden my-auto sm:my-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
              <Search className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-slate-900">Track Your Order</h2>
              <p className="text-xs text-slate-500">Instant live status of your parcel</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 sm:w-8 sm:h-8 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors flex items-center justify-center cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 sm:p-6 space-y-4 sm:space-y-5">
          <form onSubmit={handleTrack} className="flex flex-col sm:flex-row gap-2.5">
            <input
              type="text"
              value={orderIdInput}
              onChange={(e) => setOrderIdInput(e.target.value)}
              placeholder="Order ID (e.g. SZ-2026-1021)"
              className="flex-1 px-4 py-3 rounded-xl sm:rounded-2xl bg-white border border-slate-200 text-base sm:text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-100 uppercase font-semibold"
            />
            <button
              type="submit"
              disabled={isLoading}
              className="min-h-[46px] px-5 py-3 rounded-xl sm:rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm transition-colors flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer shadow-sm shrink-0"
            >
              {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
              <span>Track</span>
            </button>
          </form>

          {error && (
            <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-xs sm:text-sm text-rose-700 flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {order && (
            <div className="space-y-4 pt-2 border-t border-slate-100">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-500 block">Order ID</span>
                  <span className="text-base font-extrabold text-blue-600">{order.id}</span>
                </div>
                <div className="text-right">
                  <span className="text-xs text-slate-500 block">Status</span>
                  <span className="text-xs font-bold uppercase px-3 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                    {order.orderStatus}
                  </span>
                </div>
              </div>

              {/* Real-time Payment Verification Status */}
              <div className="rounded-2xl border border-slate-200 bg-white shadow-xs overflow-hidden">
                <OrderStatus orderId={order.id} />
              </div>

              {/* Progress Stepper */}
              <div className="p-4 rounded-2xl bg-[#f8fafc] border border-slate-200/80 text-xs space-y-2.5">
                <div className="font-bold text-slate-700 text-xs uppercase tracking-wider">
                  Dispatch Timeline
                </div>
                <div className="grid grid-cols-4 gap-1.5 text-center text-xs">
                  <div className={`p-2 rounded-xl font-semibold ${order.orderStatus !== 'cancelled' ? 'bg-blue-50 text-blue-700 border border-blue-200' : 'bg-slate-100 text-slate-400'}`}>
                    1. Placed
                  </div>
                  <div className={`p-2 rounded-xl font-semibold ${['confirmed', 'processing', 'shipped', 'delivered'].includes(order.orderStatus) ? 'bg-blue-50 text-blue-700 border border-blue-200' : 'bg-slate-100 text-slate-400'}`}>
                    2. Confirmed
                  </div>
                  <div className={`p-2 rounded-xl font-semibold ${['shipped', 'delivered'].includes(order.orderStatus) ? 'bg-blue-50 text-blue-700 border border-blue-200' : 'bg-slate-100 text-slate-400'}`}>
                    3. Shipped
                  </div>
                  <div className={`p-2 rounded-xl font-semibold ${order.orderStatus === 'delivered' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-slate-100 text-slate-400'}`}>
                    4. Delivered
                  </div>
                </div>
              </div>

              {/* Courier & Tracking */}
              <div className="p-4 rounded-2xl bg-[#f8fafc] border border-slate-200/80 text-xs sm:text-sm space-y-2">
                <div className="flex justify-between text-slate-600">
                  <span className="text-slate-500">Assigned Courier:</span>
                  <span className="font-bold text-slate-900">{order.courier.name}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span className="text-slate-500">Tracking Code:</span>
                  <span className="text-blue-600 font-bold">{order.courier.trackingId || 'Pending dispatch booking'}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span className="text-slate-500">Delivery Location:</span>
                  <span className="text-slate-800 font-medium">{order.customer.location === 'inside_dhaka' ? 'Inside Dhaka' : 'Outside Dhaka'}</span>
                </div>
                <div className="flex justify-between text-slate-600 pt-2 border-t border-slate-200/80">
                  <span className="text-slate-500 font-medium">COD Product Due:</span>
                  <span className="text-emerald-700 font-extrabold text-base">৳{(order.pricing?.productAmountDue ?? 0).toLocaleString()}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
