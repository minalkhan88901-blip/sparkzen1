import React, { useEffect, useState } from 'react';

interface OrderStatusProps {
  orderId: string | number;
  whatsappNumber?: string;
}

export default function OrderStatus({ orderId, whatsappNumber = '8801XXXXXXXXX' }: OrderStatusProps) {
  const [status, setStatus] = useState<'Pending' | 'Paid' | 'Payment Failed' | string>('Pending');

  useEffect(() => {
    // Initial immediate fetch on mount
    let isMounted = true;
    const checkStatus = async () => {
      try {
        const res = await fetch(`/api/check-order-status?order_id=${orderId}`);
        const data = await res.json();
        if (isMounted && data?.status) {
          setStatus(data.status);
        }
      } catch (err) {
        console.error("Error fetching status", err);
      }
    };
    checkStatus();

    const interval = setInterval(async () => {
      if (status === 'Paid' || status === 'Payment Failed') {
        clearInterval(interval);
        return;
      }

      try {
        const res = await fetch(`/api/check-order-status?order_id=${orderId}`);
        const data = await res.json();
        if (isMounted && data?.status) {
          setStatus(data.status);
        }
      } catch (err) {
        console.error("Error fetching status", err);
      }
    }, 4000);

    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [orderId, status]);

  const cleanWhatsappNumber = (whatsappNumber || '8801XXXXXXXXX').replace(/[^0-9a-zA-Z]/g, '');

  return (
    <div style={{ padding: '20px', textAlign: 'center', fontFamily: 'sans-serif' }}>
      {status === 'Pending' && (
        <div style={{ color: '#d97706' }}>
          <h2>⏳ Verifying Payment...</h2>
          <p>আপনার পেমেন্ট ভেরিফাই করা হচ্ছে, অনুগ্রহ করে অপেক্ষা করুন।</p>
        </div>
      )}

      {status === 'Paid' && (
        <div style={{ color: '#16a34a' }}>
          <h2>✅ Payment Verified!</h2>
          <p>আপনার অর্ডারটি সফলভাবে কনফার্ম হয়েছে।</p>
        </div>
      )}

      {status === 'Payment Failed' && (
        <div style={{ color: '#dc2626' }}>
          <h2>❌ Payment Verification Failed!</h2>
          <p>আপনার দেয়া TrxID বা টাকার পরিমাণ মেলেনি।</p>
          <a
            href={`https://wa.me/${cleanWhatsappNumber}?text=Hi, my order payment failed (Order ID: ${orderId})`}
            target="_blank"
            rel="noreferrer"
            style={{
              display: 'inline-block',
              marginTop: '15px',
              padding: '10px 20px',
              backgroundColor: '#25D366',
              color: '#fff',
              textDecoration: 'none',
              borderRadius: '5px'
            }}
          >
            Contact Customer Support on WhatsApp
          </a>
        </div>
      )}
    </div>
  );
}

export { OrderStatus };
