import React, { useState, useEffect } from 'react';
import { X, ShoppingBag, Zap, ShieldCheck, Truck, RotateCcw, Plus, Minus, Check } from 'lucide-react';
import type { Product } from '../types.js';

interface ProductDetailsModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number) => void;
  onBuyNow: (product: Product, quantity: number) => void;
}

export const ProductDetailsModal: React.FC<ProductDetailsModalProps> = ({
  product,
  onClose,
  onAddToCart,
  onBuyNow
}) => {
  const [quantity, setQuantity] = useState(1);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);

  // Reset quantity and preview image when a new product is selected
  useEffect(() => {
    setQuantity(1);
    setSelectedImageIndex(0);
  }, [product?.id]);

  if (!product) return null;

  const isOutOfStock = product.stockQuantity <= 0;
  // Stock limit as ceiling: customer cannot select more than available stock
  const maxAvailable = Math.max(1, product.stockQuantity);

  const handleIncrement = () => {
    if (quantity < maxAvailable) {
      setQuantity(q => q + 1);
    }
  };

  const handleDecrement = () => {
    if (quantity > 1) {
      setQuantity(q => q - 1);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm overscroll-contain flex min-h-full items-start sm:items-center justify-center p-2.5 sm:p-4 md:p-6 lg:p-8 animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-4xl bg-white border border-slate-200 rounded-2xl sm:rounded-3xl shadow-2xl overflow-hidden my-auto sm:my-6 md:my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 sm:top-4 sm:right-4 z-20 w-10 h-10 rounded-full bg-white/95 text-slate-500 hover:text-slate-900 border border-slate-200 hover:border-slate-300 shadow-xs transition-colors flex items-center justify-center cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-0">
          
          {/* Left Column: Image Viewer */}
          <div className="md:col-span-6 bg-[#f8fafc] p-6 sm:p-8 flex flex-col justify-between border-b md:border-b-0 md:border-r border-slate-200">
            {/* Primary Large Image */}
            <div className="relative w-full aspect-square rounded-xl bg-white border border-slate-200 p-4 flex items-center justify-center overflow-hidden shadow-xs">
              <img
                src={product.images[selectedImageIndex] || product.images[0] || '/sparkzen-logo.png'}
                alt={product.name}
                className="w-full h-full object-contain filter drop-shadow-sm"
                referrerPolicy="no-referrer"
              />
              {product.badge && (
                <span className="absolute top-3 left-3 px-2.5 py-1 rounded text-[10px] font-bold uppercase tracking-wider bg-blue-600 text-white font-mono-code shadow-xs">
                  {product.badge}
                </span>
              )}
            </div>

            {/* Thumbnails (if multiple images) */}
            {product.images.length > 1 && (
              <div className="flex items-center gap-2 mt-4 overflow-x-auto pb-1">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImageIndex(idx)}
                    className={`w-14 h-14 rounded-lg bg-white border p-1 shrink-0 transition-all cursor-pointer ${
                      selectedImageIndex === idx ? 'border-blue-600 ring-2 ring-blue-500/20' : 'border-slate-200 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                  </button>
                ))}
              </div>
            )}

            {/* Guarantee Pills */}
            <div className="mt-6 pt-4 border-t border-slate-200 grid grid-cols-2 gap-3 text-xs text-slate-600">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-blue-600 shrink-0" />
                <span>24-72h Fast Courier</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
                <span>7-Day Replacement</span>
              </div>
            </div>
          </div>

          {/* Right Column: Details & Actions */}
          <div className="md:col-span-6 p-6 sm:p-8 flex flex-col justify-between">
            <div className="space-y-4">
              
              {/* Category & SKU */}
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="uppercase text-blue-600 font-bold tracking-wide bg-blue-50 px-2.5 py-0.5 rounded-md">
                  {product.category}
                </span>
                <span className="font-medium">SKU: {product.sku}</span>
              </div>

              {/* Title */}
              <h2 className="text-2xl font-extrabold text-slate-900 leading-snug">
                {product.name}
              </h2>

              {/* Price & Savings */}
              <div className="flex items-baseline gap-3 p-4 rounded-xl bg-[#f8fafc] border border-slate-200">
                <div className="flex items-baseline gap-1">
                  <span className="text-sm font-bold text-blue-600">৳</span>
                  <span className="text-3xl font-extrabold text-slate-900">
                    {(product.price ?? 0).toLocaleString()}
                  </span>
                </div>
                {product.discountPrice != null && (
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-slate-400 line-through">
                      ৳{(product.discountPrice ?? 0).toLocaleString()}
                    </span>
                    <span className="text-xs text-emerald-700 font-bold px-2 py-0.5 rounded-full bg-emerald-50 border border-emerald-200">
                      Save ৳{product.discountPrice - product.price}
                    </span>
                  </div>
                )}
              </div>

              {/* Advance Delivery Model Explanation Callout */}
              <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-200 text-xs text-slate-700">
                <div className="flex items-center gap-1.5 text-blue-700 font-bold mb-1">
                  <Zap className="w-3.5 h-3.5" />
                  <span>Fair Delivery Model: Advance Delivery Fee Only</span>
                </div>
                <p className="leading-relaxed text-slate-600">
                  Pay strictly the courier fee in advance (৳70 inside Dhaka / ৳130 outside Dhaka). 
                  The entire product price <strong className="text-slate-900 font-bold">(৳{(product.price ?? 0).toLocaleString()})</strong> is paid in cash directly to the courier rider upon delivery.
                </p>
              </div>

              {/* Description */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                  Overview
                </h4>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {product.description}
                </p>
              </div>

              {/* Specifications Table */}
              {product.specifications && product.specifications.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                    Product Specifications
                  </h4>
                  <div className="rounded-xl border border-slate-200 overflow-hidden divide-y divide-slate-100 text-xs">
                    {product.specifications.map((spec, i) => (
                      <div key={i} className="grid grid-cols-12 py-2.5 px-3.5 bg-[#f8fafc]">
                        <span className="col-span-5 font-semibold text-slate-600">{spec.key}</span>
                        <span className="col-span-7 text-slate-800 font-medium">{spec.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Stock Status indicator */}
              <div className="flex items-center gap-2 text-xs">
                <span className="text-slate-500">Availability:</span>
                {isOutOfStock ? (
                  <span className="text-rose-600 font-bold">Currently Out of Stock</span>
                ) : (
                  <span className="text-emerald-700 font-semibold flex items-center gap-1 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    {product.stockQuantity} units in stock, ready to ship
                  </span>
                )}
              </div>

            </div>

            {/* Quantity Selector & Action Buttons */}
            <div className="mt-6 pt-5 border-t border-slate-200 space-y-3">
              {!isOutOfStock && (
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-slate-700 block">
                      Quantity
                    </span>
                    <span className="text-xs font-extrabold text-blue-600 block mt-0.5">
                      Subtotal: ৳{((product.price ?? 0) * quantity).toLocaleString()}
                    </span>
                  </div>
                  <div className="flex items-center border border-slate-200 rounded-lg bg-white shadow-xs">
                    <button
                      onClick={handleDecrement}
                      disabled={quantity <= 1}
                      className="px-3 py-1.5 text-slate-600 hover:text-slate-900 disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
                      aria-label="Decrease quantity"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="w-10 text-center text-sm font-bold text-slate-900">
                      {quantity}
                    </span>
                    <button
                      onClick={handleIncrement}
                      disabled={quantity >= maxAvailable}
                      className="px-3 py-1.5 text-slate-600 hover:text-slate-900 disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
                      aria-label="Increase quantity"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-2.5 sm:gap-3">
                <button
                  onClick={() => {
                    onAddToCart(product, quantity);
                    onClose();
                  }}
                  disabled={isOutOfStock}
                  className="w-full min-h-[48px] py-3 px-3 sm:px-4 rounded-xl bg-slate-100 hover:bg-slate-200/80 text-slate-800 border border-slate-200 text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 sm:gap-2 transition-colors disabled:opacity-40 cursor-pointer"
                >
                  <ShoppingBag className="w-4 h-4 text-slate-600 shrink-0" />
                  <span>Add to Cart {quantity > 1 ? `(${quantity})` : ''}</span>
                </button>

                <button
                  onClick={() => {
                    onBuyNow(product, quantity);
                    onClose();
                  }}
                  disabled={isOutOfStock}
                  className="w-full min-h-[48px] py-3 px-3 sm:px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-bold transition-all shadow-md shadow-blue-600/20 disabled:opacity-40 cursor-pointer active:scale-[0.99] flex items-center justify-center"
                >
                  Buy Now (৳{((product.price ?? 0) * quantity).toLocaleString()})
                </button>
              </div>
            </div>

          </div>

        </div>
      </div>
    </div>
  );
};
