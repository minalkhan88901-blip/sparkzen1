import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  ShieldCheck, 
  AlertCircle, 
  Zap, 
  ArrowRight, 
  Loader2, 
  Copy, 
  Check, 
  Minus, 
  Plus, 
  ShoppingBag,
  Truck
} from 'lucide-react';
import type { CartItem, StoreSettings, Order } from '../types.js';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  mode: 'cart' | 'buy_now';
  defaultLocation: 'inside_dhaka' | 'outside_dhaka';
  settings: StoreSettings | null;
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onOrderSuccess: (order: Order) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  mode,
  defaultLocation,
  settings,
  onUpdateQuantity,
  onOrderSuccess
}) => {
  const backdropRef = useRef<HTMLDivElement>(null);

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState(defaultLocation === 'inside_dhaka' ? 'Dhaka' : '');
  const [location, setLocation] = useState<'inside_dhaka' | 'outside_dhaka'>(defaultLocation);
  const [notes, setNotes] = useState('');

  // Advance Payment Options
  const [paymentOption, setPaymentOption] = useState<'pay_now' | 'pay_after'>('pay_now');
  const [paymentMethod, setPaymentMethod] = useState<'bkash' | 'nagad'>('bkash');
  const [transactionId, setTransactionId] = useState('');
  const [senderNumber, setSenderNumber] = useState('');

  const [copiedNumber, setCopiedNumber] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Lifecycle handler: resets transient state and scroll every time modal opens
  useEffect(() => {
    if (isOpen) {
      setErrorMessage('');
      setIsSubmitting(false);

      if (defaultLocation) {
        setLocation(defaultLocation);
        if (defaultLocation === 'inside_dhaka' && (!city || city.toLowerCase() !== 'dhaka')) {
          setCity('Dhaka');
        }
      }

      // Ensure scroll starts right at the top on every open
      const timer = setTimeout(() => {
        if (backdropRef.current) {
          backdropRef.current.scrollTop = 0;
        }
        window.scrollTo({ top: 0, behavior: 'instant' });
      }, 10);

      // Lock document body scroll
      document.body.style.overflow = 'hidden';

      return () => {
        clearTimeout(timer);
        document.body.style.overflow = '';
      };
    } else {
      document.body.style.overflow = '';
    }
  }, [isOpen, defaultLocation]);

  if (!isOpen) return null;

  const insideFee = settings?.insideDhakaDeliveryCharge || 70;
  const outsideFee = settings?.outsideDhakaDeliveryCharge || 130;
  const deliveryCharge = location === 'inside_dhaka' ? insideFee : outsideFee;

  const totalItemCount = items.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const totalOrderValue = subtotal + deliveryCharge;
  const advancePayableNow = deliveryCharge;
  const amountDueOnDelivery = subtotal;

  const activePaymentNumber = paymentMethod === 'bkash'
    ? (settings?.advancePaymentMethod?.bkashMerchantNumber || '01712-345678')
    : (settings?.advancePaymentMethod?.nagadMerchantNumber || '01712-345678');

  const handleCopyNumber = () => {
    navigator.clipboard.writeText(activePaymentNumber.replace(/[^0-9]/g, ''));
    setCopiedNumber(true);
    setTimeout(() => setCopiedNumber(false), 2000);
  };

  const handleLocationChange = (newLoc: 'inside_dhaka' | 'outside_dhaka') => {
    setLocation(newLoc);
    if (newLoc === 'inside_dhaka' && (!city || city.toLowerCase() !== 'dhaka')) {
      setCity('Dhaka');
    } else if (newLoc === 'outside_dhaka' && city.toLowerCase() === 'dhaka') {
      setCity('');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (items.length === 0) {
      setErrorMessage('Your checkout is empty. Please select a product first.');
      return;
    }

    if (!name.trim()) {
      setErrorMessage('Please enter your full name.');
      return;
    }

    const cleanPhone = phone.replace(/[^0-9+]/g, '');
    if (!/^(?:\+8801|01)[3-9]\d{8}$/.test(cleanPhone)) {
      setErrorMessage('Please enter a valid 11-digit Bangladeshi mobile number (e.g. 017XXXXXXXX).');
      return;
    }

    if (!address.trim() || address.trim().length < 6) {
      setErrorMessage('Please provide a complete delivery address (House, Road, Sector/Area).');
      return;
    }

    if (!city.trim()) {
      setErrorMessage('Please specify your Area or District/City.');
      return;
    }

    if (paymentOption === 'pay_now' && !transactionId.trim()) {
      setErrorMessage('Please provide the bKash/Nagad Transaction ID (TrxID) for your advance delivery charge.');
      return;
    }

    try {
      setIsSubmitting(true);

      const orderPayload = {
        customer: {
          name: name.trim(),
          phone: cleanPhone,
          address: address.trim(),
          city: city.trim(),
          location,
          notes: notes.trim()
        },
        items: items.map(item => ({
          productId: item.productId || item.product.id,
          quantity: item.quantity
        })),
        advancePaymentDetails: paymentOption === 'pay_now' ? {
          method: paymentMethod,
          transactionId: transactionId.trim(),
          senderNumber: senderNumber.trim() || cleanPhone
        } : undefined
      };

      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderPayload)
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to submit order');
      }

      onOrderSuccess(data);
    } catch (err: any) {
      setErrorMessage(err.message || 'An unexpected error occurred. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div 
      ref={backdropRef}
      id="checkout-modal-backdrop"
      className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm overflow-y-auto overscroll-contain p-2 sm:p-4 md:p-6 lg:p-8 flex justify-center items-start"
      onClick={onClose}
    >
      <div 
        id="checkout-modal-dialog"
        className="relative w-full max-w-6xl xl:max-w-7xl my-auto bg-white border border-slate-200 rounded-2xl sm:rounded-3xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Pinned Modal Header */}
        <div className="sticky top-0 z-30 px-4 sm:px-6 py-3.5 sm:py-4 border-b border-slate-200 bg-white/95 backdrop-blur-md flex items-center justify-between gap-3 shadow-xs">
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex items-center gap-1.5 text-blue-600">
                <Zap className="w-5 h-5 shrink-0" />
                <h2 className="text-base sm:text-lg lg:text-xl font-extrabold text-slate-900 tracking-tight">
                  Easy Checkout & Shipping
                </h2>
              </div>
              {mode === 'buy_now' ? (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
                  ⚡ Buy Now
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
                  🛒 Cart Checkout ({totalItemCount} {totalItemCount === 1 ? 'item' : 'items'})
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-0.5 truncate hidden sm:block">
              Advance courier charge • Cash on Delivery (COD) for product upon delivery
            </p>
          </div>

          <button
            id="close-checkout-modal-btn"
            onClick={onClose}
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors flex items-center justify-center cursor-pointer shrink-0"
            aria-label="Close checkout"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content Body */}
        <div className="p-4 sm:p-6 lg:p-8">
          
          {/* Error Banner */}
          {errorMessage && (
            <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-xs sm:text-sm text-rose-700 flex items-start gap-2.5 shadow-xs">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div className="flex-1 font-semibold">{errorMessage}</div>
            </div>
          )}

          {items.length === 0 ? (
            <div className="py-12 text-center">
              <ShoppingBag className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-base font-bold text-slate-800">Your checkout is empty</h3>
              <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-sm mx-auto">
                Please select a product or add items to your cart before proceeding to checkout.
              </p>
              <button
                onClick={onClose}
                className="mt-4 px-5 py-2.5 rounded-xl bg-blue-600 text-white text-xs sm:text-sm font-bold hover:bg-blue-700 transition-colors cursor-pointer"
              >
                Continue Shopping
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} id="checkout-order-form">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start">
                
                {/* LEFT COLUMN: Customer Details & Advance Payment */}
                <div className="lg:col-span-7 space-y-6 order-2 lg:order-1">
                  
                  {/* Section 1: Customer Contact & Shipping Address */}
                  <div className="p-4 sm:p-5 lg:p-6 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
                    <div className="flex items-center gap-2 pb-2.5 border-b border-slate-100">
                      <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 text-xs font-extrabold flex items-center justify-center shrink-0">1</span>
                      <h3 className="text-sm sm:text-base font-bold text-slate-900">
                        Customer & Delivery Information
                      </h3>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 sm:gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                          Full Name <span className="text-rose-500">*</span>
                        </label>
                        <input
                          id="checkout-customer-name"
                          type="text"
                          required
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="e.g. Tanvir Ahmed"
                          className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-slate-50/70 border border-slate-200 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-600 focus:bg-white focus:ring-2 focus:ring-blue-600/20 shadow-xs transition-all"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                          Mobile Number (11-digit) <span className="text-rose-500">*</span>
                        </label>
                        <input
                          id="checkout-customer-phone"
                          type="tel"
                          required
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="017XXXXXXXX"
                          className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-slate-50/70 border border-slate-200 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-600 focus:bg-white focus:ring-2 focus:ring-blue-600/20 shadow-xs transition-all font-mono"
                        />
                      </div>
                    </div>

                    {/* Delivery Area Toggle */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-2">
                        Delivery Region <span className="text-rose-500">*</span>
                      </label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 sm:gap-3">
                        <button
                          type="button"
                          onClick={() => handleLocationChange('inside_dhaka')}
                          className={`min-h-[58px] p-3 sm:p-3.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-center ${
                            location === 'inside_dhaka'
                              ? 'border-blue-600 bg-blue-50/80 text-slate-900 ring-2 ring-blue-500/20 shadow-xs'
                              : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                          }`}
                        >
                          <div className="text-xs sm:text-sm font-bold flex items-center justify-between">
                            <span className="flex items-center gap-1.5">
                              <Truck className="w-4 h-4 text-blue-600 shrink-0" />
                              Inside Dhaka
                            </span>
                            <span className="text-[11px] font-bold text-blue-600 bg-white px-2 py-0.5 rounded-md border border-blue-200">
                              ৳{insideFee}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-500 mt-1">
                            Advance courier fee: ৳{insideFee} • Fast delivery
                          </div>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleLocationChange('outside_dhaka')}
                          className={`min-h-[58px] p-3 sm:p-3.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-center ${
                            location === 'outside_dhaka'
                              ? 'border-blue-600 bg-blue-50/80 text-slate-900 ring-2 ring-blue-500/20 shadow-xs'
                              : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                          }`}
                        >
                          <div className="text-xs sm:text-sm font-bold flex items-center justify-between">
                            <span className="flex items-center gap-1.5">
                              <Truck className="w-4 h-4 text-blue-600 shrink-0" />
                              Outside Dhaka (All BD)
                            </span>
                            <span className="text-[11px] font-bold text-blue-600 bg-white px-2 py-0.5 rounded-md border border-blue-200">
                              ৳{outsideFee}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-500 mt-1">
                            Advance courier fee: ৳{outsideFee} • Nationwide
                          </div>
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 sm:gap-4">
                      <div className="sm:col-span-1">
                        <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                          City / District <span className="text-rose-500">*</span>
                        </label>
                        <input
                          id="checkout-customer-city"
                          type="text"
                          required
                          value={city}
                          onChange={(e) => setCity(e.target.value)}
                          placeholder={location === 'inside_dhaka' ? 'e.g. Mirpur, Dhaka' : 'e.g. Chattogram'}
                          className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-slate-50/70 border border-slate-200 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-600 focus:bg-white focus:ring-2 focus:ring-blue-600/20 shadow-xs transition-all"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                          Full Delivery Address <span className="text-rose-500">*</span>
                        </label>
                        <input
                          id="checkout-customer-address"
                          type="text"
                          required
                          value={address}
                          onChange={(e) => setAddress(e.target.value)}
                          placeholder="House No, Road No, Area or Landmark"
                          className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-slate-50/70 border border-slate-200 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-600 focus:bg-white focus:ring-2 focus:ring-blue-600/20 shadow-xs transition-all"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">
                        Order Notes (Optional)
                      </label>
                      <input
                        type="text"
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        placeholder="e.g. Call before delivery, deliver after 3 PM"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50/70 border border-slate-200 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-600 focus:bg-white focus:ring-2 focus:ring-blue-600/20 shadow-xs transition-all"
                      />
                    </div>
                  </div>

                  {/* Section 2: Advance Courier Payment Method */}
                  <div className="p-4 sm:p-5 lg:p-6 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
                    <div className="flex items-center justify-between pb-2.5 border-b border-slate-100">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 text-xs font-extrabold flex items-center justify-center shrink-0">2</span>
                        <h3 className="text-sm sm:text-base font-bold text-slate-900">
                          Advance Courier Payment
                        </h3>
                      </div>
                      <span className="text-xs font-extrabold text-blue-600 bg-blue-50 border border-blue-200 px-2.5 py-0.5 rounded-full">
                        ৳{advancePayableNow} Advance
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 sm:gap-3">
                      <button
                        type="button"
                        onClick={() => setPaymentOption('pay_now')}
                        className={`min-h-[58px] p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-center ${
                          paymentOption === 'pay_now'
                            ? 'border-blue-600 bg-blue-50/80 text-slate-900 ring-2 ring-blue-500/20 shadow-xs'
                            : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                        }`}
                      >
                        <div className="text-xs sm:text-sm font-bold flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-blue-600 shrink-0"></span>
                          <span>Pay Delivery Fee Now</span>
                        </div>
                        <div className="text-[11px] text-slate-500 mt-1">
                          Send ৳{advancePayableNow} via bKash/Nagad & enter TrxID
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() => setPaymentOption('pay_after')}
                        className={`min-h-[58px] p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-center ${
                          paymentOption === 'pay_after'
                            ? 'border-blue-600 bg-blue-50/80 text-slate-900 ring-2 ring-blue-500/20 shadow-xs'
                            : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                        }`}
                      >
                        <div className="text-xs sm:text-sm font-bold flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-slate-400 shrink-0"></span>
                          <span>Confirm & Pay in 2 Hours</span>
                        </div>
                        <div className="text-[11px] text-slate-500 mt-1">
                          Our WhatsApp team will verify & guide your deposit
                        </div>
                      </button>
                    </div>

                    {paymentOption === 'pay_now' ? (
                      <div className="p-3.5 sm:p-4 rounded-xl bg-[#f8fafc] border border-slate-200 space-y-3.5">
                        {/* Method selector */}
                        <div className="grid grid-cols-2 gap-2.5 sm:gap-3">
                          <button
                            type="button"
                            onClick={() => setPaymentMethod('bkash')}
                            className={`min-h-[44px] py-2 px-3 rounded-xl border text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center justify-center text-center ${
                              paymentMethod === 'bkash'
                                ? 'bg-[#e2136e]/10 border-[#e2136e] text-[#e2136e] ring-2 ring-[#e2136e]/20'
                                : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                            }`}
                          >
                            bKash Send Money
                          </button>

                          <button
                            type="button"
                            onClick={() => setPaymentMethod('nagad')}
                            className={`min-h-[44px] py-2 px-3 rounded-xl border text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center justify-center text-center ${
                              paymentMethod === 'nagad'
                                ? 'bg-[#f7941d]/10 border-[#f7941d] text-[#e27c00] ring-2 ring-[#f7941d]/20'
                                : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                            }`}
                          >
                            Nagad Send Money
                          </button>
                        </div>

                        {/* Number & Copy Instruction */}
                        <div className="p-3 sm:p-3.5 rounded-xl bg-white border border-slate-200 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 shadow-xs">
                          <div className="min-w-0">
                            <span className="text-[11px] text-slate-500 block">
                              Send ৳{advancePayableNow} to SPARK Zen {paymentMethod === 'bkash' ? 'bKash' : 'Nagad'} Number:
                            </span>
                            <span className="text-base sm:text-lg font-extrabold text-slate-900 tracking-wide block mt-0.5 font-mono">
                              {activePaymentNumber}
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={handleCopyNumber}
                            className="min-h-[38px] px-3.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer shrink-0"
                          >
                            {copiedNumber ? (
                              <>
                                <Check className="w-3.5 h-3.5 text-emerald-600" />
                                <span className="text-emerald-700">Copied!</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3.5 h-3.5 text-slate-600" />
                                <span>Copy Number</span>
                              </>
                            )}
                          </button>
                        </div>

                        {/* Transaction ID & Sender Phone */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div>
                            <label className="block text-xs font-semibold text-slate-700 mb-1">
                              bKash/Nagad TrxID <span className="text-rose-500">*</span>
                            </label>
                            <input
                              id="checkout-trx-id"
                              type="text"
                              value={transactionId}
                              onChange={(e) => setTransactionId(e.target.value)}
                              placeholder="e.g. BL99XXXXXX"
                              className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-white border border-slate-200 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-600 font-mono uppercase"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-semibold text-slate-700 mb-1">
                              Sender Phone Number (Optional)
                            </label>
                            <input
                              type="tel"
                              value={senderNumber}
                              onChange={(e) => setSenderNumber(e.target.value)}
                              placeholder="Number sent from"
                              className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-white border border-slate-200 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-600 font-mono"
                            />
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="p-3.5 sm:p-4 rounded-xl bg-blue-50 border border-blue-200 text-xs text-slate-700 space-y-1">
                        <p className="font-bold text-blue-800">
                          WhatsApp / Call Confirmation:
                        </p>
                        <p className="text-slate-600 leading-relaxed">
                          Your order will be held. Our support team will call or message your number ({phone || 'your phone number'}) to receive the ৳{advancePayableNow} advance delivery charge before parcel handover.
                        </p>
                      </div>
                    )}
                  </div>

                </div>

                {/* RIGHT COLUMN: Order Summary with Quantity Selector & Breakdown & Primary Button */}
                <div className="lg:col-span-5 order-1 lg:order-2 space-y-4 lg:sticky lg:top-24">
                  
                  <div className="p-4 sm:p-5 lg:p-6 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
                    {/* Summary Title */}
                    <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                      <h3 className="text-sm sm:text-base font-bold text-slate-900">
                        Order Summary
                      </h3>
                      <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200 font-bold">
                        {totalItemCount} {totalItemCount === 1 ? 'item' : 'items'}
                      </span>
                    </div>

                    {/* Product Items with Quantity Selection */}
                    <div className="space-y-3 max-h-72 lg:max-h-80 overflow-y-auto pr-1">
                      {items.map((item) => {
                        const itemId = item.productId || item.product.id;
                        const isMinQty = item.quantity <= 1;
                        const isMaxQty = item.quantity >= item.product.stockQuantity;

                        return (
                          <div
                            key={itemId}
                            className="p-3 sm:p-3.5 rounded-xl bg-slate-50/70 border border-slate-200/90 shadow-xs hover:border-slate-300 transition-colors"
                          >
                            <div className="flex gap-3 items-start">
                              {/* Product Thumbnail */}
                              <div className="relative w-16 h-16 sm:w-18 sm:h-18 shrink-0 rounded-xl bg-white border border-slate-200 p-1 flex items-center justify-center overflow-hidden shadow-xs">
                                <img
                                  src={item.product.images[0] || '/sparkzen-logo.png'}
                                  alt={item.product.name}
                                  className="w-full h-full object-contain filter drop-shadow-xs"
                                  referrerPolicy="no-referrer"
                                  onError={(e) => {
                                    const target = e.currentTarget;
                                    if (!target.src.endsWith('/sparkzen-logo.png')) {
                                      target.src = '/sparkzen-logo.png';
                                    }
                                  }}
                                />
                              </div>

                              {/* Product Details */}
                              <div className="flex-1 min-w-0">
                                <h4 className="text-xs sm:text-sm font-bold text-slate-900 leading-snug line-clamp-2">
                                  {item.product.name}
                                </h4>
                                
                                <div className="flex items-center gap-2 mt-1 text-xs">
                                  <span className="text-slate-500">Unit:</span>
                                  <span className="font-bold text-slate-800">৳{(item.product.price ?? 0).toLocaleString()}</span>
                                  <span className="text-[11px] text-slate-400">
                                    (Stock: {item.product.stockQuantity})
                                  </span>
                                </div>

                                {/* Quantity Controls: [-] qty [+] */}
                                <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-slate-200/70">
                                  <div className="flex items-center border border-slate-200 rounded-lg bg-white shadow-xs">
                                    <button
                                      type="button"
                                      onClick={() => onUpdateQuantity(itemId, item.quantity - 1)}
                                      disabled={isMinQty}
                                      className="w-7 h-7 flex items-center justify-center text-slate-500 hover:text-slate-900 disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
                                      aria-label={`Decrease ${item.product.name} quantity`}
                                    >
                                      <Minus className="w-3.5 h-3.5" />
                                    </button>
                                    
                                    <span className="w-7 text-center text-xs font-bold text-slate-900 select-none">
                                      {item.quantity}
                                    </span>

                                    <button
                                      type="button"
                                      onClick={() => onUpdateQuantity(itemId, item.quantity + 1)}
                                      disabled={isMaxQty}
                                      className="w-7 h-7 flex items-center justify-center text-slate-500 hover:text-slate-900 disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
                                      aria-label={`Increase ${item.product.name} quantity`}
                                    >
                                      <Plus className="w-3.5 h-3.5" />
                                    </button>
                                  </div>

                                  {/* Subtotal */}
                                  <div className="text-right">
                                    <span className="text-[10px] text-slate-400 block uppercase font-medium">Subtotal</span>
                                    <span className="text-xs sm:text-sm font-extrabold text-blue-600">
                                      ৳{((item.product.price ?? 0) * (item.quantity ?? 1)).toLocaleString()}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Financial Breakdown */}
                    <div className="p-3.5 sm:p-4 rounded-xl bg-[#f8fafc] border border-slate-200/90 space-y-2.5">
                      <div className="flex justify-between text-xs sm:text-sm text-slate-600">
                        <span>Product Subtotal</span>
                        <span className="font-bold text-slate-900">৳{(subtotal ?? 0).toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-xs sm:text-sm text-slate-600">
                        <span>Delivery Charge ({location === 'inside_dhaka' ? 'Inside Dhaka' : 'Outside Dhaka'})</span>
                        <span className="font-bold text-slate-900">৳{deliveryCharge}</span>
                      </div>

                      <div className="border-t border-slate-200 pt-2.5 flex justify-between text-sm sm:text-base font-extrabold text-slate-900">
                        <span>Total Order Value</span>
                        <span className="text-blue-600">৳{(totalOrderValue ?? 0).toLocaleString()}</span>
                      </div>

                      {/* Pay Now vs Due on Delivery Cards */}
                      <div className="grid grid-cols-2 gap-2 sm:gap-2.5 pt-1.5">
                        <div className="p-2.5 sm:p-3 rounded-xl bg-blue-50/90 border border-blue-200 shadow-xs">
                          <span className="block text-[10px] sm:text-[11px] font-bold text-blue-800 uppercase tracking-wide">
                            Pay Now (Delivery):
                          </span>
                          <span className="block text-base sm:text-lg lg:text-xl font-extrabold text-blue-600 mt-0.5">
                            ৳{advancePayableNow}
                          </span>
                          <span className="text-[10px] text-blue-700 leading-tight block mt-0.5">
                            Courier booking
                          </span>
                        </div>

                        <div className="p-2.5 sm:p-3 rounded-xl bg-emerald-50/90 border border-emerald-200 shadow-xs">
                          <span className="block text-[10px] sm:text-[11px] font-bold text-emerald-800 uppercase tracking-wide">
                            Due on Delivery:
                          </span>
                          <span className="block text-base sm:text-lg lg:text-xl font-extrabold text-emerald-700 mt-0.5">
                            ৳{(amountDueOnDelivery ?? 0).toLocaleString()}
                          </span>
                          <span className="text-[10px] text-emerald-700 leading-tight block mt-0.5">
                            Cash on Delivery
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Primary Submit Button */}
                    <div className="pt-2">
                      <button
                        id="confirm-place-order-btn"
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full min-h-[52px] py-3.5 px-5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-sm sm:text-base tracking-normal transition-all shadow-md shadow-blue-600/20 hover:shadow-lg flex items-center justify-center gap-2.5 disabled:opacity-50 cursor-pointer active:scale-[0.99]"
                      >
                        {isSubmitting ? (
                          <>
                            <Loader2 className="w-5 h-5 animate-spin" />
                            <span>Placing Your Order...</span>
                          </>
                        ) : (
                          <>
                            <span>Confirm Order (৳{advancePayableNow} Advance • ৳{(amountDueOnDelivery ?? 0).toLocaleString()} COD)</span>
                            <ArrowRight className="w-4 h-4 shrink-0" />
                          </>
                        )}
                      </button>

                      <div className="mt-3 flex items-center justify-center gap-2 text-xs text-slate-500 font-medium text-center">
                        <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span>Authentic SPARK Zen • 7-Day Replacement Guarantee</span>
                      </div>
                    </div>

                  </div>

                </div>

              </div>
            </form>
          )}

        </div>

      </div>
    </div>
  );
};
