import React from 'react';
import { ShieldCheck, CheckCircle2, Truck, Wallet, ShoppingBag, Smartphone, Check } from 'lucide-react';
import type { StoreSettings } from '../types.js';

interface PaymentModelExplainerProps {
  settings: StoreSettings | null;
}

export const PaymentModelExplainer: React.FC<PaymentModelExplainerProps> = ({ settings }) => {
  const insideFee = settings?.insideDhakaDeliveryCharge || 70;
  const outsideFee = settings?.outsideDhakaDeliveryCharge || 130;

  return (
    <section id="payment-model" className="py-16 md:py-24 bg-gradient-to-b from-[#f8fafc] to-white border-y border-slate-200 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-50 border border-blue-200 text-xs font-semibold text-blue-700 mb-3 shadow-xs">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
            <span>Fair & Honest Shopping</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            How Cash on Delivery Works at SPARK Zen
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-600 leading-relaxed">
            We believe in complete transparency. You never pay for any gadget before seeing it. 
            We only collect the courier delivery charge in advance, and you pay for the product in cash when it reaches your hands.
          </p>
        </div>

        {/* 3 Step Visual Comparison */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          
          {/* Step 1 */}
          <div className="p-7 rounded-2xl bg-white border border-slate-200/90 shadow-xs relative group hover:border-blue-300 hover:shadow-md transition-all">
            <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-100 text-blue-600 flex items-center justify-center mb-5">
              <ShoppingBag className="w-6 h-6" />
            </div>
            <div className="text-xs font-bold text-blue-600 tracking-wide uppercase mb-1">
              Step 1
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">
              Choose Your Gadget
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
              Explore our handpicked tech items under ৳1,500. Click "Order Now" and enter your address anywhere in Bangladesh.
            </p>
          </div>

          {/* Step 2 */}
          <div className="p-7 rounded-2xl bg-white border-2 border-blue-500/80 relative shadow-sm hover:shadow-md transition-all">
            <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center mb-5 shadow-xs">
              <Smartphone className="w-6 h-6" />
            </div>
            <div className="inline-block text-[11px] font-bold text-blue-600 uppercase tracking-wide mb-1 bg-blue-50 px-2.5 py-0.5 rounded-full">
              Advance Step
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">
              Pay Delivery Fee Only
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Send strictly the courier booking fee: <strong className="text-blue-700 font-semibold">৳{insideFee}</strong> (Inside Dhaka) or <strong className="text-blue-700 font-semibold">৳{outsideFee}</strong> (Outside Dhaka) via bKash or Nagad. This confirms authentic delivery.
            </p>
          </div>

          {/* Step 3 */}
          <div className="p-7 rounded-2xl bg-white border border-slate-200/90 shadow-xs relative group hover:border-emerald-300 hover:shadow-md transition-all">
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-100 text-emerald-600 flex items-center justify-center mb-5">
              <Wallet className="w-6 h-6" />
            </div>
            <div className="text-xs font-bold text-emerald-600 tracking-wide uppercase mb-1">
              Step 3
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">
              Pay Product Price in Cash
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
              The delivery rider arrives at your doorstep in 24–72 hours. Receive and inspect your parcel, then pay the product price in cash directly to the rider!
            </p>
          </div>

        </div>

        {/* Concrete Example Calculation Box */}
        <div className="max-w-3xl mx-auto rounded-2xl bg-white border border-slate-200/90 p-6 sm:p-8 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200/80 pb-5 mb-5">
            <div>
              <span className="text-xs font-bold text-blue-600 uppercase tracking-wider">
                Transparent Example
              </span>
              <h4 className="text-lg font-bold text-slate-900 mt-0.5">
                Ordering a ৳1,200 Tech Gadget
              </h4>
            </div>
            <span className="text-xs font-semibold px-3 py-1.5 rounded-full bg-slate-100 border border-slate-200 text-slate-700 w-fit">
              Outside Dhaka Delivery
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5 text-center">
            <div className="p-3.5 rounded-xl bg-[#f8fafc] border border-slate-200/70">
              <span className="text-xs text-slate-500 block font-medium">Product Price</span>
              <span className="text-base font-extrabold text-slate-900 mt-1 block">৳1,200</span>
            </div>

            <div className="p-3.5 rounded-xl bg-[#f8fafc] border border-slate-200/70">
              <span className="text-xs text-slate-500 block font-medium">Delivery Fee</span>
              <span className="text-base font-extrabold text-slate-900 mt-1 block">৳{outsideFee}</span>
            </div>

            <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-200">
              <span className="text-xs text-blue-700 block font-bold">Paid Advance</span>
              <span className="text-base font-extrabold text-blue-600 mt-1 block">৳{outsideFee}</span>
            </div>

            <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200">
              <span className="text-xs text-emerald-800 block font-bold">Due on Delivery (COD)</span>
              <span className="text-base font-extrabold text-emerald-700 mt-1 block">৳1,200</span>
            </div>
          </div>

          <div className="mt-5 text-xs text-slate-600 flex items-start gap-2.5 pt-4 border-t border-slate-100 leading-relaxed">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <span>
              <strong className="text-slate-900">100% Risk Free for You:</strong> You don't risk your money on unreceived items. We dispatch your parcel immediately with reputable couriers (Steadfast / Pathao) with instant SMS tracking.
            </span>
          </div>
        </div>

      </div>
    </section>
  );
};
