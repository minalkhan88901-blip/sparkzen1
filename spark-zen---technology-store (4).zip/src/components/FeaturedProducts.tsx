import React from 'react';
import { ShoppingBag, Eye, Zap, AlertCircle, Check } from 'lucide-react';
import type { Product } from '../types.js';

interface FeaturedProductsProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  onBuyNow: (product: Product) => void;
}

export const FeaturedProducts: React.FC<FeaturedProductsProps> = ({
  products,
  onSelectProduct,
  onAddToCart,
  onBuyNow
}) => {
  return (
    <section id="products" className="py-16 md:py-24 bg-white border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 border-b border-slate-200/80 pb-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-xs font-semibold text-blue-700 mb-2.5">
              <Zap className="w-3.5 h-3.5 text-blue-600" />
              <span>Tested & Verified Tech</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              Featured Tech Gear
            </h2>
            <p className="mt-2 text-sm sm:text-base text-slate-600 max-w-xl">
              Strictly selected for reliability, build quality, and real-world value. Every unit is unboxed and tested prior to packing.
            </p>
          </div>

          <div className="mt-4 md:mt-0 flex items-center gap-2 text-xs font-semibold text-slate-700 bg-slate-50 border border-slate-200/80 px-3.5 py-1.5 rounded-full shadow-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>{products.length} Products Available</span>
          </div>
        </div>

        {/* Products Grid: 1 col on small phones, 2 cols on phones/small tablets, 3 cols on medium tablets/laptops, 4 cols on PC/desktops */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {products.map((product) => {
            const isOutOfStock = product.stockQuantity <= 0;
            const isLowStock = product.stockQuantity > 0 && product.stockQuantity <= 5;
            const savings = product.discountPrice ? product.discountPrice - product.price : 0;

            return (
              <div
                key={product.id}
                id={`product-card-${product.id}`}
                className="group relative flex flex-col rounded-2xl bg-white border border-slate-200/90 hover:border-blue-300 hover:shadow-lg hover:shadow-slate-200/50 transition-all duration-300 overflow-hidden"
              >
                {/* Badge Top Overlay */}
                <div className="absolute top-3 left-3 z-10 flex flex-col gap-1.5 items-start pointer-events-none">
                  {product.badge && (
                    <span className="px-2.5 py-1 rounded-full text-[11px] font-bold tracking-wide bg-blue-600 text-white shadow-xs">
                      {product.badge}
                    </span>
                  )}
                  {savings > 0 && (
                    <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 shadow-xs">
                      Save ৳{savings}
                    </span>
                  )}
                </div>

                {/* Stock Tag Top Right */}
                <div className="absolute top-3 right-3 z-10 pointer-events-none">
                  {isOutOfStock ? (
                    <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-rose-50 text-rose-700 border border-rose-200 shadow-xs">
                      Sold Out
                    </span>
                  ) : isLowStock ? (
                    <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-50 text-amber-800 border border-amber-200 shadow-xs flex items-center gap-1">
                      <AlertCircle className="w-3 h-3 text-amber-600" />
                      Only {product.stockQuantity} left
                    </span>
                  ) : (
                    <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 shadow-xs flex items-center gap-1">
                      <Check className="w-3 h-3 text-emerald-600" />
                      In Stock
                    </span>
                  )}
                </div>

                {/* Product Image Container */}
                <div 
                  className="relative w-full aspect-square bg-[#f8fafc] overflow-hidden cursor-pointer flex items-center justify-center p-5 border-b border-slate-100 group-hover:bg-[#f1f5f9]/70 transition-colors"
                  onClick={() => onSelectProduct(product)}
                >
                  <img
                    src={product.images[0] || '/sparkzen-logo.png'}
                    alt={product.name}
                    className="w-full h-full object-contain filter drop-shadow-sm transition-transform duration-300 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />

                  {/* Quick View Hover Button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectProduct(product);
                    }}
                    className="absolute bottom-3 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-all duration-200 translate-y-2 group-hover:translate-y-0 px-4 py-1.5 rounded-full bg-white/95 border border-slate-200 text-slate-700 hover:text-blue-600 hover:border-blue-300 text-xs font-semibold flex items-center gap-1.5 shadow-md backdrop-blur-sm cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Quick Specs</span>
                  </button>
                </div>

                {/* Product Details Info */}
                <div className="p-5 flex flex-col flex-1 justify-between">
                  <div>
                    {/* Category */}
                    <span className="text-[11px] font-semibold uppercase tracking-wider text-blue-600 bg-blue-50/60 px-2 py-0.5 rounded-md">
                      {product.category}
                    </span>

                    {/* Title */}
                    <h3 
                      onClick={() => onSelectProduct(product)}
                      className="mt-2 text-base font-bold text-slate-900 hover:text-blue-600 transition-colors cursor-pointer line-clamp-2 leading-snug"
                    >
                      {product.name}
                    </h3>

                    {/* Short Description */}
                    <p className="mt-1.5 text-xs text-slate-500 line-clamp-2 leading-relaxed">
                      {product.shortDescription}
                    </p>
                  </div>

                  {/* Price & Actions */}
                  <div className="mt-5 pt-4 border-t border-slate-100">
                    <div className="flex items-baseline justify-between mb-3.5">
                      <div className="flex items-baseline gap-1">
                        <span className="text-sm font-bold text-blue-600">৳</span>
                        <span className="text-2xl font-extrabold text-slate-900 tracking-tight">
                          {(product.price ?? 0).toLocaleString()}
                        </span>
                      </div>
                      {product.discountPrice != null && (
                        <span className="text-xs text-slate-400 line-through">
                          ৳{(product.discountPrice ?? 0).toLocaleString()}
                        </span>
                      )}
                    </div>

                    {/* Action buttons */}
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => onAddToCart(product)}
                        disabled={isOutOfStock}
                        className="w-full py-2.5 px-2 rounded-xl bg-slate-100 hover:bg-slate-200/80 text-slate-700 hover:text-slate-900 border border-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                        title="Add to Shopping Cart"
                      >
                        <ShoppingBag className="w-3.5 h-3.5 text-slate-600" />
                        <span>Add Cart</span>
                      </button>

                      <button
                        onClick={() => onBuyNow(product)}
                        disabled={isOutOfStock}
                        className="w-full py-2.5 px-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all shadow-xs disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                      >
                        Order Now
                      </button>
                    </div>
                  </div>

                </div>

              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
