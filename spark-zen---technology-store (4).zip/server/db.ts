import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import type {
  Product,
  Order,
  StoreSettings,
  CustomerRecord,
  AdminStats,
  PaymentStatus,
  OrderStatus,
  DeliveryStatus
} from '../src/types.js';

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'store.json');
const UPLOADS_DIR = path.join(process.cwd(), 'public', 'images', 'uploads');

export interface VerifiedTransactionRecord {
  trxId: string;
  orderId: string;
  amount: number;
  sender: string;
  verifiedAt: string;
  verifiedBy: 'webhook' | 'admin' | string;
}

export interface PaymentAuditRecord {
  id: string;
  timestamp: string;
  clientIp: string;
  trxId: string;
  amount: number;
  senderMasked: string;
  status: 'success' | 'rejected' | 'already_verified' | 'no_matching_order';
  reason?: string;
  matchedOrderId?: string;
}

export interface DatabaseSchema {
  products: Product[];
  orders: Order[];
  settings: StoreSettings;
  adminUsers: {
    username: string;
    salt: string;
    hash: string;
    role: 'super_admin' | 'admin';
    createdAt: string;
  }[];
  verifiedTransactions?: VerifiedTransactionRecord[];
  paymentAuditLogs?: PaymentAuditRecord[];
}

// Default initial database content
const DEFAULT_PRODUCTS: Product[] = [
  {
    id: 'sz-tws-pulse-pro',
    name: 'ZenAudio Pulse Pro Wireless Earbuds',
    slug: 'zenaudio-pulse-pro-earbuds',
    shortDescription: 'Ultra-low 45ms gaming latency, dual ENC noise-cancelling mics, and metallic battery display case.',
    description: 'Engineered for uncompromising wireless audio fidelity and competitive mobile gaming. Features titanium composite 13mm drivers for punchy bass and crystalline highs, environmental noise cancellation (ENC) for crystal-clear calls on busy Dhaka streets, and an aerospace gunmetal alloy charging case with real-time numeric battery display.',
    specifications: [
      { key: 'Acoustic Driver', value: '13mm Titanium Composite Diaphragm' },
      { key: 'Connectivity', value: 'Bluetooth 5.3 Low-Energy with AAC / SBC' },
      { key: 'Latency Mode', value: '45ms Ultra-Low Latency Game Sync' },
      { key: 'Playtime', value: '6.5 Hours (32 Hours total with Case)' },
      { key: 'Microphone', value: 'Dual MEMS with ENC Background Filtering' },
      { key: 'Water Resistance', value: 'IPX5 Sweat and Rain Resistant' },
      { key: 'Charging', value: 'Type-C Fast Charge (10 min = 2 hrs)' }
    ],
    price: 1350,
    discountPrice: 1550,
    stockQuantity: 24,
    sku: 'SZ-TWS-01',
    category: 'Audio & Acoustics',
    status: 'active',
    featured: true,
    badge: 'Best Seller',
    images: ['/images/earbuds_product_1789388985434.jpg']
  },
  {
    id: 'sz-cable-cyber-66w',
    name: 'ZenCore 66W Cyber Braided Fast Cable',
    slug: 'zencore-66w-cyber-braided-fast-cable',
    shortDescription: 'Transparent cyber alloy housing with real-time digital OLED wattage readout and 6A fast charging.',
    description: 'The ultimate charging cable for demanding tech enthusiasts. Built with a futuristic transparent cybernetic zinc-alloy connector housing an active real-time blue OLED wattage readout. Supports up to 66W / 6A SuperCharge protocols. Bound with high-density ballistic braided nylon rated for 25,000+ flex cycles.',
    specifications: [
      { key: 'Max Output', value: '66W Max (6A High-Current SuperCharge)' },
      { key: 'Smart Display', value: 'Real-time Digital OLED Wattage Meter' },
      { key: 'Connectors', value: 'USB-A to Type-C (Zinc Alloy Cyber Shell)' },
      { key: 'Cable Length', value: '1.2m / 4.0 ft Heavy Duty' },
      { key: 'Cord Material', value: 'Ballistic Double-Braided Military Nylon' },
      { key: 'Data Transfer', value: '480 Mbps High-Speed Sync' },
      { key: 'Safety Chip', value: 'E-Marker Intelligent Over-Current Protection' }
    ],
    price: 650,
    discountPrice: 850,
    stockQuantity: 45,
    sku: 'SZ-CBL-02',
    category: 'Charging & Power',
    status: 'active',
    featured: true,
    badge: 'Popular',
    images: ['/images/cable_product_1789389001065.jpg']
  },
  {
    id: 'sz-cooler-magcool',
    name: 'ZenFrost MagCool Magnetic Phone Cooler',
    slug: 'zenfrost-magcool-phone-cooler',
    shortDescription: 'Semiconductor thermoelectric Peltier plate + hydraulic fan. Drops phone temperature by 15°C in 30 seconds.',
    description: 'Say goodbye to thermal throttling and frame drops during intense gaming sessions. The ZenFrost MagCool combines a solid-state semiconductor Peltier cooling plate with a silent 7-blade hydraulic turbine. Attaches magnetically to MagSafe iPhones or any Android device with the included ultra-thin magnetic metal ring.',
    specifications: [
      { key: 'Cooling Mechanism', value: 'Semiconductor Thermoelectric TEC Plate' },
      { key: 'Fan Speed', value: '6,500 RPM Silent Hydraulic Turbine' },
      { key: 'Temperature Drop', value: 'Up to 15°C in under 30 seconds' },
      { key: 'Mounting', value: 'Magnetic Snap + Universal Adhesive Mag-Ring' },
      { key: 'Weight', value: '62 grams (Balanced Ergonomic Grip)' },
      { key: 'Lighting', value: 'Subtle Electric Cyan Ambient Accent' },
      { key: 'Power Input', value: 'Type-C 5V/2A or 9V/2A' }
    ],
    price: 1450,
    discountPrice: 1750,
    stockQuantity: 18,
    sku: 'SZ-CLR-03',
    category: 'Mobile Gaming',
    status: 'active',
    featured: true,
    badge: 'High Performance',
    images: ['/images/cooler_product_1789389017128.jpg']
  },
  {
    id: 'sz-toolkit-zencraft-24',
    name: 'ZenCraft 24-in-1 Precision Magnetic Tool Kit',
    slug: 'zencraft-24-in-1-precision-magnetic-tool-kit',
    shortDescription: 'Pop-out space-grey anodized aluminum case with 24 anti-rust S2 alloy magnetic precision bits.',
    description: 'Designed for smartphone technicians, PC builders, and electronics hobbyists. The ZenCraft 24-in-1 kit features an anodized sandblasted aluminum alloy pop-out bay housing 24 magnetic precision bits machined from hardened S2 tool steel (60 HRC). The knurled aluminum handle features a 360-degree silent ball-bearing swivel cap.',
    specifications: [
      { key: 'Bit Material', value: 'Hardened S2 Alloy Tool Steel (60 HRC)' },
      { key: 'Bit Assortment', value: '24 Bits: Torx, Pentalobe, Phillips, Hex, Flat, Tri-wing' },
      { key: 'Case Design', value: 'Push-to-Eject Magnetic Pop-out Aluminum Bay' },
      { key: 'Handle', value: 'Anti-Slip Knurled Grip with 360° Swivel Cap' },
      { key: 'Magnetism', value: 'High-Coercivity Magnetic Bit Retention' },
      { key: 'Applications', value: 'Smartphones, Laptops, MacBooks, Drones, Eyewear' }
    ],
    price: 890,
    discountPrice: 1150,
    stockQuantity: 32,
    sku: 'SZ-TOOL-04',
    category: 'Precision Tools',
    status: 'active',
    featured: true,
    badge: 'Essential',
    images: ['/images/screwdriver_product_1789389033220.jpg']
  }
];

const DEFAULT_SETTINGS: StoreSettings = {
  storeName: 'SPARK Zen',
  brandTagline: 'Precision Engineered Technology Essentials',
  phone: '+880 1712-345678',
  whatsapp: '+880 1712-345678',
  email: 'support@sparkzen.bd',
  address: 'Level 4, Multiplan Center, New Elephant Road, Dhaka-1205, Bangladesh',
  insideDhakaDeliveryCharge: 70,
  outsideDhakaDeliveryCharge: 130,
  advancePaymentMethod: {
    bkashMerchantNumber: '01712345678',
    nagadMerchantNumber: '01712345678',
    instructions: 'Send the advance delivery charge to our verified bKash or Nagad Merchant/Personal number to confirm your courier parcel dispatch. The remaining product price is payable in cash upon receiving and inspecting the package.'
  },
  googleSheetsWebhookUrl: process.env.GOOGLE_SHEETS_WEBHOOK_URL || '',
  faqs: [
    {
      q: 'Why do you collect ONLY the delivery charge in advance?',
      a: 'We collect only the delivery charge (BDT 70 for Inside Dhaka, BDT 130 for Outside Dhaka) in advance to confirm authentic orders and prevent fake courier dispatches. The entire product amount remains due and is payable in cash when you receive the parcel.'
    },
    {
      q: 'How and when do I pay the remaining product price?',
      a: 'The remaining product price is paid in Cash on Delivery (COD) directly to the delivery courier rider once they deliver the parcel to your doorstep.'
    },
    {
      q: 'What is the estimated delivery timeframe in Bangladesh?',
      a: 'Inside Dhaka: 24 to 48 hours. Outside Dhaka (all districts including Chittagong, Sylhet, Rajshahi, Khulna, etc.): 48 to 72 hours via Steadfast, Pathao, or RedX couriers.'
    },
    {
      q: 'Are your tech accessories authentic and tested?',
      a: 'Yes. Every single item at SPARK Zen is thoroughly bench-tested and physically inspected before packaging to ensure 100% operational excellence.'
    },
    {
      q: 'What is the return and replacement policy?',
      a: 'We offer an instant 7-day replacement warranty for any functional defect or transit issue. Simply notify us with your Order ID via WhatsApp.'
    },
    {
      q: 'Can I cancel an order after placing it?',
      a: 'You may cancel anytime before the parcel is handed over to the courier by messaging our WhatsApp support. If your advance delivery fee was received and the order has not been dispatched, it will be refunded promptly.'
    }
  ],
  returnPolicy: '7-day replacement guarantee for any manufacturing defects. Products must be returned in original packaging with included accessories.',
  terms: 'All orders require advance delivery charge payment for parcel booking. Remaining product value is payable upon physical delivery.',
  heroAnnouncement: '⚡ Nationwide Fast Courier Across Bangladesh • Advance Delivery Charge + Cash On Delivery'
};

const DEFAULT_ORDERS: Order[] = [
  {
    id: 'SZ-2026-1021',
    createdAt: '2026-09-12T14:32:00.000Z',
    customer: {
      name: 'Tanvir Ahmed',
      phone: '01711223344',
      address: 'House 42, Road 7, Block C, Mirpur 2',
      city: 'Dhaka',
      location: 'inside_dhaka',
      notes: 'Call before arriving at gate'
    },
    items: [
      {
        productId: 'sz-tws-pulse-pro',
        name: 'ZenAudio Pulse Pro Wireless Earbuds',
        sku: 'SZ-TWS-01',
        price: 1350,
        quantity: 1,
        subtotal: 1350,
        image: '/images/earbuds_product_1789388985434.jpg'
      }
    ],
    pricing: {
      subtotal: 1350,
      deliveryCharge: 70,
      totalOrderValue: 1420,
      advanceDeliveryPaid: 70,
      productAmountDue: 0
    },
    paymentStatus: 'fully_paid',
    orderStatus: 'delivered',
    deliveryStatus: 'delivered',
    courier: {
      name: 'Pathao Courier',
      trackingId: 'PTH-892144'
    },
    advancePaymentDetails: {
      method: 'bkash',
      transactionId: 'BK9X21804LA',
      senderNumber: '01711223344',
      paidAt: '2026-09-12T14:35:00.000Z'
    },
    adminNotes: 'Customer confirmed parcel received in good condition.',
    syncedToGoogleSheets: true,
    sheetsSyncTimestamp: '2026-09-12T14:36:00.000Z'
  },
  {
    id: 'SZ-2026-1022',
    createdAt: '2026-09-13T10:15:00.000Z',
    customer: {
      name: 'Rakibul Hasan',
      phone: '01819876543',
      address: 'Shop 12, GEC Circle, CDA Avenue, Nasirabad',
      city: 'Chittagong',
      location: 'outside_dhaka',
      notes: 'Deliver during shop hours 10am-8pm'
    },
    items: [
      {
        productId: 'sz-cooler-magcool',
        name: 'ZenFrost MagCool Magnetic Phone Cooler',
        sku: 'SZ-CLR-03',
        price: 1450,
        quantity: 1,
        subtotal: 1450,
        image: '/images/cooler_product_1789389017128.jpg'
      }
    ],
    pricing: {
      subtotal: 1450,
      deliveryCharge: 130,
      totalOrderValue: 1580,
      advanceDeliveryPaid: 130,
      productAmountDue: 1450
    },
    paymentStatus: 'product_amount_due',
    orderStatus: 'shipped',
    deliveryStatus: 'in_transit',
    courier: {
      name: 'Steadfast Courier',
      trackingId: 'ST-904123CT'
    },
    advancePaymentDetails: {
      method: 'nagad',
      transactionId: 'NG77192801',
      senderNumber: '01819876543',
      paidAt: '2026-09-13T10:18:00.000Z'
    },
    adminNotes: 'Advance delivery charge BDT 130 received. Handed over to Steadfast hub.',
    syncedToGoogleSheets: true,
    sheetsSyncTimestamp: '2026-09-13T10:20:00.000Z'
  },
  {
    id: 'SZ-2026-1023',
    createdAt: '2026-09-14T08:00:00.000Z',
    customer: {
      name: 'Farhan Chowdhury',
      phone: '01912334455',
      address: 'Flat 4B, Road 9A, Dhanmondi',
      city: 'Dhaka',
      location: 'inside_dhaka',
      notes: ''
    },
    items: [
      {
        productId: 'sz-cable-cyber-66w',
        name: 'ZenCore 66W Cyber Braided Fast Cable',
        sku: 'SZ-CBL-02',
        price: 650,
        quantity: 2,
        subtotal: 1300,
        image: '/images/cable_product_1789389001065.jpg'
      }
    ],
    pricing: {
      subtotal: 1300,
      deliveryCharge: 70,
      totalOrderValue: 1370,
      advanceDeliveryPaid: 70,
      productAmountDue: 1300
    },
    paymentStatus: 'delivery_charge_paid',
    orderStatus: 'confirmed',
    deliveryStatus: 'booked',
    courier: {
      name: 'Pathao Courier',
      trackingId: 'PTH-pending'
    },
    advancePaymentDetails: {
      method: 'bkash',
      transactionId: 'BK3M104958P',
      senderNumber: '01912334455',
      paidAt: '2026-09-14T08:05:00.000Z'
    },
    adminNotes: 'Advance BDT 70 verified via bKash statement. Packing order.',
    syncedToGoogleSheets: true,
    sheetsSyncTimestamp: '2026-09-14T08:06:00.000Z'
  }
];

function hashPassword(password: string, salt: string): string {
  return crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
}

export class Database {
  private data: DatabaseSchema;
  private saveTimeout: NodeJS.Timeout | null = null;
  private failedLoginAttempts: Map<string, { count: number; lockedUntil: number }> = new Map();
  private revokedTokens: Set<string> = new Set();

  constructor() {
    this.ensureDataDirectory();
    this.data = this.loadDatabase();
  }

  private ensureDataDirectory() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(UPLOADS_DIR)) {
      fs.mkdirSync(UPLOADS_DIR, { recursive: true });
    }
  }

  private loadDatabase(): DatabaseSchema {
    if (fs.existsSync(DB_FILE)) {
      try {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        if (parsed && Array.isArray(parsed.products) && Array.isArray(parsed.orders) && parsed.settings) {
          // Ensure adminUsers exists
          if (!Array.isArray(parsed.adminUsers) || parsed.adminUsers.length === 0) {
            const defaultAdminUsername = process.env.ADMIN_USERNAME || 'admin';
            const defaultAdminPassword = process.env.ADMIN_PASSWORD || 'SparkZenAdmin@2026';
            const salt = crypto.randomBytes(16).toString('hex');
            const hash = hashPassword(defaultAdminPassword, salt);
            parsed.adminUsers = [
              {
                username: defaultAdminUsername,
                salt,
                hash,
                role: 'super_admin',
                createdAt: new Date().toISOString()
              }
            ];
          }
          if (!Array.isArray(parsed.verifiedTransactions)) {
            parsed.verifiedTransactions = [];
          }
          if (!Array.isArray(parsed.paymentAuditLogs)) {
            parsed.paymentAuditLogs = [];
          }
          return parsed;
        }
      } catch (err) {
        console.error('Error reading database file, creating fresh store:', err);
      }
    }

    const defaultAdminUsername = process.env.ADMIN_USERNAME || 'admin';
    const defaultAdminPassword = process.env.ADMIN_PASSWORD || 'SparkZenAdmin@2026';
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = hashPassword(defaultAdminPassword, salt);

    const initialData: DatabaseSchema = {
      products: DEFAULT_PRODUCTS,
      orders: DEFAULT_ORDERS,
      settings: DEFAULT_SETTINGS,
      verifiedTransactions: [],
      paymentAuditLogs: [],
      adminUsers: [
        {
          username: defaultAdminUsername,
          salt,
          hash,
          role: 'super_admin',
          createdAt: new Date().toISOString()
        }
      ]
    };

    this.writeAtomic(initialData);
    return initialData;
  }

  private writeAtomic(data: DatabaseSchema) {
    try {
      const tmpFile = path.join(DATA_DIR, `store.${Date.now()}.${Math.random().toString(36).slice(2)}.tmp`);
      fs.writeFileSync(tmpFile, JSON.stringify(data, null, 2), 'utf-8');
      fs.renameSync(tmpFile, DB_FILE);
    } catch (err) {
      console.error('Failed to write database file atomically:', err);
      // Fallback direct write
      try {
        fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
      } catch (directErr) {
        console.error('Direct fallback write also failed:', directErr);
      }
    }
  }

  public save() {
    if (this.saveTimeout) {
      clearTimeout(this.saveTimeout);
    }
    this.saveTimeout = setTimeout(() => {
      this.writeAtomic(this.data);
    }, 100);
  }

  public saveImmediate() {
    if (this.saveTimeout) {
      clearTimeout(this.saveTimeout);
      this.saveTimeout = null;
    }
    this.writeAtomic(this.data);
  }

  public backupDatabase(): DatabaseSchema {
    return JSON.parse(JSON.stringify(this.data));
  }

  public restoreDatabase(backup: DatabaseSchema): boolean {
    if (!backup || !Array.isArray(backup.products) || !Array.isArray(backup.orders) || !backup.settings) {
      return false;
    }
    this.data = {
      products: backup.products,
      orders: backup.orders,
      settings: backup.settings,
      adminUsers: Array.isArray(backup.adminUsers) && backup.adminUsers.length > 0 ? backup.adminUsers : this.data.adminUsers
    };
    this.saveImmediate();
    return true;
  }

  // --- Products ---
  public getProducts(includeDisabled = false): Product[] {
    if (includeDisabled) {
      return [...this.data.products];
    }
    return this.data.products.filter(p => p.status === 'active');
  }

  public getProductById(id: string): Product | undefined {
    return this.data.products.find(p => p.id === id || p.slug === id);
  }

  public addProduct(productData: Omit<Product, 'id'>): Product {
    const id = 'sz-' + crypto.randomBytes(4).toString('hex');
    const newProduct: Product = {
      ...productData,
      id
    };
    this.data.products.push(newProduct);
    this.save();
    return newProduct;
  }

  public updateProduct(id: string, updates: Partial<Product>): Product | null {
    const index = this.data.products.findIndex(p => p.id === id);
    if (index === -1) return null;
    this.data.products[index] = {
      ...this.data.products[index],
      ...updates
    };
    this.save();
    return this.data.products[index];
  }

  public deleteProduct(id: string): boolean {
    const initialLen = this.data.products.length;
    this.data.products = this.data.products.filter(p => p.id !== id);
    if (this.data.products.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  // --- Orders ---
  public getOrders(filter?: {
    search?: string;
    orderStatus?: string;
    paymentStatus?: string;
  }): Order[] {
    let result = [...this.data.orders];

    if (filter?.orderStatus && filter.orderStatus !== 'all') {
      result = result.filter(o => o.orderStatus === filter.orderStatus);
    }

    if (filter?.paymentStatus && filter.paymentStatus !== 'all') {
      result = result.filter(o => o.paymentStatus === filter.paymentStatus);
    }

    if (filter?.search) {
      const q = filter.search.toLowerCase().trim();
      result = result.filter(o =>
        (o.id && o.id.toLowerCase().includes(q)) ||
        (o.customer?.name && o.customer.name.toLowerCase().includes(q)) ||
        (o.customer?.phone && o.customer.phone.includes(q)) ||
        (o.courier?.trackingId && o.courier.trackingId.toLowerCase().includes(q)) ||
        (o.courier?.name && o.courier.name.toLowerCase().includes(q))
      );
    }

    return result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public getOrderById(id: string): Order | undefined {
    if (!id) return undefined;
    const cleanId = id.trim().toLowerCase();
    const cleanNum = cleanId.replace(/^sz-sb-/, '').replace(/^sz-/, '');
    return this.data.orders.find(o => {
      const oId = o.id.toLowerCase();
      const oNum = oId.replace(/^sz-sb-/, '').replace(/^sz-/, '');
      return oId === cleanId ||
             oId === `sz-sb-${cleanId}` ||
             cleanId === `sz-sb-${oId}` ||
             (cleanNum.length > 0 && oNum === cleanNum);
    });
  }

  public upsertOrder(order: Order): Order {
    const cleanId = order.id.trim().toLowerCase();
    const index = this.data.orders.findIndex(o => o.id.toLowerCase() === cleanId);
    if (index === -1) {
      this.data.orders.push(order);
    } else {
      this.data.orders[index] = order;
    }
    this.saveImmediate();
    return order;
  }

  public createOrder(orderPayload: {
    customer: Order['customer'];
    items: Order['items'];
    advancePaymentDetails?: Order['advancePaymentDetails'];
  }): Order {
    // Generate unique sequential / formatted Order ID
    const year = new Date().getFullYear();
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const orderId = `SZ-${year}-${randomSuffix}`;

    const subtotal = orderPayload.items.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const deliveryCharge = orderPayload.customer.location === 'inside_dhaka'
      ? this.data.settings.insideDhakaDeliveryCharge
      : this.data.settings.outsideDhakaDeliveryCharge;

    const totalOrderValue = subtotal + deliveryCharge;

    // Has advance delivery payment details been submitted?
    // Security Rule: Customer submitting a TrxID only records it as submitted.
    // It remains pending until verified by the bKash SMS webhook or Admin.
    const advanceDeliveryPaid = 0;
    const productAmountDue = totalOrderValue;

    const newOrder: Order = {
      id: orderId,
      createdAt: new Date().toISOString(),
      customer: orderPayload.customer,
      items: orderPayload.items,
      pricing: {
        subtotal,
        deliveryCharge,
        totalOrderValue,
        advanceDeliveryPaid,
        productAmountDue
      },
      paymentStatus: 'delivery_charge_pending',
      orderStatus: 'new',
      deliveryStatus: 'pending',
      courier: {
        name: orderPayload.customer.location === 'inside_dhaka' ? 'Pathao Courier' : 'Steadfast Courier',
        trackingId: ''
      },
      advancePaymentDetails: orderPayload.advancePaymentDetails,
      adminNotes: '',
      syncedToGoogleSheets: false
    };

    // Deduct stock
    for (const item of orderPayload.items) {
      const product = this.data.products.find(p => p.id === item.productId);
      if (product) {
        product.stockQuantity = Math.max(0, product.stockQuantity - item.quantity);
      }
    }

    this.data.orders.push(newOrder);
    this.saveImmediate();

    // Trigger asynchronous sync to Google Sheets if configured
    this.syncOrderToGoogleSheets(newOrder).catch(err => {
      console.error(`Google Sheets sync error for order ${orderId}:`, err);
    });

    return newOrder;
  }

  public updateOrder(id: string, updates: Partial<Order>): Order | null {
    const index = this.data.orders.findIndex(o => o.id === id);
    if (index === -1) return null;

    const prevOrder = this.data.orders[index];
    const updatedOrder: Order = {
      ...prevOrder,
      ...updates,
      customer: updates.customer ? { ...prevOrder.customer, ...updates.customer } : prevOrder.customer,
      pricing: updates.pricing ? { ...prevOrder.pricing, ...updates.pricing } : prevOrder.pricing,
      courier: updates.courier ? { ...prevOrder.courier, ...updates.courier } : prevOrder.courier,
      advancePaymentDetails: updates.advancePaymentDetails
        ? { ...(prevOrder.advancePaymentDetails || {}), ...updates.advancePaymentDetails } as any
        : prevOrder.advancePaymentDetails
    };

    // If order was newly cancelled, restore product stock
    if (updates.orderStatus === 'cancelled' && prevOrder.orderStatus !== 'cancelled') {
      for (const item of updatedOrder.items) {
        const product = this.data.products.find(p => p.id === item.productId);
        if (product) {
          product.stockQuantity += item.quantity;
        }
      }
    }

    this.data.orders[index] = updatedOrder;
    this.save();
    return updatedOrder;
  }

  // --- Customers Aggregation ---
  public getCustomers(): CustomerRecord[] {
    const customerMap = new Map<string, CustomerRecord>();

    for (const order of this.data.orders) {
      const phone = order.customer.phone.trim();
      const existing = customerMap.get(phone);

      const isDeliveredOrFullyPaid = order.paymentStatus === 'fully_paid' || order.orderStatus === 'delivered';
      const orderSpent = isDeliveredOrFullyPaid ? order.pricing.totalOrderValue : order.pricing.advanceDeliveryPaid;
      const orderDue = isDeliveredOrFullyPaid ? 0 : order.pricing.productAmountDue;

      if (!existing) {
        customerMap.set(phone, {
          id: 'cust-' + crypto.createHash('md5').update(phone).digest('hex').substring(0, 8),
          name: order.customer.name,
          phone: order.customer.phone,
          address: order.customer.address,
          city: order.customer.city,
          location: order.customer.location,
          ordersCount: 1,
          totalSpent: orderSpent,
          outstandingDue: orderDue,
          lastOrderDate: order.createdAt
        });
      } else {
        existing.ordersCount += 1;
        existing.totalSpent += orderSpent;
        existing.outstandingDue += orderDue;
        if (new Date(order.createdAt).getTime() > new Date(existing.lastOrderDate).getTime()) {
          existing.lastOrderDate = order.createdAt;
          existing.address = order.customer.address;
          existing.name = order.customer.name;
        }
      }
    }

    return Array.from(customerMap.values()).sort(
      (a, b) => new Date(b.lastOrderDate).getTime() - new Date(a.lastOrderDate).getTime()
    );
  }

  // --- Stats & Analytics ---
  public getStats(): AdminStats {
    const orders = this.data.orders;
    let totalSales = 0;
    let amountCollected = 0;
    let amountDue = 0;

    let newOrders = 0;
    let confirmedOrders = 0;
    let processingOrders = 0;
    let shippedOrders = 0;
    let deliveredOrders = 0;
    let cancelledOrders = 0;

    for (const order of orders) {
      if (order.orderStatus === 'cancelled') {
        cancelledOrders++;
        continue;
      }

      const totalVal = Number(order.pricing?.totalOrderValue ?? 0);
      const advPaid = Number(order.pricing?.advanceDeliveryPaid ?? 0);
      const prodDue = Number(order.pricing?.productAmountDue ?? 0);

      totalSales += totalVal;

      if (order.paymentStatus === 'fully_paid' || order.orderStatus === 'delivered') {
        amountCollected += totalVal;
      } else {
        amountCollected += advPaid;
        amountDue += prodDue;
      }

      switch (order.orderStatus) {
        case 'new':
          newOrders++;
          break;
        case 'confirmed':
          confirmedOrders++;
          break;
        case 'processing':
          processingOrders++;
          break;
        case 'shipped':
          shippedOrders++;
          break;
        case 'delivered':
          deliveredOrders++;
          break;
      }
    }

    const lowStockProducts = (this.data.products || []).filter(p => (p.stockQuantity ?? 0) <= 5).length;

    return {
      totalOrders: orders.length,
      newOrders,
      confirmedOrders,
      processingOrders,
      shippedOrders,
      deliveredOrders,
      cancelledOrders,
      totalSales,
      amountCollected,
      amountDue,
      deliveryChargesCollected: amountCollected,
      outstandingProductDue: amountDue,
      lowStockProducts
    };
  }

  // --- Settings ---
  public getSettings(): StoreSettings {
    return { ...this.data.settings };
  }

  public updateSettings(updates: Partial<StoreSettings>): StoreSettings {
    this.data.settings = {
      ...this.data.settings,
      ...updates
    };
    this.save();
    return this.data.settings;
  }

  // --- Admin Auth & Security ---
  public checkRateLimit(ip: string): boolean {
    const record = this.failedLoginAttempts.get(ip);
    if (!record) return true;
    if (Date.now() < record.lockedUntil) {
      return false; // locked out
    }
    return true;
  }

  public recordFailedLogin(ip: string) {
    const record = this.failedLoginAttempts.get(ip) || { count: 0, lockedUntil: 0 };
    record.count++;
    if (record.count >= 5) {
      record.lockedUntil = Date.now() + 15 * 60 * 1000; // Lock for 15 minutes
    }
    this.failedLoginAttempts.set(ip, record);
  }

  public resetFailedLogin(ip: string) {
    this.failedLoginAttempts.delete(ip);
  }

  public verifyAdminCredentials(username: string, password: string): boolean {
    const user = this.data.adminUsers.find(u => u.username === username);
    if (!user) return false;

    const hash = hashPassword(password, user.salt);
    return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(user.hash, 'hex'));
  }

  public updateAdminPassword(username: string, newPassword: string): boolean {
    const user = this.data.adminUsers.find(u => u.username === username);
    if (!user) return false;

    const salt = crypto.randomBytes(16).toString('hex');
    user.salt = salt;
    user.hash = hashPassword(newPassword, salt);
    this.save();
    return true;
  }

  // Create cryptographic HMAC session token
  public createSessionToken(username: string): string {
    const secret = process.env.SESSION_SECRET || 'sparkzen_jwt_secret_token_secure_key_92817293';
    const payload = {
      username,
      iat: Date.now(),
      exp: Date.now() + 7 * 24 * 60 * 60 * 1000 // 7 days
    };
    const payloadB64 = Buffer.from(JSON.stringify(payload)).toString('base64url');
    const signature = crypto.createHmac('sha256', secret).update(payloadB64).digest('base64url');
    return `${payloadB64}.${signature}`;
  }

  public revokeSessionToken(token: string) {
    if (token) {
      this.revokedTokens.add(token);
    }
  }

  public verifySessionToken(token: string): { valid: boolean; username?: string } {
    if (!token || !token.includes('.') || this.revokedTokens.has(token)) return { valid: false };
    const [payloadB64, signature] = token.split('.');
    const secret = process.env.SESSION_SECRET || 'sparkzen_jwt_secret_token_secure_key_92817293';

    const expectedSig = crypto.createHmac('sha256', secret).update(payloadB64).digest('base64url');
    if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSig))) {
      return { valid: false };
    }

    try {
      const payload = JSON.parse(Buffer.from(payloadB64, 'base64url').toString('utf-8'));
      if (Date.now() > payload.exp) {
        return { valid: false };
      }
      return { valid: true, username: payload.username };
    } catch {
      return { valid: false };
    }
  }

  // --- Google Sheets Integration ---
  public formatOrderForGoogleSheets(order: Order) {
    const productNames = order.items.map(i => i.name).join('; ');
    const skus = order.items.map(i => i.sku).join('; ');
    const quantities = order.items.map(i => `${i.name} (${i.quantity})`).join('; ');
    const unitPrices = order.items.map(i => `${i.sku}: BDT ${i.price}`).join('; ');

    return {
      orderId: order.id,
      dateTime: new Date(order.createdAt).toLocaleString('en-GB', { timeZone: 'Asia/Dhaka' }),
      customerName: order.customer.name,
      phone: order.customer.phone,
      fullAddress: order.customer.address,
      areaCity: `${order.customer.city} (${order.customer.location === 'inside_dhaka' ? 'Inside Dhaka' : 'Outside Dhaka'})`,
      productName: productNames,
      sku: skus,
      quantity: quantities,
      productPrice: unitPrices,
      deliveryCharge: order.pricing.deliveryCharge,
      advanceDeliveryPaid: order.pricing.advanceDeliveryPaid,
      remainingAmountDue: order.pricing.productAmountDue,
      totalOrderValue: order.pricing.totalOrderValue,
      paymentStatus: order.paymentStatus,
      orderStatus: order.orderStatus,
      deliveryStatus: order.deliveryStatus,
      courier: order.courier.name,
      trackingId: order.courier.trackingId || 'N/A',
      customerNote: order.customer.notes || 'None',
      adminNote: order.adminNotes || 'None'
    };
  }

  public async syncOrderToGoogleSheets(order: Order): Promise<{ success: boolean; message: string }> {
    const webhookUrl = this.data.settings.googleSheetsWebhookUrl || process.env.GOOGLE_SHEETS_WEBHOOK_URL;
    if (!webhookUrl || !webhookUrl.startsWith('http')) {
      return { success: false, message: 'Google Sheets webhook URL is not configured.' };
    }

    const rowData = this.formatOrderForGoogleSheets(order);

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8000);

      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'append_order',
          order: rowData
        }),
        signal: controller.signal
      });
      clearTimeout(timeoutId);

      if (response.ok) {
        order.syncedToGoogleSheets = true;
        order.sheetsSyncTimestamp = new Date().toISOString();
        this.save();
        return { success: true, message: 'Successfully synced to Google Sheets.' };
      } else {
        return { success: false, message: `Webhook responded with status ${response.status}` };
      }
    } catch (err: any) {
      console.error('Failed to post to Google Sheets webhook:', err);
      return { success: false, message: err.name === 'AbortError' ? 'Webhook request timed out after 8s' : (err.message || 'Network error connecting to webhook') };
    }
  }

  public exportOrdersToCSV(): string {
    const headers = [
      'Order ID',
      'Date/Time',
      'Customer Name',
      'Phone',
      'Full Address',
      'Area/City',
      'Product Name',
      'SKU',
      'Quantity',
      'Product Price (BDT)',
      'Delivery Charge (BDT)',
      'Advance Delivery Charge Paid (BDT)',
      'Remaining Amount Due (BDT)',
      'Total Order Value (BDT)',
      'Payment Status',
      'Order Status',
      'Delivery Status',
      'Courier',
      'Tracking ID',
      'Customer Note',
      'Admin Note'
    ];

    const rows = this.data.orders.map(order => {
      const row = this.formatOrderForGoogleSheets(order);
      return [
        row.orderId,
        `"${row.dateTime}"`,
        `"${row.customerName.replace(/"/g, '""')}"`,
        `"${row.phone}"`,
        `"${row.fullAddress.replace(/"/g, '""')}"`,
        `"${row.areaCity.replace(/"/g, '""')}"`,
        `"${row.productName.replace(/"/g, '""')}"`,
        `"${row.sku}"`,
        `"${row.quantity}"`,
        order.pricing.subtotal,
        row.deliveryCharge,
        row.advanceDeliveryPaid,
        row.remainingAmountDue,
        row.totalOrderValue,
        `"${row.paymentStatus}"`,
        `"${row.orderStatus}"`,
        `"${row.deliveryStatus}"`,
        `"${row.courier}"`,
        `"${row.trackingId}"`,
        `"${row.customerNote.replace(/"/g, '""')}"`,
        `"${row.adminNote.replace(/"/g, '""')}"`
      ].join(',');
    });

    return [headers.join(','), ...rows].join('\n');
  }

  // --- bKash Payment & Audit Tracking ---
  public isTransactionVerified(trxId: string): boolean {
    if (!trxId) return false;
    const cleanTrx = trxId.trim().toUpperCase();
    if (!this.data.verifiedTransactions) this.data.verifiedTransactions = [];
    return this.data.verifiedTransactions.some(v => v.trxId.toUpperCase() === cleanTrx);
  }

  public getVerifiedTransaction(trxId: string): VerifiedTransactionRecord | undefined {
    if (!trxId) return undefined;
    const cleanTrx = trxId.trim().toUpperCase();
    if (!this.data.verifiedTransactions) this.data.verifiedTransactions = [];
    return this.data.verifiedTransactions.find(v => v.trxId.toUpperCase() === cleanTrx);
  }

  public recordVerifiedTransaction(record: VerifiedTransactionRecord): void {
    if (!this.data.verifiedTransactions) this.data.verifiedTransactions = [];
    const cleanTrx = record.trxId.trim().toUpperCase();
    if (!this.isTransactionVerified(cleanTrx)) {
      this.data.verifiedTransactions.push({
        ...record,
        trxId: cleanTrx
      });
      this.saveImmediate();
    }
  }

  public logPaymentAudit(record: Omit<PaymentAuditRecord, 'id' | 'timestamp'>): void {
    if (!this.data.paymentAuditLogs) this.data.paymentAuditLogs = [];
    const entry: PaymentAuditRecord = {
      id: 'aud-' + crypto.randomBytes(4).toString('hex'),
      timestamp: new Date().toISOString(),
      ...record
    };
    this.data.paymentAuditLogs.unshift(entry);
    if (this.data.paymentAuditLogs.length > 500) {
      this.data.paymentAuditLogs = this.data.paymentAuditLogs.slice(0, 500);
    }
    this.save();
  }

  public getPaymentAuditLogs(limit = 100): PaymentAuditRecord[] {
    if (!this.data.paymentAuditLogs) this.data.paymentAuditLogs = [];
    return this.data.paymentAuditLogs.slice(0, limit);
  }
}

export const db = new Database();
