import express, { Request, Response, NextFunction } from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import cookieParser from 'cookie-parser';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { db } from './server/db.js';
import type { Order } from './src/types.js';

// ==========================================
// SUPABASE CLIENT INITIALIZATION
// ==========================================
// Credentials provided for Supabase database integration:
export const SUPABASE_URL = process.env.SUPABASE_URL || 'https://spqpwimhruoqjmbpgjka.supabase.co';
export const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || 'sb_publishable_IP-Cf6UmZFiA7NntczH9ug_6ZJrZKK2';
export const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || 'sb_secret_iZ4Fs7v_kR_CdzfmNDTIsA_PF5oq5j5';

// Use Service Role Key for server-side trusted DB queries, fallback to Anon Key
const supabaseActiveKey = SUPABASE_SERVICE_ROLE_KEY || SUPABASE_ANON_KEY;

// URL validation helper to prevent startup crashes when SUPABASE_URL is not an HTTP URL
function isValidHttpUrl(str: string): boolean {
  if (!str) return false;
  try {
    const u = new URL(str);
    return u.protocol === 'http:' || u.protocol === 'https:';
  } catch {
    return false;
  }
}

// Normalize Supabase URL (e.g. project ref formatted to https://<ref>.supabase.co)
function getResolvedSupabaseUrl(): string {
  const raw = (process.env.SUPABASE_URL || SUPABASE_URL).trim();
  if (!raw) return '';
  if (raw.startsWith('http://') || raw.startsWith('https://')) {
    return raw;
  }
  if (/^[a-zA-Z0-9_-]+$/.test(raw)) {
    return `https://${raw}.supabase.co`;
  }
  return raw;
}

let supabaseInstance: SupabaseClient | null = null;
const initialSupabaseUrl = getResolvedSupabaseUrl();

if (isValidHttpUrl(initialSupabaseUrl)) {
  try {
    supabaseInstance = createClient(initialSupabaseUrl, supabaseActiveKey, {
      auth: { persistSession: false, autoRefreshToken: false }
    });
    console.log(`[Supabase] Client initialized successfully with ${initialSupabaseUrl}`);
  } catch (err) {
    console.error('[Supabase] Initialization error:', err);
  }
} else {
  console.log('[Supabase] Client initialized with credentials. Awaiting valid SUPABASE_URL (e.g. https://<project-ref>.supabase.co).');
}

export function getSupabase(): SupabaseClient | null {
  if (supabaseInstance) return supabaseInstance;
  const currentUrl = getResolvedSupabaseUrl();
  if (isValidHttpUrl(currentUrl)) {
    try {
      supabaseInstance = createClient(currentUrl, supabaseActiveKey, {
        auth: { persistSession: false, autoRefreshToken: false }
      });
      return supabaseInstance;
    } catch (e) {
      console.error('[Supabase] Lazy initialization error:', e);
      return null;
    }
  }
  return null;
}

let cachedOrdersColumns: Set<string> | null = null;
let lastColumnsFetchTime = 0;

export async function getOrdersTableColumns(): Promise<Set<string>> {
  const now = Date.now();
  if (cachedOrdersColumns && now - lastColumnsFetchTime < 60000) {
    return cachedOrdersColumns;
  }
  try {
    const currentUrl = getResolvedSupabaseUrl();
    if (isValidHttpUrl(currentUrl)) {
      const resp = await fetch(`${currentUrl.replace(/\/$/, '')}/rest/v1/`, {
        headers: {
          apikey: supabaseActiveKey,
          Authorization: `Bearer ${supabaseActiveKey}`
        }
      });
      if (resp.ok) {
        const spec: any = await resp.json();
        const props = spec?.definitions?.orders?.properties;
        if (props && typeof props === 'object') {
          cachedOrdersColumns = new Set(Object.keys(props));
          lastColumnsFetchTime = now;
          return cachedOrdersColumns;
        }
      }
    }
  } catch (e) {
    // Non-blocking schema discovery
  }
  if (cachedOrdersColumns) return cachedOrdersColumns;
  return new Set(['order_id', 'created_at', 'customer_name', 'address', 'phone', 'total_price']);
}

// ==========================================
// GOOGLE WEB APP WEBHOOK INTEGRATION
// ==========================================
export const GOOGLE_WEBAPP_URL =
  process.env.GOOGLE_WEBAPP_URL ||
  'https://script.google.com/macros/s/AKfycbwLsJ4UDeJ1jZCDdMdHr97w0qcuzCP1Z4hk9gK3UXwTF4GwB6OYl-EHWNsJ_8m3SoIiFQ/exec';

export async function sendOrderToGoogleWebApp(orderDetails: {
  order_id: string | number;
  customer_name: string;
  phone: string;
  address: string;
  total_price: number;
}) {
  const url = process.env.GOOGLE_WEBAPP_URL || GOOGLE_WEBAPP_URL;
  if (!url) return null;

  try {
    console.log(`[Google WebApp] Sending order ${orderDetails.order_id} to Web App:`, url);
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(orderDetails),
      redirect: 'follow'
    });

    console.log(`[Google WebApp] Webhook response HTTP ${response.status}`);
    return { success: response.ok, status: response.status };
  } catch (err: any) {
    console.error('[Google WebApp] Failed to dispatch order to Google Web App:', err?.message || err);
    return { success: false, error: err?.message || err };
  }
}

// ==========================================
// bKASH SMS PARSING & AUTOMATED VERIFICATION
// ==========================================

export const BKASH_WEBHOOK_SECRET = process.env.BKASH_WEBHOOK_SECRET || 'sparkzen_bkash_webhook_secret_key_849201';

// Helper to mask phone numbers safely in logs (e.g. 01712345678 -> 017****5678)
export function maskPhone(phone?: string): string {
  if (!phone) return 'UNKNOWN';
  const clean = phone.replace(/[^0-9+]/g, '');
  if (clean.length < 7) return '***';
  return clean.slice(0, 3) + '****' + clean.slice(-4);
}

// bKash SMS Parsing (Regex)
export function parseBkashSMS(smsText: string) {
  if (!smsText || typeof smsText !== 'string') return null;
  const trxMatch = smsText.match(/TrxID\s+([A-Z0-9]+)/i);
  const amountMatch = smsText.match(/(?:Tk|BDT|Tk\.)\s*([\d,]+\.?\d*)/i);
  const senderMatch = smsText.match(/(?:from|sender)\s+(\+?8801[3-9]\d{8}|01[3-9]\d{8})/i);
  const dateMatch = smsText.match(/at\s+(\d{1,2}\/\d{1,2}\/\d{2,4}\s+\d{1,2}:\d{2})/i);

  if (trxMatch && amountMatch) {
    return {
      trx_id: trxMatch[1].trim().toUpperCase(),
      amount: parseFloat(amountMatch[1].replace(/,/g, '')),
      sender: senderMatch ? senderMatch[1].trim() : undefined,
      timestamp: dateMatch ? dateMatch[1].trim() : undefined
    };
  }
  return null;
}

// Reseller auto-order logic
export async function placeResellerOrder(orderData: any) {
  // Call your Reseller site API here
  const targetId = orderData.id || orderData.order_id;
  console.log("Placing order on Reseller Site for Order ID:", targetId);
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const UPLOADS_DIR = path.join(process.cwd(), 'public', 'images', 'uploads');

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Ensure public upload directory exists
  if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  }

  // Body and Cookie Parsers
  app.use(express.json({ limit: '15mb' }));
  app.use(express.urlencoded({ extended: true, limit: '15mb' }));
  app.use(cookieParser());

  // Static serving for public uploaded and local images
  app.use('/images', express.static(path.join(process.cwd(), 'public', 'images')));

  // Request IP helper
  const getClientIp = (req: Request): string => {
    const forwarded = req.headers['x-forwarded-for'];
    if (typeof forwarded === 'string') {
      return forwarded.split(',')[0].trim();
    }
    return req.socket.remoteAddress || 'unknown';
  };

  // Helper to extract token from header, cookie, or query
  const extractAdminToken = (req: Request): string => {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      return authHeader.split(' ')[1].trim();
    }
    if (req.cookies && req.cookies.sparkzen_admin_token) {
      return req.cookies.sparkzen_admin_token;
    }
    if (req.query.token && typeof req.query.token === 'string') {
      return req.query.token;
    }
    return '';
  };

  // Auth Middleware for protected Admin routes
  const requireAdminAuth = (req: Request, res: Response, next: NextFunction) => {
    const token = extractAdminToken(req);

    if (!token) {
      return res.status(401).json({ error: 'Unauthorized: Missing or invalid authentication token' });
    }

    const { valid, username } = db.verifySessionToken(token);
    if (!valid || !username) {
      return res.status(401).json({ error: 'Unauthorized: Session expired or invalid. Please log in again.' });
    }

    (req as any).adminUser = username;
    (req as any).adminToken = token;
    next();
  };

  // ==========================================
  // PUBLIC STOREFRONT API ROUTES
  // ==========================================

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      brand: 'SPARK Zen',
      timestamp: new Date().toISOString(),
      supabaseConfigured: Boolean(getSupabase())
    });
  });

  // Get active products
  app.get('/api/products', (req, res) => {
    try {
      const products = db.getProducts(false);
      res.json(products);
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to fetch products' });
    }
  });

  // Get single product
  app.get('/api/products/:id', (req, res) => {
    try {
      const product = db.getProductById(req.params.id);
      if (!product) {
        return res.status(404).json({ error: 'Product not found' });
      }
      res.json(product);
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to fetch product' });
    }
  });

  // Get public store settings
  app.get('/api/settings', (req, res) => {
    try {
      const settings = db.getSettings();
      // Omit any internal secrets from public payload
      const publicSettings = {
        ...settings,
        googleSheetsWebhookUrl: undefined, // Hidden from public
        isGoogleSheetsConfigured: Boolean(settings.googleSheetsWebhookUrl)
      };
      res.json(publicSettings);
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to fetch settings' });
    }
  });

  // Place order
  app.post('/api/orders', async (req, res) => {
    try {
      const { customer, items, advancePaymentDetails } = req.body;

      if (!customer || !customer.name || !customer.phone || !customer.address || !customer.city) {
        return res.status(400).json({ error: 'Please provide all required delivery details (Name, Phone, Address, City).' });
      }

      // Validate Bangladesh phone number pattern
      const cleanPhone = customer.phone.replace(/[^0-9+]/g, '');
      if (!/^(?:\+8801|01)[3-9]\d{8}$/.test(cleanPhone)) {
        return res.status(400).json({ error: 'Please enter a valid 11-digit Bangladeshi mobile number (e.g. 017XXXXXXXX).' });
      }

      if (!items || !Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ error: 'Cart cannot be empty.' });
      }

      // Verify each item exists and stock is sufficient
      const validatedItems = [];
      for (const item of items) {
        const product = db.getProductById(item.productId);
        if (!product) {
          return res.status(400).json({ error: `Product ${item.name || item.productId} no longer exists.` });
        }
        if (product.status !== 'active') {
          return res.status(400).json({ error: `Product "${product.name}" is currently unavailable.` });
        }
        if (product.stockQuantity < item.quantity) {
          return res.status(400).json({
            error: `Insufficient stock for "${product.name}". Available: ${product.stockQuantity}, Requested: ${item.quantity}.`
          });
        }

        validatedItems.push({
          productId: product.id,
          name: product.name,
          sku: product.sku,
          price: product.price,
          quantity: item.quantity,
          subtotal: product.price * item.quantity,
          image: product.images[0] || '/sparkzen-logo.png'
        });
      }

      // Price calculation
      const settings = db.getSettings();
      const deliveryCharge = customer.location === 'outside_dhaka'
        ? (settings.outsideDhakaDeliveryCharge || 130)
        : (settings.insideDhakaDeliveryCharge || 70);
      const subtotal = validatedItems.reduce((sum, item) => sum + item.subtotal, 0);
      const totalPrice = subtotal + deliveryCharge;
      // Security Rule: Customer submitting a TrxID at checkout does NOT mark it paid.
      // Payment remains pending until verified by the bKash SMS webhook or admin.
      const advancePaid = 0;
      const productAmountDue = totalPrice;
      const fullAddress = `${customer.address.trim()}, ${customer.city.trim()}`;
      const submittedTrxId = advancePaymentDetails?.transactionId?.trim().toUpperCase() || null;

      // Deduct stock quantity
      for (const it of validatedItems) {
        const prod = db.getProductById(it.productId);
        if (prod) {
          prod.stockQuantity = Math.max(0, prod.stockQuantity - it.quantity);
        }
      }
      db.saveImmediate();

      // =========================================================================
      // SUPABASE PERSISTENCE: Save order adhering dynamically to table schema
      // =========================================================================
      const knownCols = await getOrdersTableColumns();
      const supabasePayload: Record<string, any> = {
        customer_name: customer.name.trim(),
        phone: cleanPhone,
        address: fullAddress,
        total_price: totalPrice
      };

      if (knownCols.has('payment_status')) {
        supabasePayload.payment_status = 'pending';
      }
      if (knownCols.has('submitted_trx_id') && submittedTrxId) {
        supabasePayload.submitted_trx_id = submittedTrxId;
      }

      const supabase = getSupabase();
      let supabaseInsertSuccess = false;
      let insertedRow: any = null;

      if (supabase) {
        try {
          const { data, error } = await supabase
            .from('orders')
            .insert([supabasePayload])
            .select();

          if (error) {
            // Minimal fallback schema if custom payload encounters column cache discrepancy
            const fallbackPayload = {
              customer_name: customer.name.trim(),
              phone: cleanPhone,
              address: fullAddress,
              total_price: totalPrice
            };
            const fallbackRes = await supabase.from('orders').insert([fallbackPayload]).select();
            if (fallbackRes.error) {
              console.error('[Supabase] Insert failed:', fallbackRes.error.message || fallbackRes.error);
            } else {
              insertedRow = fallbackRes.data && fallbackRes.data.length > 0 ? fallbackRes.data[0] : null;
              supabaseInsertSuccess = true;
            }
          } else {
            console.log('[Supabase] Order inserted successfully into orders table:', data);
            insertedRow = data && data.length > 0 ? data[0] : null;
            supabaseInsertSuccess = true;
          }
        } catch (sbErr: any) {
          console.error('[Supabase] Exception during order insert:', sbErr.message || sbErr);
        }
      } else {
        console.warn('[Supabase] Supabase client is not connected. Configure SUPABASE_URL in your environment.');
      }

      // Generate order ID
      const sbRawId = insertedRow?.order_id ?? insertedRow?.id;
      const orderId = sbRawId
        ? (typeof sbRawId === 'number' ? `SZ-SB-${sbRawId}` : String(sbRawId))
        : `SZ-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

      const orderResult = {
        id: orderId,
        customer: {
          name: customer.name.trim(),
          phone: cleanPhone,
          address: customer.address.trim(),
          city: customer.city.trim(),
          location: customer.location === 'outside_dhaka' ? 'outside_dhaka' : 'inside_dhaka',
          notes: customer.notes?.trim() || ''
        },
        items: validatedItems,
        pricing: {
          subtotal,
          deliveryCharge,
          advanceDeliveryPaid: advancePaid,
          productAmountDue,
          totalOrderValue: totalPrice
        },
        paymentStatus: 'delivery_charge_pending',
        orderStatus: 'new',
        deliveryStatus: 'pending_dispatch',
        courier: {
          name: customer.location === 'outside_dhaka' ? 'Steadfast Courier' : 'Pathao Courier',
          trackingId: ''
        },
        advancePaymentDetails: advancePaymentDetails ? {
          method: advancePaymentDetails.method || 'bkash',
          transactionId: submittedTrxId || '',
          senderNumber: advancePaymentDetails.senderNumber?.trim() || '',
          paidAt: undefined // will be set once verified by webhook or admin
        } : undefined,
        createdAt: insertedRow?.created_at || new Date().toISOString(),
        syncedToSupabase: supabaseInsertSuccess
      };

      // Ensure order is accessible in local store for Admin Panel and instant webhook matching
      db.upsertOrder(orderResult as any);

      if (supabaseInsertSuccess) {
        // When new order is inserted into Supabase, dispatch POST request to Google Web App URL
        const googleWebAppPayload = {
          order_id: sbRawId ?? orderId,
          customer_name: customer.name.trim(),
          phone: cleanPhone,
          address: fullAddress,
          total_price: totalPrice
        };

        sendOrderToGoogleWebApp(googleWebAppPayload).catch(err => {
          console.error('[Google WebApp] Background delivery error:', err?.message || err);
        });
      }

      // Synchronize to Google Sheets if configured
      db.syncOrderToGoogleSheets(orderResult as any).catch(err => {
        console.warn('Google Sheets sync skipped or error:', err?.message);
      });

      res.status(201).json(orderResult);
    } catch (err: any) {
      console.error('Order creation error:', err);
      res.status(500).json({ error: err.message || 'Failed to process order' });
    }
  });

  // Public order tracking by query (Phone or Order ID) - defined before /:id
  app.get('/api/orders/track', (req, res) => {
    try {
      const { orderId, phone } = req.query;
      if (!orderId && !phone) {
        return res.status(400).json({ error: 'Please provide an Order ID or Phone number to track.' });
      }
      let orders = db.getOrders();
      if (orderId && typeof orderId === 'string') {
        const cleanId = orderId.trim().toLowerCase();
        orders = orders.filter(o => o.id.toLowerCase() === cleanId);
      }
      if (phone && typeof phone === 'string') {
        const cleanPhone = phone.replace(/[^0-9]/g, '');
        orders = orders.filter(o => o.customer.phone.replace(/[^0-9]/g, '').includes(cleanPhone));
      }
      if (orders.length === 0) {
        return res.status(404).json({ error: 'No matching orders found' });
      }
      res.json({ orders });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to track order' });
    }
  });

  // Get order by ID (customer order confirmation & tracking)
  app.get('/api/orders/:id', (req, res) => {
    try {
      const order = db.getOrderById(req.params.id);
      if (!order) {
        return res.status(404).json({ error: 'Order not found' });
      }
      res.json(order);
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to fetch order details' });
    }
  });

  // Submit advance payment details for existing order
  // Security Rule: Customer submitting a TrxID only records it as submitted.
  // It remains pending until verified by the bKash SMS webhook or admin.
  app.post('/api/orders/:id/advance-payment', async (req, res) => {
    try {
      const { method, transactionId, senderNumber } = req.body;
      const order = db.getOrderById(req.params.id);
      if (!order) {
        return res.status(404).json({ error: 'Order not found' });
      }

      if (!transactionId || !transactionId.trim()) {
        return res.status(400).json({ error: 'Please enter the transaction ID (TrxID).' });
      }

      const cleanTrx = transactionId.trim().toUpperCase();

      const updated = db.updateOrder(order.id, {
        paymentStatus: 'delivery_charge_pending',
        advancePaymentDetails: {
          method: method || 'bkash',
          transactionId: cleanTrx,
          senderNumber: senderNumber?.trim() || '',
          paidAt: undefined // Will be set when verified by webhook or admin
        } as any,
        adminNotes: order.adminNotes
          ? `${order.adminNotes} | Customer submitted TrxID: ${cleanTrx} (Pending SMS verification)`
          : `Customer submitted TrxID: ${cleanTrx} (Pending SMS verification)`
      });

      // Update Supabase if connected
      const supabase = getSupabase();
      if (supabase) {
        try {
          const knownCols = await getOrdersTableColumns();
          const updateData: Record<string, any> = {};
          if (knownCols.has('submitted_trx_id')) {
            updateData.submitted_trx_id = cleanTrx;
          }
          if (knownCols.has('payment_status')) {
            updateData.payment_status = 'pending';
          }
          if (Object.keys(updateData).length > 0) {
            const sbKeyCol = order.id.startsWith('SZ-SB-') ? 'order_id' : 'id';
            const sbKeyVal = order.id.startsWith('SZ-SB-') ? parseInt(order.id.replace('SZ-SB-', ''), 10) : order.id;
            await supabase
              .from('orders')
              .update(updateData)
              .eq(sbKeyCol, sbKeyVal);
          }
        } catch (sbErr) {
          // Schema fallback
        }
      }

      res.json({
        message: 'bKash Transaction ID submitted. Verification is in progress via bKash SMS.',
        order: updated
      });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to update payment information' });
    }
  });

  // =========================================================================
  // SECURE bKASH SMS PAYMENT WEBHOOK & REAL-TIME VERIFICATION ENGINE
  // =========================================================================

  const handleBkashSmsWebhook = async (req: Request, res: Response) => {
    const clientIp = getClientIp(req);

    // 1. Accept only HTTPS requests in production
    const isHttps = req.secure || req.headers['x-forwarded-proto'] === 'https';
    if (process.env.NODE_ENV === 'production' && !isHttps) {
      db.logPaymentAudit({
        clientIp,
        trxId: 'UNKNOWN',
        amount: 0,
        senderMasked: 'UNKNOWN',
        status: 'rejected',
        reason: 'insecure_connection'
      });
      return res.status(403).json({
        status: 'rejected',
        reason: 'insecure_connection',
        message: 'HTTPS connection is strictly required for payment webhooks.'
      });
    }

    // 2. Secret authentication token validation
    const authHeader = req.headers['x-bkash-webhook-token'] ||
                       req.headers['authorization'] ||
                       req.query.token ||
                       req.query.secret;

    let token = '';
    if (typeof authHeader === 'string') {
      if (authHeader.startsWith('Bearer ')) {
        token = authHeader.slice(7).trim();
      } else {
        token = authHeader.trim();
      }
    }

    if (!token || token !== BKASH_WEBHOOK_SECRET) {
      db.logPaymentAudit({
        clientIp,
        trxId: 'UNKNOWN',
        amount: 0,
        senderMasked: 'UNKNOWN',
        status: 'rejected',
        reason: 'unauthorized'
      });
      return res.status(401).json({
        status: 'rejected',
        reason: 'unauthorized',
        message: 'Invalid or missing webhook authentication token.'
      });
    }

    // 3. Extract and parse parameters from JSON body or raw SMS text
    const { message, sms_body, body: rawBody } = req.body || {};
    const rawSmsText = message || sms_body || rawBody;

    let trxId = req.body?.trx_id ? String(req.body.trx_id).trim().toUpperCase() : '';
    let amount = req.body?.amount !== undefined ? Number(req.body.amount) : NaN;
    let senderPhone = req.body?.sender ? String(req.body.sender).trim() : '';
    let timestampRaw = req.body?.timestamp || req.body?.sms_timestamp;

    if (rawSmsText && typeof rawSmsText === 'string') {
      const parsed = parseBkashSMS(rawSmsText);
      if (parsed) {
        if (!trxId) trxId = parsed.trx_id;
        if (isNaN(amount)) amount = parsed.amount;
        if (!senderPhone && parsed.sender) senderPhone = parsed.sender;
        if (!timestampRaw && parsed.timestamp) timestampRaw = parsed.timestamp;
      }
    }

    // 4. Validate transaction ID (8 to 12 alphanumeric characters)
    if (!trxId || !/^[A-Z0-9]{8,12}$/i.test(trxId)) {
      db.logPaymentAudit({
        clientIp,
        trxId: trxId || 'EMPTY',
        amount: isNaN(amount) ? 0 : amount,
        senderMasked: maskPhone(senderPhone),
        status: 'rejected',
        reason: 'invalid_transaction_id'
      });
      return res.status(400).json({
        status: 'rejected',
        reason: 'invalid_transaction_id',
        message: 'Transaction ID is missing or invalid (expected 8-12 alphanumeric characters).'
      });
    }

    // 5. Validate amount (must be positive number)
    if (isNaN(amount) || amount <= 0) {
      db.logPaymentAudit({
        clientIp,
        trxId,
        amount: isNaN(amount) ? 0 : amount,
        senderMasked: maskPhone(senderPhone),
        status: 'rejected',
        reason: 'invalid_amount'
      });
      return res.status(400).json({
        status: 'rejected',
        reason: 'invalid_amount',
        message: 'Amount must be a positive number.'
      });
    }

    // 6. Validate timestamp (if provided)
    if (timestampRaw) {
      const txTime = new Date(timestampRaw).getTime();
      if (!isNaN(txTime)) {
        const now = Date.now();
        const fifteenMinAhead = now + 15 * 60 * 1000;
        const fortyEightHoursAgo = now - 48 * 60 * 60 * 1000;
        if (txTime > fifteenMinAhead) {
          db.logPaymentAudit({
            clientIp,
            trxId,
            amount,
            senderMasked: maskPhone(senderPhone),
            status: 'rejected',
            reason: 'future_timestamp'
          });
          return res.status(400).json({
            status: 'rejected',
            reason: 'future_timestamp',
            message: 'Transaction timestamp is in the future.'
          });
        }
        if (txTime < fortyEightHoursAgo) {
          db.logPaymentAudit({
            clientIp,
            trxId,
            amount,
            senderMasked: maskPhone(senderPhone),
            status: 'rejected',
            reason: 'expired_transaction'
          });
          return res.status(400).json({
            status: 'rejected',
            reason: 'expired_transaction',
            message: 'Transaction is older than 48 hours.'
          });
        }
      }
    }

    // 7. Prevent duplicate transaction IDs (Atomic anti-replay check)
    if (db.isTransactionVerified(trxId)) {
      const verified = db.getVerifiedTransaction(trxId);
      db.logPaymentAudit({
        clientIp,
        trxId,
        amount,
        senderMasked: maskPhone(senderPhone),
        status: 'already_verified',
        matchedOrderId: verified?.orderId
      });
      return res.status(200).json({
        status: 'already_verified',
        message: 'Transaction ID has already been verified and processed.',
        trx_id: trxId,
        order_id: verified?.orderId
      });
    }

    const existingPaid = db.getOrders().find(o =>
      o.advancePaymentDetails?.transactionId?.toUpperCase() === trxId &&
      o.paymentStatus === 'delivery_charge_paid'
    );
    if (existingPaid) {
      db.recordVerifiedTransaction({
        trxId,
        orderId: existingPaid.id,
        amount,
        sender: senderPhone,
        verifiedAt: new Date().toISOString(),
        verifiedBy: 'webhook'
      });
      db.logPaymentAudit({
        clientIp,
        trxId,
        amount,
        senderMasked: maskPhone(senderPhone),
        status: 'already_verified',
        matchedOrderId: existingPaid.id
      });
      return res.status(200).json({
        status: 'already_verified',
        message: 'Transaction ID has already been verified for an order.',
        trx_id: trxId,
        order_id: existingPaid.id
      });
    }

    // 8. Match pending order
    const targetOrderId = req.body?.order_id || req.query?.order_id;
    let matchedOrder: Order | undefined;

    if (targetOrderId) {
      matchedOrder = db.getOrderById(String(targetOrderId));
    }

    if (!matchedOrder) {
      matchedOrder = db.getOrders().find(o =>
        o.advancePaymentDetails?.transactionId?.toUpperCase() === trxId ||
        (o as any).submitted_trx_id?.toUpperCase() === trxId
      );
    }

    if (!matchedOrder && senderPhone) {
      const cleanSender = senderPhone.replace(/[^0-9]/g, '').slice(-10);
      if (cleanSender.length === 10) {
        matchedOrder = db.getOrders().find(o => {
          const cleanCustPhone = o.customer.phone.replace(/[^0-9]/g, '').slice(-10);
          return o.paymentStatus === 'delivery_charge_pending' && cleanCustPhone === cleanSender;
        });
      }
    }

    // Also query Supabase if available
    const supabase = getSupabase();
    let supabaseOrderRow: any = null;
    if (supabase) {
      try {
        const knownCols = await getOrdersTableColumns();
        if (knownCols.has('submitted_trx_id')) {
          const sbTrxRes = await supabase
            .from('orders')
            .select('*')
            .eq('submitted_trx_id', trxId)
            .limit(1);
          if (sbTrxRes.data && sbTrxRes.data.length > 0) {
            supabaseOrderRow = sbTrxRes.data[0];
          }
        }

        if (!supabaseOrderRow && targetOrderId) {
          const rawNum = String(targetOrderId).replace(/[^0-9]/g, '');
          if (rawNum) {
            const sbIdRes = await supabase
              .from('orders')
              .select('*')
              .or(`order_id.eq.${rawNum},id.eq.${rawNum}`)
              .limit(1);
            if (sbIdRes.data && sbIdRes.data.length > 0) {
              supabaseOrderRow = sbIdRes.data[0];
            }
          }
        }
      } catch (sbErr) {
        // Non-blocking
      }
    }

    if (!matchedOrder && !supabaseOrderRow) {
      db.logPaymentAudit({
        clientIp,
        trxId,
        amount,
        senderMasked: maskPhone(senderPhone),
        status: 'no_matching_order'
      });
      return res.status(200).json({
        status: 'no_matching_order',
        message: 'No pending order found matching this TrxID or customer details.',
        trx_id: trxId,
        amount
      });
    }

    // 9. Match received amount against expected delivery charge
    // Inside Dhaka: 70 BDT. Outside Dhaka: 130 BDT.
    const settings = db.getSettings();
    const isInsideDhaka = matchedOrder
      ? matchedOrder.customer.location === 'inside_dhaka'
      : (supabaseOrderRow?.address ? supabaseOrderRow.address.toLowerCase().includes('dhaka') : true);

    const expectedDeliveryCharge = matchedOrder?.pricing?.deliveryCharge ??
      (isInsideDhaka ? (settings.insideDhakaDeliveryCharge || 70) : (settings.outsideDhakaDeliveryCharge || 130));

    if (amount < expectedDeliveryCharge) {
      const matchedId = matchedOrder?.id ?? String(supabaseOrderRow?.order_id ?? supabaseOrderRow?.id);
      db.logPaymentAudit({
        clientIp,
        trxId,
        amount,
        senderMasked: maskPhone(senderPhone),
        status: 'rejected',
        reason: 'insufficient_amount',
        matchedOrderId: matchedId
      });
      return res.status(422).json({
        status: 'rejected',
        reason: 'insufficient_amount',
        message: `Received amount (BDT ${amount}) is less than expected delivery charge (BDT ${expectedDeliveryCharge}).`,
        expected_delivery_charge: expectedDeliveryCharge,
        received_amount: amount,
        order_id: matchedId,
        location: isInsideDhaka ? 'inside_dhaka' : 'outside_dhaka'
      });
    }

    // 10. SUCCESS! Update order in local DB, sync Supabase, and prevent duplicate reuse
    const orderId = matchedOrder?.id ?? String(supabaseOrderRow?.order_id ?? supabaseOrderRow?.id);
    let updatedOrder: Order | null = null;

    if (matchedOrder) {
      const subtotal = matchedOrder.pricing.subtotal;
      const totalOrderValue = matchedOrder.pricing.totalOrderValue;
      const advancePaid = expectedDeliveryCharge;
      const productDue = Math.max(0, totalOrderValue - advancePaid);

      updatedOrder = db.updateOrder(matchedOrder.id, {
        paymentStatus: 'delivery_charge_paid',
        orderStatus: 'confirmed',
        pricing: {
          ...matchedOrder.pricing,
          advanceDeliveryPaid: advancePaid,
          productAmountDue: productDue
        },
        advancePaymentDetails: {
          method: 'bkash',
          transactionId: trxId,
          senderNumber: senderPhone || matchedOrder.advancePaymentDetails?.senderNumber || matchedOrder.customer.phone,
          paidAt: new Date().toISOString(),
          verifiedBy: 'bkash_sms_webhook',
          verifiedAt: new Date().toISOString(),
          verifiedAmount: amount
        } as any,
        adminNotes: matchedOrder.adminNotes
          ? `${matchedOrder.adminNotes} | bKash SMS Verified BDT ${amount} (TrxID: ${trxId})`
          : `bKash SMS Verified BDT ${amount} (TrxID: ${trxId})`
      });
    }

    // Update Supabase payment status if columns exist in orders table
    if (supabase) {
      try {
        const knownCols = await getOrdersTableColumns();
        const updatePayload: Record<string, any> = {};
        if (knownCols.has('payment_status')) updatePayload.payment_status = 'verified';
        if (knownCols.has('status')) updatePayload.status = 'Paid';
        if (knownCols.has('verified_amount')) updatePayload.verified_amount = amount;
        if (knownCols.has('verified_trx_id')) updatePayload.verified_trx_id = trxId;
        if (knownCols.has('verified_at')) updatePayload.verified_at = new Date().toISOString();

        if (Object.keys(updatePayload).length > 0) {
          const sbKeyCol = supabaseOrderRow?.order_id !== undefined ? 'order_id' : (supabaseOrderRow?.id !== undefined ? 'id' : 'order_id');
          const sbKeyVal = supabaseOrderRow?.[sbKeyCol] ?? (orderId.startsWith('SZ-SB-') ? parseInt(orderId.replace('SZ-SB-', ''), 10) : orderId);

          const { error: sbUpdateErr } = await supabase
            .from('orders')
            .update(updatePayload)
            .eq(sbKeyCol, sbKeyVal);

          if (!sbUpdateErr) {
            console.log(`[Supabase] Order ${orderId} updated with verified payment status`);
          }
        }
      } catch (sbErr: any) {
        console.warn('[Supabase] Update exception:', sbErr.message || sbErr);
      }
    }

    // Record verified transaction ID (Atomic duplicate prevention)
    db.recordVerifiedTransaction({
      trxId,
      orderId,
      amount,
      sender: senderPhone,
      verifiedAt: new Date().toISOString(),
      verifiedBy: 'webhook'
    });

    // Log verification in audit trail
    db.logPaymentAudit({
      clientIp,
      trxId,
      amount,
      senderMasked: maskPhone(senderPhone),
      status: 'success',
      matchedOrderId: orderId
    });

    // Optional Reseller Auto-Order trigger
    placeResellerOrder(updatedOrder || matchedOrder || { id: orderId, amount }).catch(err => {
      console.warn('Reseller order background notification warning:', err);
    });

    return res.status(200).json({
      status: 'success',
      message: 'bKash payment verified successfully. Delivery charge marked as paid and remaining balance is Cash on Delivery.',
      order_id: orderId,
      trx_id: trxId,
      verified_amount: amount,
      delivery_charge_paid: expectedDeliveryCharge,
      product_amount_due: updatedOrder ? updatedOrder.pricing.productAmountDue : 'Cash on Delivery',
      payment_mode: 'cash_on_delivery'
    });
  };

  // Register production and legacy webhook endpoints
  app.post('/api/payment/bkash-sms', handleBkashSmsWebhook);
  app.post('/api/sms-webhook', handleBkashSmsWebhook);

  // Customer frontend real-time order status check endpoint
  app.get('/api/check-order-status', async (req: Request, res: Response) => {
    try {
      const { order_id } = req.query;
      if (!order_id) {
        return res.json({ status: 'Pending' });
      }

      const orderIdStr = String(order_id);
      const supabase = getSupabase();
      let order: any = null;

      if (supabase) {
        try {
          const rawNum = orderIdStr.replace(/[^0-9]/g, '');
          let sbQuery = supabase.from('orders').select('*');
          if (rawNum) {
            sbQuery = sbQuery.or(`id.eq.${rawNum},order_id.eq.${rawNum}`);
          } else {
            sbQuery = sbQuery.or(`id.eq.${orderIdStr},order_id.eq.${orderIdStr}`);
          }
          const resId = await sbQuery.limit(1);

          if (resId.data && resId.data.length > 0) {
            order = resId.data[0];
          }
        } catch (sbErr) {
          // non-blocking
        }
      }

      const local = db.getOrderById(orderIdStr);

      const isVerified =
        local?.paymentStatus === 'delivery_charge_paid' ||
        local?.paymentStatus === 'fully_paid' ||
        order?.payment_status === 'verified' ||
        order?.status === 'Paid';

      const isFailed =
        local?.paymentStatus === 'payment_failed' ||
        order?.payment_status === 'failed' ||
        order?.status === 'Payment Failed';

      if (isVerified) {
        return res.json({
          status: 'Paid',
          paymentStatus: 'delivery_charge_paid',
          advanceDeliveryPaid: local?.pricing?.advanceDeliveryPaid ?? order?.verified_amount ?? 70,
          productAmountDue: local?.pricing?.productAmountDue ?? 'Cash on Delivery'
        });
      }

      if (isFailed) {
        return res.json({
          status: 'Payment Failed',
          reason: order?.failure_reason || local?.adminNotes || 'Payment verification failed'
        });
      }

      return res.json({
        status: 'Pending',
        submitted_trx_id: local?.advancePaymentDetails?.transactionId || order?.submitted_trx_id
      });
    } catch (err) {
      res.json({ status: 'Pending' });
    }
  });

  // Admin audit logs for payment verifications
  app.get('/api/admin/payment-audits', requireAdminAuth, (req, res) => {
    try {
      const audits = db.getPaymentAuditLogs(100);
      res.json({
        audits,
        verifiedTransactions: db.getSettings() ? (db as any).data?.verifiedTransactions || [] : []
      });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to fetch payment audits' });
    }
  });

  // ==========================================
  // PRIVATE ADMIN API ROUTES (Protected)
  // ==========================================

  // Admin login with rate-limiting
  app.post('/api/admin/login', (req, res) => {
    const ip = getClientIp(req);
    const { username, password } = req.body;

    if (!db.checkRateLimit(ip)) {
      return res.status(429).json({
        error: 'Too many failed login attempts. Account temporarily locked for 15 minutes for security.'
      });
    }

    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password are required.' });
    }

    const isValid = db.verifyAdminCredentials(username, password);
    if (!isValid) {
      db.recordFailedLogin(ip);
      return res.status(401).json({ error: 'Invalid administrator credentials.' });
    }

    db.resetFailedLogin(ip);
    const token = db.createSessionToken(username);

    // Set secure HttpOnly session cookie
    res.cookie('sparkzen_admin_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
      path: '/'
    });

    res.json({
      token,
      user: {
        username,
        role: 'super_admin'
      }
    });
  });

  // Admin Logout: invalidate session & clear cookies
  app.post('/api/admin/logout', (req, res) => {
    const token = extractAdminToken(req);
    if (token) {
      db.revokeSessionToken(token);
    }
    res.clearCookie('sparkzen_admin_token', { path: '/' });
    res.json({ success: true, message: 'Logged out successfully.' });
  });

  // Verify session token
  app.get('/api/admin/verify', requireAdminAuth, (req, res) => {
    res.json({ valid: true, user: { username: (req as any).adminUser, role: 'super_admin' } });
  });

  // Admin dashboard stats
  app.get('/api/admin/stats', requireAdminAuth, (req, res) => {
    try {
      const stats = db.getStats();
      const recentOrders = db.getOrders().slice(0, 5);
      res.json({ stats, recentOrders });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to calculate stats' });
    }
  });

  // Admin Products
  app.get('/api/admin/products', requireAdminAuth, (req, res) => {
    try {
      const products = db.getProducts(true);
      res.json(products);
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to retrieve products' });
    }
  });

  app.post('/api/admin/products', requireAdminAuth, (req, res) => {
    try {
      const { name, price, stockQuantity, sku, category, description, shortDescription, specifications, images, featured, badge, status } = req.body;
      if (!name || price === undefined || stockQuantity === undefined || !sku) {
        return res.status(400).json({ error: 'Name, price, stock quantity, and SKU are required.' });
      }

      const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

      const newProduct = db.addProduct({
        name: name.trim(),
        slug,
        price: Number(price),
        discountPrice: req.body.discountPrice ? Number(req.body.discountPrice) : undefined,
        stockQuantity: Number(stockQuantity),
        sku: sku.trim(),
        category: category || 'General Tech',
        description: description || '',
        shortDescription: shortDescription || '',
        specifications: specifications || [],
        images: images && images.length > 0 ? images : ['/images/earbuds_product_1789388985434.jpg'],
        featured: Boolean(featured),
        badge: badge || undefined,
        status: status === 'disabled' ? 'disabled' : 'active'
      });

      res.status(201).json(newProduct);
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to add product' });
    }
  });

  const updateProductHandler = (req: Request, res: Response) => {
    try {
      const updated = db.updateProduct(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ error: 'Product not found' });
      }
      res.json(updated);
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to update product' });
    }
  };

  app.put('/api/admin/products/:id', requireAdminAuth, updateProductHandler);
  app.patch('/api/admin/products/:id', requireAdminAuth, updateProductHandler);

  app.delete('/api/admin/products/:id', requireAdminAuth, (req, res) => {
    try {
      const deleted = db.deleteProduct(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: 'Product not found' });
      }
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to delete product' });
    }
  });

  // Admin Orders
  app.get('/api/admin/orders', requireAdminAuth, async (req, res) => {
    try {
      const { search, orderStatus, paymentStatus } = req.query;
      let orders = db.getOrders({
        search: typeof search === 'string' ? search : undefined,
        orderStatus: typeof orderStatus === 'string' ? orderStatus : undefined,
        paymentStatus: typeof paymentStatus === 'string' ? paymentStatus : undefined
      });

      // If Supabase is connected, retrieve records from the Supabase orders table
      const supabase = getSupabase();
      if (supabase) {
        try {
          const { data: sbOrders, error } = await supabase
            .from('orders')
            .select('*')
            .order('created_at', { ascending: false });

          if (!error && sbOrders && sbOrders.length > 0) {
            const existingIds = new Set(orders.map(o => o.id));
            for (const row of sbOrders) {
              const rawRowId = row.order_id ?? row.id;
              const rowId = rawRowId ? (typeof rawRowId === 'number' ? `SZ-SB-${rawRowId}` : String(rawRowId)) : `SB-${row.created_at || Math.random()}`;
              if (!existingIds.has(rowId)) {
                orders.push({
                  id: rowId,
                  customer: {
                    name: row.customer_name || 'Customer',
                    phone: row.phone || '',
                    address: row.address || '',
                    city: 'Dhaka',
                    location: 'inside_dhaka'
                  },
                  items: [],
                  pricing: {
                    subtotal: Number(row.total_price) || 0,
                    deliveryCharge: 0,
                    advanceDeliveryPaid: 0,
                    productAmountDue: Number(row.total_price) || 0,
                    totalOrderValue: Number(row.total_price) || 0
                  },
                  paymentStatus: 'pending',
                  orderStatus: (row.status || 'new') as any,
                  deliveryStatus: (row.delivery_status || 'pending_dispatch') as any,
                  courier: { name: 'Pathao Courier', trackingId: '' },
                  createdAt: row.created_at || new Date().toISOString(),
                  syncedToSupabase: true
                } as any);
              }
            }
          }
        } catch (sbErr: any) {
          console.warn('[Supabase] Failed to fetch orders for admin:', sbErr.message || sbErr);
        }
      }

      res.json(orders);
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to retrieve orders' });
    }
  });

  // Export orders to CSV (full 20 Google Sheets columns) - defined before :id
  app.get(['/api/admin/orders/export-csv', '/api/admin/export-orders-csv'], requireAdminAuth, (req, res) => {
    try {
      const csv = db.exportOrdersToCSV();
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="sparkzen-orders-${new Date().toISOString().split('T')[0]}.csv"`);
      res.send(csv);
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to export CSV' });
    }
  });

  app.get('/api/admin/orders/:id', requireAdminAuth, (req, res) => {
    try {
      const order = db.getOrderById(req.params.id);
      if (!order) {
        return res.status(404).json({ error: 'Order not found' });
      }
      res.json(order);
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to retrieve order' });
    }
  });

  const updateOrderHandler = (req: Request, res: Response) => {
    try {
      const updated = db.updateOrder(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ error: 'Order not found' });
      }
      res.json(updated);
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to update order' });
    }
  };

  app.put(['/api/admin/orders/:id', '/api/admin/orders/:id/status'], requireAdminAuth, updateOrderHandler);
  app.patch(['/api/admin/orders/:id', '/api/admin/orders/:id/status'], requireAdminAuth, updateOrderHandler);

  // Manual trigger to sync an order to Google Sheets
  app.post('/api/admin/orders/:id/sync-sheets', requireAdminAuth, async (req, res) => {
    try {
      const order = db.getOrderById(req.params.id);
      if (!order) {
        return res.status(404).json({ error: 'Order not found' });
      }

      const result = await db.syncOrderToGoogleSheets(order);
      res.json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Sync failed' });
    }
  });

  // Admin Customers
  app.get('/api/admin/customers', requireAdminAuth, (req, res) => {
    try {
      const customers = db.getCustomers();
      res.json(customers);
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to retrieve customer records' });
    }
  });

  // Admin Settings
  app.get('/api/admin/settings', requireAdminAuth, (req, res) => {
    try {
      const settings = db.getSettings();
      res.json(settings);
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to retrieve store settings' });
    }
  });

  app.put('/api/admin/settings', requireAdminAuth, (req, res) => {
    try {
      const updated = db.updateSettings(req.body);
      res.json(updated);
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to update store settings' });
    }
  });

  // Admin Password Change
  app.post('/api/admin/change-password', requireAdminAuth, (req, res) => {
    try {
      const { newPassword } = req.body;
      const username = (req as any).adminUser;
      if (!newPassword || newPassword.length < 8) {
        return res.status(400).json({ error: 'New password must be at least 8 characters long.' });
      }

      db.updateAdminPassword(username, newPassword);
      res.json({ success: true, message: 'Admin password updated successfully.' });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to update password' });
    }
  });

  // Admin Image Upload
  app.post('/api/admin/upload-image', requireAdminAuth, (req, res) => {
    try {
      const { image, filename } = req.body;
      if (!image || typeof image !== 'string') {
        return res.status(400).json({ error: 'No image data provided.' });
      }

      // Check base64 data URL format
      const match = image.match(/^data:(image\/(jpeg|png|webp|gif|svg\+xml));base64,(.+)$/);
      let buffer: Buffer;
      let ext = 'jpg';

      if (match) {
        const mime = match[1];
        const base64Data = match[3];
        buffer = Buffer.from(base64Data, 'base64');
        if (mime === 'image/png') ext = 'png';
        else if (mime === 'image/webp') ext = 'webp';
        else if (mime === 'image/gif') ext = 'gif';
        else if (mime === 'image/svg+xml') ext = 'svg';
        else ext = 'jpg';
      } else {
        // Raw base64 string
        buffer = Buffer.from(image, 'base64');
      }

      // Validate size (max 5MB)
      if (buffer.length > 5 * 1024 * 1024) {
        return res.status(400).json({ error: 'Image exceeds the maximum allowed size of 5MB.' });
      }

      const randomSuffix = crypto.randomBytes(6).toString('hex');
      const safeOriginal = (filename || 'product')
        .toLowerCase()
        .replace(/[^a-z0-9_-]/g, '_')
        .substring(0, 20);
      const outputFilename = `upload_${Date.now()}_${safeOriginal}_${randomSuffix}.${ext}`;
      const targetPath = path.join(UPLOADS_DIR, outputFilename);

      fs.writeFileSync(targetPath, buffer);

      const publicUrl = `/images/uploads/${outputFilename}`;
      res.json({ success: true, url: publicUrl, filename: outputFilename });
    } catch (err: any) {
      console.error('Image upload error:', err);
      res.status(500).json({ error: 'Failed to process and store uploaded image.' });
    }
  });

  // Admin Database Backup Export
  app.get('/api/admin/backup', requireAdminAuth, (req, res) => {
    try {
      const backup = db.backupDatabase();
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', `attachment; filename="sparkzen-backup-${new Date().toISOString().split('T')[0]}.json"`);
      res.json(backup);
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to create database backup' });
    }
  });

  // Admin Database Restore
  app.post('/api/admin/restore', requireAdminAuth, (req, res) => {
    try {
      const { backup } = req.body;
      if (!backup) {
        return res.status(400).json({ error: 'Backup data is required.' });
      }
      const success = db.restoreDatabase(backup);
      if (!success) {
        return res.status(400).json({ error: 'Invalid backup file structure.' });
      }
      res.json({ success: true, message: 'Database successfully restored from backup.' });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to restore database: ' + err.message });
    }
  });

  // ==========================================
  // VITE DEV MIDDLEWARE & PRODUCTION STATIC SERVING
  // ==========================================
  const httpServer = http.createServer(app);

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: { server: httpServer }
      },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`⚡ SPARK Zen server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
